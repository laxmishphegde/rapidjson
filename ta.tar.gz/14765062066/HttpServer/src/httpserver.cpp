/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include "QCoreApplication"
#include "QDir"
#include "QFile"
#include "QSettings"
#include "QMap"

#include "unidef.h"     /* Mandatory */
#include "syslib.h"
#include "serv.h"
#include "httpserver.h"
#include "httpclient.h"
#include "rpclib.h"
#include "json.h"
#include "gen.h"

#include "dbamac.h"
#include "httpsession.h"
#include "qhostinfo.h"
#include "servdisp.h"
#include "fuscluster.h"
#include "conv.h"
#include "crypt.h"

#include "aaatelemetry.h"

#include "zlib.h"
// Found these here http://mail-archives.apache.org/mod_mbox/trafficserver-dev/201110.mbox/%3CCACJPjhYf=+br1W39vyazP=ix
//eQZ-4Gh9-U6TtiEdReG3S4ZZng@mail.gmail.com%3E
#define MOD_GZIP_ZLIB_WINDOWSIZE 15
#define MOD_GZIP_ZLIB_CFACTOR    9

#ifdef AAAPURIFY
#include "pure.h"
#endif
#include <httpfilter.h>

#ifdef NTWIN
#pragma warning (pop)
#endif

extern char    SV_User[MAX_USERINFO_LEN + 1];
extern ServerClientConfig EV_CurrentSrvConfig;

/************************************************************************
*   Class        :   RpcContextHttp
*
*************************************************************************/


int  RpcContextHttp::getMinSizeToCompress() {
    static bool initialized = false;
    static int minSizeToCompress = static_cast<int>(SYS_GetEnvSizeOrDefValue("AAAHTTPSERVERMINSIZECOMPRESS", 1000));
    if (!initialized)
    {
        if (minSizeToCompress > 0 && minSizeToCompress < 1000)
        {
            std::stringstream  	bufStream;
            bufStream << "The Value of AAAHTTPSERVERMINSIZECOMPRESS is too small " << minSizeToCompress << " adjusted to 1000 (0 mean no compression)";
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, bufStream.str().c_str());
            minSizeToCompress = 1000;
        }
    }
    initialized = true;
    return minSizeToCompress;
}

/************************************************************************
*   Function        :   RpcContextHttp::RpcContextHttp
*
*   Description     :   Constructor
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
RpcContextHttp::RpcContextHttp(const HttpRequest& request, HttpResponse & response)
    : m_isInit(false)
    , m_response(response)
    , m_authenticationUser(nullptr)
    , m_authenticationPwd(nullptr)
    , m_formatFields(nullptr)
    , m_requestCompression(HttpUtility::Compression::NONE)
    , m_importLogLevelEn(ProcessingMessageNatEn::Warning)
{
    CURRENTCHARSETCODE_ENUM charset;
    this->m_formatFields = new FormatFieldsRapidJson();

    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charset);
    this->m_formatFields->setCharsetUtf8(charset == CurrentCharsetCode_UTF8);
    this->m_formatFields->setErrorCallback(MSG_SendMesg);

    setDesiredCompression(request);

    const QByteArray displayHost = getRequestHeader(request,"X-DisplayHost");
    if (displayHost.isEmpty() == false)
    {
        this->m_displayHost = displayHost.data();
    }

    constexpr char* BEARER_HEADER = "Bearer ";
    const QByteArray authorizationHeader = getRequestHeader(request, "Authorization");
    if (authorizationHeader.isEmpty() == false && authorizationHeader.startsWith(BEARER_HEADER))
    {
        m_base64JWT = authorizationHeader.right(authorizationHeader.length() - qstrlen(BEARER_HEADER));
    }
}


/************************************************************************
*   Function        :   RpcContextHttp::~RpcContextHttp
*
*   Description     :   Destructor
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
RpcContextHttp::~RpcContextHttp()
{
    delete m_formatFields;
}


/************************************************************************
*   Function        :   RpcContextHttp::getRpcContextType
*
*   Description     :   This is an HTTP context
*
*   Arguments       :   None
*
*   Return          :   This is an HTTP context
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
RpcContextType RpcContextHttp::getRpcContextType()
{
    return RpcContextType::HTTP;
}


/************************************************************************
*   Function        :   RpcContextHttp::setRpcOnError
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - LJE - 160613
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::setRpcOnError()
{
    SYS_SetThreadFatalError();
    if (this->getTaRetCode() == RET_SUCCEED)    /* DLA - PMSTA-25721 - 161219 */
    {
        this->setTaRetCode(RET_SRV_LIB_ERR_GENERAL);
    }
}


/************************************************************************
*   Function        :   RpcContextHttp::serverDoneError
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::serverDoneError()
{
}

int RpcContextHttp::serverMsg(const char *, int retCode, int)
{
    this->setTaRetCode(retCode);
    return 1;
}

bool RpcContextHttp::servColBind(int colNumber, const char * colName, DATATYPE_ENUM type, DBI_PTR dataPtr, DBI_INT *dataLength, DBI_SMALLINT *nullData, FIELD_IDX_T dynStPos)
{
    if (this->m_isInit == false)
    {
        this->m_isInit = true;
        this->m_formatFields->blockModeBegin(NullEntity, this->m_currMapBindDataDef.m_usage == DbiBindDataDef::Usage::OutputParam ? SqlRequestOutputParam : NullDynSt);
        this->resultSetNb++;
    }

    RpcContext::servColBind(colNumber, colName, type, dataPtr, dataLength, nullData, dynStPos);

    return true;
}

std::string RpcContextHttp::getConnectionInputKey()
{
    return getSessionId().data();	/* PMSTA-24797 - TEB - 160823 */
}

/************************************************************************
*   Function           : RpcContext::bindRecord()
*
*   Description        :
*
*   Arguments          :
*
*   Functions call     :
*
*   Return             :
*  Creation Date       :
*
*  Last Modif          : PMSTA-24913 - LJE - 161003
*
*************************************************************************/
bool RpcContextHttp::bindRecord(DBA_DYNST_ENUM dynSt, const char **colNameTab, std::set<INT_T>* fieldListSet)
{
    this->m_isInit = true;
    this->m_formatFields->blockModeBegin(GET_OBJ_DYNST(dynSt), dynSt);
    this->resultSetNb++;

    return RpcContext::bindRecord(dynSt, colNameTab, fieldListSet);
}

/*************************************************************************
*   Function             : RpcContextHttp::prepareDataField()
*
*   Description          : Prepare the send of data columns to the client
*                          for a financial function result.
*
*   Arguments            : srvProc   : a client threat pointer
*                          fieldType : the field datatype
*                          colNb     : a pointer on the columns number
*                          field     : a pointer on a DBA_DYNFLD_ST
*
*   Functions call       :
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*  Creation Date         : December 94 - PEC
*  Last Modif            : February 00 - GRD - REF4204.
*                          REF8844 - LJE - 030325 : Add fldNbr
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*                          PMSTA-18893 - 101114 - PMO : Core dump during precomp on instrument
*                          PMSTA-27364 - 080518 - PMO : RpcContextHttp::prepareDataField: Source and destination overlap in memcpy
*
*************************************************************************/
bool RpcContextHttp::prepareDataField(DATATYPE_ENUM fieldType, int colNb, DBA_DYNFLD_STP dynStp, int fldNbr)
{
    if (nullptr == this->bindStp)
    {
        return false;
    }

    this->setOutPutDynStp(this->bindStp);

    if (nullptr == this->nullFlags || nullptr == this->fieldLength)
    {
        return false;
    }


    /* PMSTA-27364 - 080518 - PMO */
    if (this->bindStp != dynStp)
    {
        switch (GET_CTYPE(fieldType))
        {
            case DoubleCType:
                SET_DOUBLE(this->bindStp, colNb, GET_DOUBLE(dynStp, fldNbr));
                break;

            case CharPtrCType:
            case TextPtrCType:                  /* REF4204 */
                SET_STRING(this->bindStp, colNb, GET_STRING(dynStp, fldNbr));
                this->fieldLength[colNb] = GET_FLD_STRLEN(dynStp, fldNbr);
                break;

            case UniCharPtrCType:
            case UniTextPtrCType:
                SET_USTRING(this->bindStp, colNb, GET_USTRING(dynStp, fldNbr));
                this->fieldLength[colNb] = GET_FLD_USTRLEN(dynStp, fldNbr) * sizeof(UChar);
                break;

            case IntCType:
            case UIntCType:
                SET_INT(this->bindStp, colNb, GET_INT(dynStp, fldNbr));
                break;

            case LongLongCType: /* DLA - PMSTA08801 - 091216 */
                SET_LONGLONG(this->bindStp, colNb, GET_LONGLONG(dynStp, fldNbr));
                break;

            case ShortCType:
            case UShortCType:
                SET_SHORT(this->bindStp, colNb, GET_SHORT(dynStp, fldNbr));
                break;

            case UCharCType:
                SET_UCHAR(this->bindStp, colNb, GET_UCHAR(dynStp, fldNbr));
                break;

            case TimeStampCType:
                SET_TIMESTAMP(this->bindStp, colNb, GET_TIMESTAMP(dynStp, fldNbr));
                break;

            case BinaryCType:
                SET_BINARY(this->bindStp, colNb, GET_BINARY(dynStp, fldNbr));
                break;

            case DateTimeStCType:
                SET_DATETIMEST(this->bindStp, colNb, GET_DATETIMEST(dynStp, fldNbr));
                break;

            default:
                break;
        }
    }
    else
    { // Source and target are equal
        /* PMSTA-27364 - 080518 - PMO */
        switch (GET_CTYPE(fieldType))
        {
            case CharPtrCType:
            case TextPtrCType:
                this->fieldLength[colNb] = GET_FLD_STRLEN(dynStp, fldNbr);
                break;

            case UniCharPtrCType:
            case UniTextPtrCType:
                this->fieldLength[colNb] = GET_FLD_USTRLEN(dynStp, fldNbr) * sizeof(UChar);
                break;

            default:
                break;
        }
    }

    if (IS_NULLFLD(dynStp, fldNbr))
    {
        SET_NOTNULLFLG_F(this->bindStp, colNb);
        this->nullFlags[colNb] = DBI_NULLDATA;
    }
    else
    {
        SET_NOTNULLFLG_T(this->bindStp, colNb);
        this->nullFlags[colNb] = DBI_GOODDATA;
    }

    return true;
}

/************************************************************************
*   Function        :   RpcContextHttp::setSessionId
*
*   Description     :
*
*   Arguments       :   sessionId
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::setSessionId(QByteArray sessionId)
{
    m_sessionId = sessionId;

}


/************************************************************************
*   Function        :   RpcContextHttp::getSessionId
*
*   Description     :
*
*   Arguments       :   None
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
QByteArray RpcContextHttp::getSessionId()
{
    return m_sessionId;
}


/************************************************************************
*   Function        :   RpcContextHttp::setHttpBody
*
*   Description     :   Define the HTTP body
*
*   Arguments       :   httpBody
*
*   Return          :
*
*   Creation Date   :   PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::setHttpBody(const std::string & httpBody)
{
    m_httpBody = httpBody;
}

/************************************************************************
*   Function        :   RpcContextHttp::getHttpBody
*
*   Description     :   Return a reference to the HTTP body
*
*   Arguments       :
*
*   Return          :   A reference to the HTTP body
*
*   Creation Date   :   PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*
*   Last Modif.     :
*
*************************************************************************/
const std::string & RpcContextHttp::getHttpBody()
{
    return m_httpBody;
}


/************************************************************************
*   Function        :   RpcContextHttp::setImportLogLevel
*
*   Description     :   Define the Import Log Level
*
*   Arguments       :   importLogLevel
*
*   Return          :
*
*   Creation Date   :   PMSTA-46681 - LJE - 240207
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::setImportLogLevel(const std::string& importLogLevel)
{
    auto enumValue = DBA_GetPermValEnum(ProcessingMessage, A_ProcessingMessage_NatEn, importLogLevel.c_str());

    if (enumValue != -1)
    {
        this->m_importLogLevelEn = static_cast<ProcessingMessageNatEn>(enumValue);
    }
    else
    {
        this->m_importLogLevelEn = ProcessingMessageNatEn::Warning;
    }
}

/************************************************************************
*   Function        :   RpcContextHttp::getImportLogLevel
*
*   Description     :   Get the Import Log Level
*
*   Arguments       :   
*
*   Return          :
*
*   Creation Date   :   PMSTA-46681 - LJE - 240207
*
*   Last Modif.     :
*
*************************************************************************/
ProcessingMessageNatEn RpcContextHttp::getImportLogLevel() const
{
    return this->m_importLogLevelEn;
}

/************************************************************************
*   Function        :   RpcContextHttp::setEntityProfile
*
*   Description     :   Define the Import entity profile
*
*   Arguments       :   entityProfile
*
*   Return          :
*
*   Creation Date   :   PMSTA-46681 - LJE - 240207
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::setEntityProfile(const std::string& entityProfile)
{
    this->m_entityProfileCd = entityProfile;
}

/************************************************************************
*   Function        :   RpcContextHttp::getEntityProfile
*
*   Description     :   Get the Import entity profile
*
*   Arguments       :   
*
*   Return          :
*
*   Creation Date   :   PMSTA-46681 - LJE - 240207
*
*   Last Modif.     :
*
*************************************************************************/
const std::string& RpcContextHttp::getEntityProfile() const
{
    return this->m_entityProfileCd;
}

/************************************************************************
*   Function        :   RpcContextHttp::getDisplayHost
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-43741 - LJE - 210223
*
*   Last Modif.     :
*
*************************************************************************/
const std::string & RpcContextHttp::getDisplayHost() const
{
    return this->m_displayHost;
}

/************************************************************************
*   Function        :   RpcContextHttp::servSendFile
*
*   Description     :   Send a file as a result
*
*   Arguments       :   filename
*                       mimeType
*
*   Return          :   true    if ok
*                       false   if error
*
*   Creation Date   :   PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*
*   Last Modif.     :
*
*************************************************************************/
bool RpcContextHttp::servSendFile(const std::string & filename, const std::string & mimeType)
{
    bool ret = false;

    QFile file(QString::fromLocal8Bit(filename.c_str()));

    if (file.open(QIODevice::ReadOnly))
    {
        m_response.setHeader("Content-Type", qPrintable(mimeType.c_str()));
        size_t pos = filename.find_last_of('/');
#if defined(_WIN32)
        if (pos == std::string::npos)
        {
            pos = filename.find_last_of('\\');
        }
#endif
        std::string attachFileName = "attachment; filename=\"";
        if (pos != std::string::npos)
        {
            attachFileName = attachFileName + filename.substr(pos + 1) ;
        }
        else
        {
            attachFileName = attachFileName + filename;
        }
        attachFileName = attachFileName + "\"";

        m_response.setHeader("Content-Disposition", qPrintable(attachFileName.c_str()));

        // Return the file content
        while (!file.atEnd() && !file.error())
        {
            m_response.write(file.read(64*1024*1024));
        }

        file.close();
        ret = true;
    }

    return ret;
}


/************************************************************************
*   Function        :   RpcContextHttp::setAuthenticationUserPwd
*
*   Description     :   Used only the time of Authentication
*
*   Arguments       :   authenticationUser  User
*                       authenticationPwd   Password
*
*   Return          :
*
*   Creation Date   :   PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*   Last Modif.     :
*
*************************************************************************/
void RpcContextHttp::setAuthenticationUserPwd(const QByteArray * authenticationUser, PasswordEncrypted * authenticationPwd)
{
    m_authenticationUser = authenticationUser;
    m_authenticationPwd = authenticationPwd;
}


/************************************************************************
*   Function        :   RpcContextHttp::getAuthenticationUser
*
*   Description     :   Used only the time of Authentication
*
*   Arguments       :   None
*
*   Return          :   User referenced by setAuthenticationUserPwd
*
*   Creation Date   :   PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*   Last Modif.     :
*
*************************************************************************/
const QByteArray * RpcContextHttp::getAuthenticationUser() const
{
    return m_authenticationUser;
}


/************************************************************************
*   Function        :   RpcContextHttp::getAuthenticationUser
*
*   Description     :   Used only the time of Authentication
*
*   Arguments       :   None
*
*   Return          :   Password referenced by setAuthenticationUserPwd
*
*   Creation Date   :   PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*   Last Modif.     :
*
*************************************************************************/
PasswordEncrypted * RpcContextHttp::getAuthenticationPwd()
{
    return m_authenticationPwd;
}

/************************************************************************
*   Function        :   RpcContextHttp::getHTTPStatusFromTaRetCode
*
*   Description     :   Return the HTTP status depends of TA ret code
*
*   Arguments       :   None
*
*   Return          :   HTTP status
*
*   Last Modif.     : PMSTA-49293 FME 2022-06-23
*
*************************************************************************/
int RpcContextHttp::getHTTPStatusFromTaRetCode()
{
    int ret = HTTP_STATUS_OK;
    switch (getTaRetCode())
    {
    case RET_FIN_ERR_SECURITY_ISSUE:
        ret = HTTP_STATUS_FORBIDDEN;
        break;

    case RET_DBA_ERR_CANNOTCONNECT:
        ret = HTTP_STATUS_FORBIDDEN;
        break;

    case RET_GEN_ERR_INVARG:
        ret = HTTP_STATUS_BAD_REQUEST;
        break;

    case RET_SUCCEED:
        ret = HTTP_STATUS_OK;
        break;

    case RET_SRV_INFO_CLOSING_SUCCEED:
        ret = HTTP_STATUS_NO_CONTENT;
        break;

    case RET_GEN_INFO_MAX_REACHED:
        ret = HTTP_STATUS_PARTIAL_CONTENT;
        break;

    default:
        if (RET_GET_LEVEL(getTaRetCode()) == RET_LEV_ERROR)
        {
            ret = HTTP_STATUS_INTERNAL_SERVER_ERROR;
        }
        else
        {
            ret = HTTP_STATUS_OK;
        }
    }
    return ret;
}

bool RpcContextHttp::servSendRowData()
{
    bool ret = false;

    if (this->bLocaDynStp)
    {
        FIELD_IDX_T fldIdx = 0;
        if (this->m_dynStp == nullptr)
        {
            this->m_dynStpSize = CAST_INT(this->m_currMapBindDataDef.bindData.size());
            this->m_dynStp = ALLOC_DYNST_WITHOUTDEF(this->m_dynStpSize);

            int i = 0;
            for (auto it = this->m_currMapBindDataDef.bindData.begin(); it != this->m_currMapBindDataDef.bindData.end(); ++it, ++i)
            {
                this->m_dynStp[i].dataType = static_cast<unsigned char>(it->second.m_dataType);
            }
        }

        for (auto it = this->m_currMapBindDataDef.bindData.begin(); it != this->m_currMapBindDataDef.bindData.end(); ++it)
        {
            DATATYPE_ENUM type = it->second.m_dataType;

            if (it->second.m_nullValue != nullptr &&
                *it->second.m_nullValue == DBI_NULLDATA)
            {
                SET_NULL(this->m_dynStp, fldIdx, type);
            }
            else
            {
                switch (GET_CTYPE(type))
                {
                    case  DoubleCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, *(double*)it->second.m_dataIn);
                        break;
                    case  IntCType:
                    case  UIntCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, *(int*)it->second.m_dataIn);
                        break;

                    case  ShortCType:
                    case  UShortCType:

                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, *(short*)it->second.m_dataIn);
                        break;
                    case  UCharCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, *(unsigned char*)it->second.m_dataIn);
                        break;

                    case  DateTimeStCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, *(DATETIME64_ST*)it->second.m_dataIn);
                        break;

                    case  UniCharPtrCType:
                    case  UniTextPtrCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, (const UChar*)it->second.m_dataIn);
                        break;

                    case  LongLongCType:
                    case  BinaryCType:
                    case  TimeStampCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, *(INT64_T*)it->second.m_dataIn);
                        break;

                    case  TextPtrCType:
                    case  CharPtrCType:
                    case  VarCharPtrCType:
                    case  VarTextPtrCType:
                        DICT_SetDynfld(this->m_dynStp, fldIdx, type, (const char*)it->second.m_dataIn);
                        break;


                    case  ExtPtrCType:
                    case  ArrayPtrCType:
                    case  MultiArrayPtrCType:
                    case  PtrCType:
                        break;
                }
            }
            fldIdx++;
        }
    }

    if (this->m_dynStp == nullptr)
    {
        return false;
    }

    BuildBindOption  buildBindOption;
    this->m_formatFields->blockModeAdd(this->m_dynStp, this->m_currMapBindDataDef, buildBindOption);
    this->rowsSendNb++;

    if (true == this->m_formatFields->isError())
    { /* Error */
        MSG_SendMesg(ret, 1, FILEINFO, "servSendRowData", "Error formatting data");

        for (size_t idxError = 0; idxError < this->m_formatFields->nbError(); idxError++)
        {
            // DLA - Error Management TODO
        }
        return false;
    }

    this->m_currMapBindDataDef.rowsSentNbr++;

    return true;
}


/************************************************************************
*   Function        :   RpcContextHttp::servSendDone
*
*   Description     :
*
*   Arguments       :   status
*                       rows
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :   PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*
*************************************************************************/
bool RpcContextHttp::servSendDone(int status, int rows)
{
    bool isInError = SYS_IsThreadFatalError();
    bool lastPart = ((status & SEND_MORE) != SEND_MORE);
    if (isInError)
    {
        status |= SEND_ERROR;
    }
    if (lastPart)
    {
        status |= SEND_FINAL;
    }

    bool bSendDone = RpcContext::servSendDone(status, rows);

    /* PMSTA-32235 - 160519 - PMO */
    if (SEND_FINISHED != (status & SEND_FINISHED))
    {
        this->m_formatFields->blockModeEnd();
    }

    if (lastPart)
    {
        if (isInError == false)
        {
	        /* Data serialized */
	        std::string jsonData;

            if (this->m_response.getStatusCode() != HTTP_STATUS_NO_CONTENT)
            {
                this->m_formatFields->getDataSerialized(jsonData, true);
            }

            {
                AAALogger httpServerAccessLogger = AAALogger::get(AAALogger::Logger::HttpAccessServer);
                if (httpServerAccessLogger.isTraceEnabled())
                {
                    std::ostringstream  loggingStream;

                    loggingStream << "RpcContextHttp::servSendDone : data=" << jsonData << " status=" << m_response.getStatusCode();

                    loggingStream << " header={";
                    QMapIterator<QByteArray, QByteArray> headerIter(m_response.getHeaders());
                    while (headerIter.hasNext())
                    {
                        headerIter.next();
                        loggingStream << headerIter.key().data() << "=" << headerIter.value().data();
                        if (headerIter.hasNext())
                        {
                            loggingStream << ",";
                        }
                    }
                    loggingStream << "}";

                    httpServerAccessLogger.trace(loggingStream.str());
                }
            }

            QByteArray datatoSend;

            manageCompression(jsonData, datatoSend);

	        this->m_response.write(datatoSend, lastPart);

    	}
        else
        {
            m_response.setHeader("Content-Type", "application/json; charset=UTF-8");
            m_response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_INTERNAL_SERVER_ERROR));
            m_response.write("{ ""Error"":500, ""RPC"":" + QByteArray(this->getRpcName().c_str()) + ", ""Message"":""Error in RPC execution, see log file""}", true);
        }
    }
    this->rowsSendNb = 0;

    if (this->bLocaDynStp)
    {
        FREE_DYNST_SUPPLFLD(this->m_dynStp, this->m_dynStpSize);
    }
    else
    {
        this->m_dynStp = nullptr;
    }
    this->m_dynStpSize = 0;
    this->bLocaDynStp  = true;

    this->m_currMapBindDataDef.clear();
    this->m_isInit = false;

    if (rows > 1)
    {
        m_response.flush();
    }

    return bSendDone;
}


/************************************************************************
*   Function        :   RpcContextHttp::servSendData
*
*   Description     :
*
*   Arguments       :   status
*                       rows
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :   PMSTA-46681 - LJE - 220704
*
*************************************************************************/
bool RpcContextHttp::servSendData(const std::string& jsonData)
{
    bool isInError = SYS_IsThreadFatalError();

    bool bSendDone = isInError == false;

    if (isInError == false)
    {
        AAALogger httpServerAccessLogger = AAALogger::get(AAALogger::Logger::HttpAccessServer);
        if (httpServerAccessLogger.isTraceEnabled())
        {
            std::ostringstream  loggingStream;

            loggingStream << "RpcContextHttp::servSendDone : data=" << jsonData << " status=" << m_response.getStatusCode();

            loggingStream << " header={";
            QMapIterator<QByteArray, QByteArray> headerIter(m_response.getHeaders());
            while (headerIter.hasNext())
            {
                headerIter.next();
                loggingStream << headerIter.key().data() << "=" << headerIter.value().data();
                if (headerIter.hasNext())
                {
                    loggingStream << ",";
                }
            }
            loggingStream << "}";

            httpServerAccessLogger.trace(loggingStream.str());
        }

        QByteArray datatoSend;

        manageCompression(jsonData, datatoSend);

        m_response.setHeader("Content-Type", "application/json; charset=UTF-8");
        m_response.setStatus(HTTP_STATUS_AND_TEXTC(this->getHTTPStatusFromTaRetCode()));
        this->m_response.write(datatoSend, true);

        RpcContext::servSendDone(SEND_FINAL | SEND_COUNT, 1);
    }
    else
    {
        m_response.setHeader("Content-Type", "application/json; charset=UTF-8");
        m_response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_INTERNAL_SERVER_ERROR));
        m_response.write("{ ""Error"":500, ""RPC"":" + QByteArray(this->getRpcName().c_str()) + ", ""Message"":""Error in RPC execution, see log file""}", true);
    }
    m_response.flush();

    return bSendDone;
}

void RpcContextHttp::manageCompression(const std::string& fromData, QByteArray& compressedData)
{
    size_t initalSize = fromData.size();

    if (initalSize == 0)
    {
        return;
    }

    size_t minSizeToCompress = getMinSizeToCompress();

    switch (m_requestCompression)
    {
        case HttpUtility::Compression::DEFLATE:
        case HttpUtility::Compression::GZIP:

            if (minSizeToCompress > 0 && fromData.size() >= minSizeToCompress)
            {


                z_stream zs;                        // z_stream is zlib's control structure
                memset(&zs, 0, sizeof(zs));


                if (m_requestCompression == HttpUtility::Compression::DEFLATE)
                {
                    int compressionlevel = Z_BEST_COMPRESSION;
                    if (deflateInit(&zs, compressionlevel) != Z_OK)
                    {
                        throw(std::runtime_error("deflateInit failed while compressing."));
                    }
                    this->m_response.setHeader("Content-Encoding", "deflate");

                }
                if (m_requestCompression == HttpUtility::Compression::GZIP)
                {
                    if (deflateInit2(&zs,
                                     Z_BEST_COMPRESSION,
                                     Z_DEFLATED,
                                     MOD_GZIP_ZLIB_WINDOWSIZE + 16,
                                     MOD_GZIP_ZLIB_CFACTOR,
                                     Z_DEFAULT_STRATEGY) != Z_OK
                        )
                    {
                        throw(std::runtime_error("deflateInit2 failed while compressing."));
                    }
                    this->m_response.setHeader("Content-Encoding", "gzip");
                }

                zs.next_in = reinterpret_cast<Bytef*>(const_cast<char *>(fromData.data()));
                zs.avail_in = static_cast<uInt>(fromData.size());           // set the z_stream's input

                int ret;
                char outbuffer[32768];

                compressedData.reserve(static_cast<int>(fromData.size())); // Avoid buffer resize, so worst case no compression

                // retrieve the compressed bytes blockwise
                do
                {
                    zs.next_out = reinterpret_cast<Bytef*>(outbuffer);
                    zs.avail_out = sizeof(outbuffer);

                    ret = deflate(&zs, Z_FINISH);

                    if (compressedData.size() < static_cast<int>(zs.total_out))
                    {
                        // append the block to the output string
                        compressedData.append(outbuffer,
                                              zs.total_out - compressedData.size());
                    }
                } while (ret == Z_OK);

                deflateEnd(&zs);

                if (ret != Z_STREAM_END)
                {          // an error occurred that was not EOF
                    std::ostringstream oss;
                    oss << "Exception during zlib compression: (" << ret << ") " << (zs.msg == nullptr) ? "" : zs.msg;
                    throw(std::runtime_error(oss.str()));
                }

            }
            else
            {
                compressedData = fromData.c_str();
            }
            break;

        default:
            compressedData = fromData.c_str();
            break;
    }
    {
        int finalSize = compressedData.size();
        std::ostringstream oss;
        oss << "Compression from size=" << initalSize << " to=" << finalSize << " requesting compression " << m_requestCompression << " min. size to compress=" << minSizeToCompress << " ratio=" << initalSize / finalSize;

        AAALogger::get(AAALogger::Logger::HttpServer).info(oss.str());
    }
}


bool RpcContextHttp::servSendStatus(int status)
{
    bool bSendStatus = RpcContext::servSendStatus(status);

    if (status != 0)
    {
        m_response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_INTERNAL_SERVER_ERROR));
    }
    else
    {
        m_response.setStatus(HTTP_STATUS_AND_TEXTC(this->getHTTPStatusFromTaRetCode()));
    }

    return bSendStatus;
}

void RpcContextHttp::setDesiredCompression(const HttpRequest & request)
{

    QList<QByteArray> acceptedEncoding = getRequestHeader(request,"Accept-Encoding").split(',');
    for (QList<QByteArray>::iterator i = acceptedEncoding.begin(); i != acceptedEncoding.end(); ++i) {
        if (QString::compare(i->trimmed(), "gzip", Qt::CaseInsensitive) == 0)
        {
            m_requestCompression = HttpUtility::Compression::GZIP;
            break;
        }
        if (QString::compare(i->trimmed(), "deflate", Qt::CaseInsensitive) == 0)
        {
            m_requestCompression = HttpUtility::Compression::DEFLATE;
            break;
        }
    }
}

bool RpcContextHttp::servEndianWorkAround()
{
    return 0;
}

void RpcContextHttp::servStop()
{
    SERV_SetStopedServer();
    QCoreApplication::quit();
}

std::string RpcContextHttp::getCharsetName()
{
    return std::string();
}

bool RpcContextHttp::servSleep(std::string )
{
    return false;
}

bool RpcContextHttp::servWakeUp()
{
    return false;
}

bool RpcContextHttp::servEvent(SRV_EVENT_ENUM)
{
    return false;
}

void RpcContextHttp::setJWT(QByteArray jwt)
{
    m_base64JWT = jwt;
}

QByteArray RpcContextHttp::getJWT() const
{
    return m_base64JWT;
}

/************************************************************************
**
**  Function    :   HTTP_CreateThreadDescriptorWithHttpContext
**
**  Description :   A thread created by HTTP have a lot of builtin "variables" defined
**                  These variables are transfered into the thread infrastructure into this function
**
**  Arguments   :   request
**                  response
**                  rpcName
**                  rpcProperties
**
**  Return      :   Return a pointer on the created thread filled with Sybase variable values
**
**  Last modif. :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**
*************************************************************************/
ThreadDescriptor * HTTP_CreateThreadDescriptorWithHttpContext(const HttpRequest &, QByteArray & rpcName, const RpcProperties & rpcProperties, HttpSession & session)
{
    SYS_InitThreadLocalStorage();

    ThreadDescriptor * pThread = new ThreadDescriptor(ThreadBind::TB_CURRENT_THREAD);


    /* PMSTA-34344 - TEB - 190805 */
    AAALogger httpServerAccessLogger = AAALogger::get(AAALogger::Logger::HttpAccessServer);

    if (httpServerAccessLogger.isDebugEnabled())
    {
        if (session.contains("applSessionCd"))
        {
            const std::string  sessCD = std::string(session.get("applSessionCd").toString().toLocal8Bit().constData());

            std::ostringstream  loggingStream;
            loggingStream << " HTTP_CreateThreadDescriptorWithHttpContext (" << qPrintable(rpcName) << ") with cookie applSessionCd[" << sessCD << "]";
            httpServerAccessLogger.debug(loggingStream.str());
        }
    }

    if (session.contains("userId") && rpcProperties.isProxy() == true )
    {
        if (httpServerAccessLogger.isDebugEnabled())
        {
            std::ostringstream  loggingStream;
            loggingStream << " HTTP_CreateThreadDescriptorWithHttpContext (" << qPrintable(rpcName) << ") with cookie userId[" << session.get("userId").toString().toLocal8Bit().constData() << "]";
            httpServerAccessLogger.debug(loggingStream.str());
        }

        pThread->setUser(session.get("userId").toString().toLocal8Bit().constData());
    }
    else      /* PMSTA-34344 - TEB - 190805 */
    {
        if (httpServerAccessLogger.isDebugEnabled())
        {
            std::ostringstream  loggingStream;
            loggingStream << " HTTP_CreateThreadDescriptorWithHttpContext (" << qPrintable(rpcName) << ") set userId[" << SV_User << "]";
            httpServerAccessLogger.debug(loggingStream.str());
        }

        pThread->setUser(session.get("userId").toString().toLocal8Bit().constData());
    }

    if (session.contains("password") && rpcProperties.isProxy() == true)
    {
        PasswordEncrypted pE;
        pE.setPassword(session.get("password").toString().toLocal8Bit().constData());
        pThread->setPassword(pE);

        if (httpServerAccessLogger.isDebugEnabled())
        {
            std::ostringstream  loggingStream;
            loggingStream << " HTTP_CreateThreadDescriptorWithHttpContext (" << qPrintable(rpcName) << ") set password from Session";
            httpServerAccessLogger.debug(loggingStream.str());
        }

    }
    else     /* PMSTA-34344 - TEB - 190805 */
    {
        if (session.contains("userId") && session.contains("password") )             /* PMSTA-34344 - TEB - 190405 */
        {
            PasswordEncrypted pE;
            pE.setPassword(session.get("password").toString().toLocal8Bit().constData());
            pThread->setPassword(pE);
        }
        else if (session.contains("password"))
        {
            PasswordEncrypted * pE = nullptr;
            GEN_GetUserInfo(UserPasswd, &pE);

            pThread->setPassword(*pE);

            if (httpServerAccessLogger.isDebugEnabled())
            {
                std::ostringstream  loggingStream;
                loggingStream << " HTTP_CreateThreadDescriptorWithHttpContext (" << qPrintable(rpcName) << ") set password from gen User Info";
                httpServerAccessLogger.debug(loggingStream.str());
            }
        }

    }

    pThread->setThreadCreator(ThreadCreator::TC_QT);

    { /* Get client Application name */
        pThread->setApplicationName("aaa_srv");
    }

    { /* Get the client host name */
        QHostInfo host;
        pThread->setHostName(host.localHostName().toLocal8Bit().constData());
    }

    { /*Get the thread type*/
        pThread->setTechnicalType(ThreadTechnicalType::CLIENT);
    }

    { /*Get the C library version */
        pThread->setCLibVersion("007");
    }

    { /*Get the RPC name */
        pThread->setRpcName(qPrintable(rpcName));
    }

    /* Error handling */
    if (true == SYS_IsThreadFatalError())
    { /* Error */
        //        SYB_ServerDoneError(srvProc);
    }

    SERV_InitNewConInfoThread(SYS_GetThreadUser(),
                              SYS_GetThreadHostName(),
                              SYS_GetThreadApplicationName(),
                              SYS_GetThreadCLibVersion());

    return pThread;
}


/************************************************************************
**
**  Function    :   HTTP_MapThreadReturn
**
**  Description :   Map a boolean return value to an HTTP return value
**
**  Arguments   :   value     true  -> 1
**                            false -> 0
**
**  Return      :   true  -> 1
**                  false -> 0MapThreadReturn
**
**  Last modif. :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**
*************************************************************************/
int HTTP_MapThreadReturn(const bool value)
{
    return true == value ? 1 : 0;
}



/************************************************************************
*   Function        :   HTTP_RpcExecutor
*
*   Description     :   Execute the RPC if any
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :   PMSTA-27310 - 160517 - PMO : Core file generated when writing an error message
*
*************************************************************************/
void HTTP_RpcExecutor(HttpRequest& request, HttpResponse& response, QByteArray & rpcName, HttpSession& session)
{
    bool internalError = false; /* PMSTA-27310 - 160517 - PMO */
    AAATracer::AAAScopedSpan executorSpan(AAATelemetry::GetTracer(AAATracer::TraceName::HttpServerDetailed).startNewSpan("HTTP_RpcExecutor"));
    try
    {
        const RpcProperties &   rpcProperties     = EV_RpcCollection.getRpcProperties(qPrintable(rpcName));
        RPC_FN                  functionToExecute = rpcProperties.getRpcFuncPtr();
        ThreadFrame             threadFrame(HTTP_CreateThreadDescriptorWithHttpContext(request, rpcName, rpcProperties, session));
        RpcContextHttp          rpcContextHttp(request, response);

        try // To have an understandable error message in the log file, thread data are separated / PMSTA-27310 - 160517 - PMO
        {
            if (nullptr != functionToExecute &&
                true    == rpcProperties.isRoleAllowed())
            {
                rpcContextHttp.setRpcName(SYS_GetRpcName());
                rpcContextHttp.setSessionId(session.getId());		/* PMSTA-24797 - TEB - 160823 */

                /* PMSTA-34344 - TEB - 190805 */
                AAALogger httpServerAccessLogger = AAALogger::get(AAALogger::Logger::HttpAccessServer);

                if (httpServerAccessLogger.isTraceEnabled())
                {
                    std::ostringstream  loggingStream;

                    loggingStream << " [HTTP_RpcExecutor] Content of session :   ";

                    QMapIterator<QByteArray, QVariant> i(session.getAll());

                    while (i.hasNext())
                    {
                        i.next();
                        if (i.key().toLower().startsWith("password") ) {
                           loggingStream << " key[" << i.key().data() << "] value=[encrypted], ";
                        }
                        else
                        {
                            loggingStream << " key[" << i.key().data() << "] value=[" << i.value().toString().toLatin1().data() << "], ";
                        }
                    }

                    httpServerAccessLogger.trace(loggingStream.str());
                }

                /* PMSTA-34344 - LJE - 201119 */
                if (session.contains("AAARealmUser"))
                {
                    rpcContextHttp.setProxyCall(true);
                    rpcContextHttp.setAAARealmUser(session.get("AAARealmUser").toString().toLocal8Bit().constData());
                }
                else
                {
                    rpcContextHttp.setAAARealmUser(session.get("userId").toString().toLocal8Bit().constData());
                }
                if (session.contains("applSessionCd"))
                {
                    if (session.contains("guiProxy"))
                    {
                        rpcContextHttp.setProxyCall(true);
                    }

                    rpcContextHttp.setApplSessionCd(session.get("applSessionCd").toString().toLocal8Bit().constData());
                }

                response.setHeader("Content-Type", "application/json; charset=UTF-8");

                if (SYS_IsStateShutdownRequested() == false)
                {
                    if (rpcContextHttp.getApplSessionCd().empty() &&
                        rpcContextHttp.getRpcProperties().isProxy() &&
                        rpcContextHttp.getRpcProperties().isApplSession())
                    {
                        QByteArray basicRealmValue("Basic realm=");
                        basicRealmValue.append('"').append(session.get("userId").toString().toLocal8Bit().constData()).append('"');
                        response.setHeader("WWW-Authenticate", basicRealmValue);
                        response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_UNAUTHORIZED));
                        response.write("401 Authorization Required", true);
                    }
                    else
                    {
                        /* Initialize the RPC as "Running" */
                        if (SERV_RpcInit() == FALSE)
                        {
                            SYS_SetThreadFatalError();
                        }
                        else
                        {
                            AAATracer::AAASpan readParamaterSpan = AAATelemetry::GetTracer(AAATracer::TraceName::HttpServerDetailed).startNewSpan("Http_ReadRpcParameters");
                            bool paramOk = Http_ReadRpcParameters(request, rpcContextHttp, rpcProperties);
                            readParamaterSpan.finish();
                            if (paramOk)
                            {
                                std::string applSessionCd = SYS_GetThreadApplSessionCd();

                                SERV_GetCurrConnStructPtr()->dialogType = RpcDialog;

                                {
                                    /* if the http request has JWT, then set proxy user
                                     * otherwise there will be issue with getting DB connection in the RPC method
                                     * as we don't use tasc technical user.
                                     */
                                    if (!rpcContextHttp.getJWT().isEmpty())
                                    {
                                        DBA_SetProxyUserToOn();
                                    }
                                    AAATracer::AAAScopedSpan payloadSpan(AAATelemetry::GetTracer(AAATracer::TraceName::HttpServer).startNewSpan(SYS_Stringer("rpcExecution ", rpcName.constData())));
                                    SYS_ExecuteThread(threadFrame.getThread(), functionToExecute, &rpcContextHttp, rpcContextHttp.getRpcName().c_str());
                                }

                                if ((rpcContextHttp.getLastSendDone() & SEND_FINAL) != SEND_FINAL)
                                {
                                    if (SYS_IsThreadFatalError() == false)
                                    {
                                        rpcContextHttp.servSendDone(SEND_FINAL, 0);
                                    }
                                    else
                                    {
                                        int retStatus = rpcContextHttp.getHTTPStatusFromTaRetCode();    /* DLA - PMSTA-25243 - 170306 */
                                        response.setStatus(HTTP_STATUS_AND_TEXTC(retStatus));
                                        std::string tmp = SYS_Stringer("{ \"Error\":", retStatus, ", \"RPC\":\"", rpcName.constData(), "\", \"Message\":\"Error in RPC execution, see log file\", \"TA_RETCODE\":", rpcContextHttp.getTaRetCode(), "}");    /* DLA - PMSTA-25721 - 161219 */
                                        response.write(tmp.c_str(), true);
                                    }
                                }

                                if (rpcContextHttp.isRpcEndExecuted() == false)
                                {
                                    AAATracer::AAAScopedSpan finishSpan (AAATelemetry::GetTracer(AAATracer::TraceName::HttpServerDetailed).startNewSpan("rpcEnd"));

                                    SERV_RpcEnd(&rpcContextHttp);

                                }
                            }
                            else
                            {
                                int retStatus = rpcContextHttp.getHTTPStatusFromTaRetCode(); /* FME */
                                response.setStatus(HTTP_STATUS_AND_TEXTC(retStatus));
                                std::string errorText = SYS_Stringer("{ \"Error\":", retStatus, ", \"RPC\":\"", rpcName.constData(), "\", \"Message\":\"Invalid input parameters, see log file\", \"TA_RETCODE\":", rpcContextHttp.getTaRetCode(), "}");
                                response.write(errorText.c_str(), true);
                                MSG_SendMesg(FILEINFO, std::string("Invalid RPC input parameter: ") + qPrintable(rpcName));
                                SERV_RpcEnd(&rpcContextHttp);   /* DLA - PMSTA-25017 - 161013 */
                            }
                        }
                        if (rpcProperties.getRpcName().compare("create_appl_session_rpc") == 0 &&
                            rpcContextHttp.getApplSessionCd().empty() == false)
                        {
                            const QByteArray applSessionCd(rpcContextHttp.getApplSessionCd().c_str(), (int)rpcContextHttp.getApplSessionCd().length());

                            session.set("applSessionCd", applSessionCd);

                            /* PMSTA-34344 - TEB - 190805 */
                            if (httpServerAccessLogger.isTraceEnabled())
                            {
                                const std::string  sessCD = std::string("Put in session id : {") + session.getId().data() + std::string("} applSessionCd [") + applSessionCd.data() + std::string("] ");
                                std::ostringstream  loggingStream;
                                loggingStream << " HTTP_RpcExecutor : " << sessCD;
                                httpServerAccessLogger.trace(loggingStream.str());
                            }
                        }

                    }
                }
                else
                {
                    response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_SERVICE_UNAVAILABLE));
                    std::string tmp = SYS_Stringer("{ \"Error\":", HTTP_STATUS_SERVICE_UNAVAILABLE, ", \"RPC\":\"", rpcName.constData(), "\", \"Message\":\" not available, the financial server is in quarantine mode, no connection allowed\", \"TA_RETCODE\":", RET_SRV_GEN_ERR_STANDALONE, "}");
                    response.write(tmp.c_str(), true);
                    MSG_SendMesg(FILEINFO, std::string(rpcName + " is not available, the financial server is in quarantine mode, no connection allowed"));
                }
            }
            else
            {
                response.setHeader("Content-Type", "text/html; charset=ISO-8859-1");
                response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_NOT_FOUND));
                if (false == rpcProperties.isRoleAllowed())
                {
                    response.write("Error 404 RPC " + rpcName + " not allowed on this server", true);
                    MSG_SendMesg(FILEINFO, std::string("RPC call not allowed on this server: ") + qPrintable(rpcName));
                }
                else
                {
                    response.write("Error 404 RPC " + rpcName + " not found", true);
                    MSG_SendMesg(FILEINFO, std::string("Unknown RPC call: ") + qPrintable(rpcName));
                }
            }
        }
        catch (...)
        {
            internalError = true;
            exceptionHandler(FILEINFO, MSG_SendMesg);
        }
    }
    catch (...)
    {
        internalError = true;
        MSG_SendMesg(FILEINFO, std::string("RPC initial allocation failed: ") + qPrintable(rpcName));
    }

    if (true == internalError)
    {
        response.setHeader("Content-Type", "text/html; charset=ISO-8859-1");
        response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_INTERNAL_SERVER_ERROR));
        response.write("Error 500 RPC " + rpcName + " generate an exception, see log files", true);
    }
}

/************************************************************************
*   Function        :   HTTP_AuthenticationCore
*
*   Description     :   Verify the use credential versus AAA Realm
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
void HTTP_AuthenticationCore(RpcContext *rpcContext)
{
    RpcContextHttp *    rpcContextHttp = dynamic_cast<RpcContextHttp *>(rpcContext);
    RET_CODE            ret;

    try
    {
        // Open connection with dbo user
        DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
        MemoryPool     mp;
        DBA_DYNFLD_STP sApplUserTmp = mp.allocDynst(FILEINFO, S_ApplUser);
        DBA_DYNFLD_STP aApplUserTmp = mp.allocDynst(FILEINFO, A_ApplUser);
        bool 		   bFound = false;

        std::string userString((char*)rpcContextHttp->getAuthenticationUser()->data());

        SET_CODE(sApplUserTmp, S_ApplUser_Cd, userString.c_str());

        // Use connection as dbo to do the queries in appl_user & appl_user_password
        if ((ret = dbiConnHelper.dbaGet(ApplUser, UNUSED, sApplUserTmp, &aApplUserTmp)) == RET_SUCCEED)
        {
            if (GET_FLAG(aApplUserTmp, A_ApplUser_HasDbLoginFlg) == TRUE)
            {
                PasswordEncrypted*  _passEncypted = rpcContextHttp->getAuthenticationPwd();
                if (_passEncypted != nullptr && 
                    RET_SUCCEED == DBA_OpenConnForUser(rpcContextHttp->getAuthenticationUser()->constData(), *_passEncypted, nullptr, ROLE_USER))
                {
                    bFound = true;
                }
            }
            else
            {
                DBA_DYNFLD_STP aUserPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);
                DBA_DYNFLD_STP sUserPwdStp = mp.allocDynst(FILEINFO, S_ApplUserPassword);

                SET_ID(sUserPwdStp, S_ApplUserPassword_UserId, GET_ID(aApplUserTmp, A_ApplUser_Id));

                if ((ret = dbiConnHelper.dbaGet(ApplUserPassword, UNUSED, sUserPwdStp, &aUserPwdStp)) == RET_SUCCEED)
                {
                    char          *pMD5Password = NULL;
                    char       *pSHA256Password = NULL;
                    char    *pMD5SaltedPassword = NULL;
                    char           *pSHA256User = NULL;

                    // if user and password found, check with provided encrypted password
                    char *dbPasswordStr = GET_INFO(aUserPwdStp, A_ApplUserPassword_CryptedPassword);

                    if (dbPasswordStr != nullptr)
                    {
                        {
                            SYSNAME_T szPassword;
                            AUTO_PASSWORD_CLEAR(szPassword, sizeof(szPassword));
                            strcpy(szPassword, (char*)rpcContextHttp->getAuthenticationPwd()->getClearPassword().getPassword());

                            _CRYPT_HashMD5(szPassword, &pMD5Password);
                            _CRYPT_HashSHA256(szPassword, &pSHA256Password);
                            _CRYPT_HashMD5Salted(szPassword, pSHA256Password, &pMD5SaltedPassword);
                        }
                        switch ((PREFIX_ALGO_USED_ENUM)dbPasswordStr[0])
                        {
                        case PREFIX_ALGO_USED_ENUM::SALTED_MD5:
                                if (strcmp(pMD5SaltedPassword, dbPasswordStr + 1) == 0)
                                {
                                    bFound = true;
                                }
                                break;

                            case PREFIX_ALGO_USED_ENUM::SHA256:
                                if (strcmp(pSHA256Password, dbPasswordStr + 1) == 0)
                                {
                                    bFound = true;
                                }
                                break;

                            case PREFIX_ALGO_USED_ENUM::SALTED_SHA256:
                            {
                                SYSNAME_T szUser;
                                SYSNAME_T szPassword;
                                AUTO_PASSWORD_CLEAR(szPassword, sizeof(szPassword));
                                strcpy(szPassword, (char*)rpcContextHttp->getAuthenticationPwd()->getClearPassword().getPassword());

                                szUser[0] = 0;

                                if (IS_NULLFLD(aApplUserTmp, A_ApplUser_ThirdId) == FALSE)
                                {
                                    DBA_DYNFLD_STP sThird = mp.allocDynst(FILEINFO, S_Third);
                                    DBA_DYNFLD_STP aThird = mp.allocDynst(FILEINFO, A_Third);

                                    SET_ID(sThird, S_Third_Id, GET_ID(aApplUserTmp, A_ApplUser_ThirdId));

                                    if (dbiConnHelper.dbaGet(Third, UNUSED, sThird, &aThird) == RET_SUCCEED)
                                    {
                                        strcpy(szUser, GET_CODE(aThird, A_Third_Cd));
                                    }
                                }
                                else if (IS_NULLFLD(aApplUserTmp, A_ApplUser_ManagerId) == FALSE)
                                {
                                    DBA_DYNFLD_STP sMgr = mp.allocDynst(FILEINFO, S_Mgr);
                                    DBA_DYNFLD_STP aMgr = mp.allocDynst(FILEINFO, A_Mgr);

                                    SET_ID(sMgr, S_Mgr_Id, GET_ID(aApplUserTmp, A_ApplUser_ManagerId));

                                    if (dbiConnHelper.dbaGet(Mgr, UNUSED, sMgr, &aMgr) == RET_SUCCEED)
                                    {
                                        strcpy(szUser, GET_CODE(aMgr, A_Mgr_Cd));
                                    }
                                }
                                else
                                {
                                    strcpy(szUser, GET_CODE(aApplUserTmp, A_ApplUser_Cd));
                                }

                                if (szUser[0] != 0)
                                {
                                    char *pSHA256SaltedPassword = NULL;

                                    _CRYPT_HashSHA256(szUser, &pSHA256User);
                                    _CRYPT_HashSHA256Salted(szPassword, pSHA256User, &pSHA256SaltedPassword);

                                    if (strcmp(pSHA256SaltedPassword, dbPasswordStr + 1) == 0)
                                    {
                                        bFound = true;
                                    }

                                    FREE(pSHA256SaltedPassword);
                                }

                                break;
                            }

                            default:
                                if (strcmp(pMD5Password, dbPasswordStr) == 0)
                                {
                                    bFound = true;
                                }
                                break;
                        }

                        FREE(pMD5Password);
                        FREE(pSHA256Password);
                        FREE(pMD5SaltedPassword);
                        FREE(pSHA256User);

                        if (bFound)
                        {
                            rpcContext->setAAARealmUser(rpcContextHttp->getAuthenticationUser()->data());
                        }
                    }
                }
            }
        }

        if (bFound == false &&
            ret != RET_DBA_ERR_CONNOTFOUND &&
            ret != RET_DBA_ERR_CONNLOST)
        {
            SYS_SetThreadFatalError();

            if (rpcContextHttp->getDisplayHost().empty() == false)
            {
                RequestHelper requestHelper(dbiConnHelper);

                const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.CheckLoginFailed";
                    sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                }

                requestHelper.setCommand("#EXEC #AAALOGIN_DB.chk_login_failed ?, ?");
                requestHelper.addNewParamCharPtr(userString, SysnameType);
                requestHelper.addNewParam(FlagType);

                if (requestHelper.sendAndGetCommand() == RET_SUCCEED &&
                    requestHelper.getLastStatus())
                {
                    MSG_LogMesg(RET_DBA_ERR_LOGIN, 1, FILEINFO, userString.c_str());
                }

                requestHelper.finishRequest();

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsertLoginFailed";
                    sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                }

                requestHelper.setCommand("#EXEC #AAALOGIN_DB.ins_login_failed_by_cd ?, ?");
                requestHelper.addNewParamCharPtr(userString, SysnameType);
                requestHelper.addNewParamCharPtr(rpcContextHttp->getDisplayHost(), String1000Type);
                requestHelper.sendAndGetCommand();
            }
        }
    }
    catch (...)
    {
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }


}

/************************************************************************
*   Function        :   HTTP_Authentication
*
*   Description     :   verify the users credential in AAA model (appl_user_password...)
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
bool HTTP_Authentication(const HttpRequest& request, HttpSession & session, const QByteArray& user, PasswordEncrypted& pE)
{
    bool ret = false;

    try
    {
        AAATracer::AAAScopedSpan authSpan(AAATelemetry::GetTracer(AAATracer::TraceName::HttpServer).startNewSpan("HTTP_Authentication"));
        /*
         * Calling SYS_ExecuteThread was necessary to avoid HTTP connection leaks.
         * The free of login connection is done in the end thread code
         */
        QByteArray          name("HTTP_Authentication");
        const RpcProperties rpcProperties;
        ThreadFrame         threadFrame(HTTP_CreateThreadDescriptorWithHttpContext(request, name, rpcProperties, session));
        HttpResponse        response(nullptr);
        RpcContextHttp      rpcContextHttp(request, response);

        rpcContextHttp.setAuthenticationUserPwd(&user, &pE);

        ret = SYS_ExecuteThread(threadFrame.getThread(), HTTP_AuthenticationCore, &rpcContextHttp, "HTTP_Authentication");

        if (ret)
        {
            session.set("userId", user);

            if (rpcContextHttp.getAAARealmUser().empty())
            {
                session.set("password", pE.getPassword());
            }
            else
            {
                session.set("AAARealmUser", user);
            }
        }
    }
    catch (...)
    {
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }

    return ret;
}


/************************************************************************
*   Class        :   HttpServerListenerConfiguration
*
*************************************************************************/


HttpServerListenerConfiguration::HttpServerListenerConfiguration():
m_certificateFilePath(),
m_privateKeyFilePath(),
m_listeningInterface(),
m_listeningInterfaceName(), /* PMSTA - 32186 CMILOS 05032019 */
m_listeningExternalInterface(),
m_sslProtocolVersion(),
m_minThreads(1),
m_maxThreads(1),
m_cleanupIntervalsec(0),
m_readTimeoutSec(30),
m_maxRequestSize(1024 * 1024),
m_maxMultiPartSize(1024 * 1024),
m_stackSize(1024 * 1024),
m_listeningPort(0),
m_listeningExternalPort(0),
m_use_ssl(false),
m_mutual_tls(false),
m_use_external_ssl(false), /* PMSTA-30135 CMILOS 140219 */
m_needToStart(false)
{
}

HttpServerListenerConfiguration::~HttpServerListenerConfiguration()
{
}


QSettings* HttpServerListenerConfiguration::getQSettings(QObject * parent)
{
    QSettings * listenerSettings = new QSettings(AAAQCoreApplication::getInMemoryQSettingsFormat(AAAQCoreApplication::InMemoryConfigurationQSetting::listenerConfigurationQSetting), QSettings::UserScope, "", "", parent);;

    listenerSettings->setValue("port", getListeningPort());
    listenerSettings->setValue("host", getListeningInterface());
    listenerSettings->setValue("minThreads", getMinThreads());
    listenerSettings->setValue("maxThreads", getMaxThreads());
    if (this->isUse_ssl())
    {
        listenerSettings->setValue("sslKeyFile", getPrivateKeyFilePath());
        listenerSettings->setValue("sslCertFile", getCertificateFilePath());

		CryptoString sslPassword;
        PasswordEncrypted pE;

        RET_CODE ret_code = SYS_AutoLogin("sslKeyPassCode", pE);

        if (ret_code == RET_SUCCEED)
        {
            PasswordClear pass = pE.getClearPassword();
            auto password = pass.getPassword();
            listenerSettings->setValue("sslKeypassword", password);
        }
    }
    else
    {
        listenerSettings->remove("sslKeyFile");
        listenerSettings->remove("sslCertFile");
		listenerSettings->remove("sslKeypassword");

    }

	if (this->isMutual_tls())
	{
		listenerSettings->setValue("trustStoreFile", getTrustStoreFilePath());
	}
	else
	{
		listenerSettings->remove("trustStoreFile");
	}

    listenerSettings->setValue("cleanupInterval", getCleanupIntervalsec() * 1000);
    listenerSettings->setValue("readTimeout", getReadTimeoutSec() * 1000);
    listenerSettings->setValue("maxRequestSize", getMaxRequestSize());
    listenerSettings->setValue("maxMultiPartSize", getMaxMultiPartSize());
    listenerSettings->setValue("stackSize", getStackSize());
    listenerSettings->setValue("sslProtocolVersion",getSslProtocolVersion());

    QStringList	ak = listenerSettings->allKeys();

    return listenerSettings;

}


void HttpServerListenerConfiguration::setCertificateFilePath(const QString& certificateFilePath)
{
    m_certificateFilePath = certificateFilePath;
}
void HttpServerListenerConfiguration::setPrivateKeyFilePath(const QString& privateKeyFilePath)
{
    m_privateKeyFilePath = privateKeyFilePath;
}
void HttpServerListenerConfiguration::setTrustStoreFilePath(const QString& trustStoreFilePath)
{
	m_trustStoreFilePath = trustStoreFilePath;
}
void HttpServerListenerConfiguration::setMinThreads(int minThreads)
{
    m_minThreads = minThreads;
}
void HttpServerListenerConfiguration::setMaxThreads(int maxThreads)
{
    m_maxThreads = maxThreads;
}
void HttpServerListenerConfiguration::setCleanupIntervalsec(int cleanupIntervalsec)
{
    m_cleanupIntervalsec = cleanupIntervalsec;
}
void HttpServerListenerConfiguration::setReadTimeoutSec(int readTimeoutSec)
{
    m_readTimeoutSec = readTimeoutSec;
}
void HttpServerListenerConfiguration::setMaxRequestSize(int maxRequestSize)
{
    m_maxRequestSize = maxRequestSize;
}
void HttpServerListenerConfiguration::setMaxMultiPartSize(int maxMultiPartSize)
{
    m_maxMultiPartSize = maxMultiPartSize;
}
void HttpServerListenerConfiguration::setStackSize(int stackSize)
{
    m_stackSize = stackSize;
}
bool HttpServerListenerConfiguration::setListeningInterface(const QString& listeningInterface)
{
    /*< DLA - PMSTA-25079 - 161213 */
    bool         badHost = false;

    if (listeningInterface.isEmpty() == false ) /* PMSTA-30135 CMILOS 140219 */ /* PMSTA-58784-FME-20240927 localhost also treated in HTTP_CheckValidInterface */
    {
        if (HTTP_CheckValidInterface(listeningInterface, m_listeningInterface) == true)
        {
            if (m_listeningInterface.isEmpty())
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL_WARN, 7, FILEINFO, "listener.host=", listeningInterface.toLocal8Bit().constData(), "declared in aaa_srv.ini has more than 1 valid interface, listen any !");
            }
        }
        else
        {
            badHost = true;
        }
    }
    return badHost == false;
    /* DLA - PMSTA-25079 - 161213 >*/
}
void HttpServerListenerConfiguration::setListeningInterfaceName(const QString& listeningInterface) /* PMSTA - 32186 CMILOS 05032019 */
{
    m_listeningInterfaceName = listeningInterface;
}
void HttpServerListenerConfiguration::setListeningPort(int listeningPort)
{
    m_listeningPort = listeningPort;
}
void HttpServerListenerConfiguration::setListeningExternalInterface(const QString& listeningInterface)
{
    m_listeningExternalInterface = listeningInterface;
}
void HttpServerListenerConfiguration::setSslProtocolVersion(const QString& sslProtocolVersion)
{
    m_sslProtocolVersion = sslProtocolVersion;
}
void HttpServerListenerConfiguration::setListeningExternalPort(int listeningPort)
{
    m_listeningExternalPort = listeningPort;
}
void HttpServerListenerConfiguration::setUse_ssl(bool use_ssl)
{
    m_use_ssl = use_ssl;
}
void HttpServerListenerConfiguration::setMutual_tls(bool mutual_tls)
{
	m_mutual_tls = mutual_tls;
}
void HttpServerListenerConfiguration::setUse_external_ssl(bool use_ssl) /* PMSTA-30135 CMILOS 140219 */
{
    m_use_external_ssl = use_ssl;
}
void HttpServerListenerConfiguration::setNeedToStart(bool needToStart)
{
    m_needToStart = needToStart;
}
const QString& HttpServerListenerConfiguration::getCertificateFilePath() const
{
    return m_certificateFilePath;
}
const QString& HttpServerListenerConfiguration::getPrivateKeyFilePath() const
{
    return m_privateKeyFilePath;
}
const QString& HttpServerListenerConfiguration::getTrustStoreFilePath() const
{
	return m_trustStoreFilePath;
}
int HttpServerListenerConfiguration::getMinThreads() const
{
    return m_minThreads;
}
int HttpServerListenerConfiguration::getMaxThreads() const
{
    return m_maxThreads;
}
int HttpServerListenerConfiguration::getCleanupIntervalsec() const
{
    return m_cleanupIntervalsec;
}
int HttpServerListenerConfiguration::getReadTimeoutSec() const
{
    return m_readTimeoutSec;
}
int HttpServerListenerConfiguration::getMaxRequestSize() const
{
    return m_maxRequestSize;
}
int HttpServerListenerConfiguration::getMaxMultiPartSize() const
{
    return m_maxMultiPartSize;
}
int HttpServerListenerConfiguration::getStackSize() const
{
    return m_stackSize;
}
const QString& HttpServerListenerConfiguration::getListeningInterface() const
{
    return m_listeningInterface;
}
const QString& HttpServerListenerConfiguration::getListeningInterfaceName() const /* PMSTA - 32186 CMILOS 05032019 */
{
    return m_listeningInterfaceName;
}
int HttpServerListenerConfiguration::getListeningPort() const
{
    return m_listeningPort;
}
const QString& HttpServerListenerConfiguration::getListeningExternalInterface() const
{
    return m_listeningExternalInterface;
}
const QString& HttpServerListenerConfiguration::getSslProtocolVersion() const
{
    return m_sslProtocolVersion;
}
int HttpServerListenerConfiguration::getListeningExternalPort() const
{
    return m_listeningExternalPort;
}
bool HttpServerListenerConfiguration::isUse_ssl() const
{
    return m_use_ssl;
}
bool HttpServerListenerConfiguration::isMutual_tls() const
{
	return m_mutual_tls;
}
bool HttpServerListenerConfiguration::isUse_external_ssl() const /* PMSTA-30135 CMILOS 140219 */
{
    return m_use_external_ssl;
}
bool HttpServerListenerConfiguration::isNeedToStart() const
{
    return m_needToStart;
}


/************************************************************************
*   Class        :   HttpServerSessionConfiguration
*
*************************************************************************/


HttpServerSessionConfiguration::HttpServerSessionConfiguration():
m_cookieName(),
m_cookiePath(),
m_cookieComment(),
m_cookieDomain(),
m_RealmName(),
m_expirationTimeSec(365 * 24 * 3600),  /* PMSTA-25008 - LJE - 161012 - To modify... */
m_cookieSecure(true)
{
}

HttpServerSessionConfiguration::~HttpServerSessionConfiguration()
{
}

QSettings* HttpServerSessionConfiguration::getQSettings(QObject * parent)
{
    QSettings * sessionSettings = new QSettings(AAAQCoreApplication::getInMemoryQSettingsFormat(AAAQCoreApplication::InMemoryConfigurationQSetting::sessionConfigurationQSetting), QSettings::UserScope, "", "", parent);;

    sessionSettings->setValue("expirationTime", getExpirationTimeSec());
    sessionSettings->setValue("cookieName", getCookieName());
    sessionSettings->setValue("cookiePath", getCookiePath());
    sessionSettings->setValue("cookieComment", getCookieComment());
    sessionSettings->setValue("cookieDomain", getCookieDomain());
    sessionSettings->setValue("cookieSecure", isCookieSecure());
    sessionSettings->setValue("realmName", getRealmName());

    QStringList	ak = sessionSettings->allKeys();

    return sessionSettings;
}

int HttpServerSessionConfiguration::getExpirationTimeSec() const
{
    return m_expirationTimeSec;
}
void HttpServerSessionConfiguration::setExpirationTimeSec(int expirationTimeSec)
{
    m_expirationTimeSec = expirationTimeSec;
}
const QString& HttpServerSessionConfiguration::getCookieName() const
{
    return m_cookieName;
}
void HttpServerSessionConfiguration::setCookieName(const QString& cookieName)
{
    m_cookieName = cookieName;
}
const QString& HttpServerSessionConfiguration::getCookiePath() const
{
    return m_cookiePath;
}
void HttpServerSessionConfiguration::setCookiePath(const QString& cookiePath)
{
    m_cookiePath = cookiePath;
}
const QString& HttpServerSessionConfiguration::getCookieComment() const
{
    return m_cookieComment;
}
void HttpServerSessionConfiguration::setCookieComment(const QString& cookieComment)
{
    m_cookieComment = cookieComment;
}
const QString& HttpServerSessionConfiguration::getCookieDomain() const
{
    return m_cookieDomain;
}
void HttpServerSessionConfiguration::setCookieDomain(const QString& cookieDomain)
{
    m_cookieDomain = cookieDomain;
}
bool HttpServerSessionConfiguration::isCookieSecure() const
{
    return m_cookieSecure;
}
void HttpServerSessionConfiguration::setCookieSecure(bool cookieSecure)
{
    m_cookieSecure = cookieSecure;
}
const QString& HttpServerSessionConfiguration::getRealmName() const
{
    return m_RealmName;
}
void HttpServerSessionConfiguration::setRealmName(const QString& realmName)
{
    m_RealmName = realmName;
}


/************************************************************************
*   Function        :   HttpServer::HttpServer
*
*   Description     :   Constructor
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
HttpServer::HttpServer(AAAQCoreApplication * qtCoreApplication, const QString& serverName):
m_ServerName(serverName),
m_QtCoreApplication(qtCoreApplication),
m_HttpListener(nullptr),
m_RequestMapper(nullptr)
{
}


/************************************************************************
*   Function        :   HttpServer::~HttpServer
*
*   Description     :   Destructor
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :   PMSTA-34824 - 210219 - PMO : Regression: several core file generated while running the TaAutomator night batch (HttpConnectionHandler)
*   Last Modif.     :   PMSTA-47004 - FME - 20211116 : Put again deleteLater as in sometimes (e.g dict_entity has changed ) QT complains with fatal erors (QThread: Destroyed while thread is still running)
*                                                      m_HttpListener contains pool of HttpConnectionHandler (subclass of QThread).
*
*************************************************************************/
HttpServer::~HttpServer()
{
    if (nullptr != m_HttpListener)
    {
        m_HttpListener->deleteLater(); /* PMSTA-47004 - FME - 20211116 */
        m_HttpListener = nullptr;
    }
    if (nullptr != m_RequestMapper)
    {
        m_RequestMapper->deleteLater();
        m_RequestMapper = nullptr;
    }
}

/************************************************************************
*   Function        :   HttpServer::configure
*
*   Description     :   Configure the HTTP server
*
*   Arguments       :
*
*   Return          :   true    ok
*                       false   failed to start the http server
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
bool HttpServer::configure()
{
    /* HTTP server might have a configuration file */
    (void)m_HttpServerFileConfiguration.load();

    HttpServerSessionConfiguration sessionStoreConfiguration;
    init(sessionStoreConfiguration);

    m_RequestMapper = new RequestMapper();

    m_RequestMapper->configureSessionStore(sessionStoreConfiguration);

    init(this->m_ListenerConfiguration);

    if (this->m_ListenerConfiguration.isNeedToStart())
    {
        QSettings* listenerSettings = this->m_ListenerConfiguration.getQSettings(m_QtCoreApplication);

        m_HttpListener = new HttpListener(listenerSettings, m_RequestMapper);

        bool isListening = m_HttpListener->isListening();
        if (isListening)
        {
            /* PMSTA-24563 - LJE - 160914 */
            int desired_port = this->m_ListenerConfiguration.getListeningPort();
            int effective_port = m_HttpListener->serverPort();
            int externalPort = this->m_ListenerConfiguration.getListeningExternalPort(); /* DLA - PMSTA-24842 - 160927 */

            if (externalPort > 0 && desired_port == 0) /* DLA - PMSTA-24842 - 160927 */
            {
                MSG_SendMesg(FILEINFO, std::string("aaa_srv.ini: can not specify an listener.external_port without listener.port<>0") );
                return false;
            }

            SCHEME_ENUM scheme = this->m_ListenerConfiguration.isUse_ssl() ? Scheme_Https : Scheme_Http;
            SCHEME_ENUM external_scheme = this->m_ListenerConfiguration.isUse_external_ssl() ? Scheme_Https : Scheme_Http; /* PMSTA-30135 CMILOS 140219 */

            /* DLA - PMSTA-24842 - 160927 */
            std::string externalHost = this->m_ListenerConfiguration.getListeningExternalInterface().toLocal8Bit().constData();
            std::string configFileHost = this->m_ListenerConfiguration.getListeningInterface().toLocal8Bit().constData();
            std::string configFileHostName = this->m_ListenerConfiguration.getListeningInterfaceName().toLocal8Bit().constData(); /* PMSTA - 32186 CMILOS 05032019 */

            if (configFileHost.size() > 0) /* DLA - PMSTA-24842 - 160927 */
            {
                EV_CurrentSrvConfig.setHost(configFileHost);
            }

            /* PMSTA - 32186 CMILOS 05032019 */
            if (configFileHostName.size() > 0)
            {
                EV_CurrentSrvConfig.setHostName(configFileHostName);
            }

            EV_CurrentSrvConfig.setPort(effective_port);
            EV_CurrentSrvConfig.setScheme(scheme);
            EV_CurrentSrvConfig.setExternalScheme(external_scheme); /* PMSTA-30135 CMILOS 140219 */

            EV_CurrentSrvConfig.setExternalHost(externalHost); /* DLA - PMSTA-24842 - 160927 */
            EV_CurrentSrvConfig.setExternalPort(externalPort);

        }
        return isListening;
    }
    else
    {
        return false;  // Must not start
    }
}

/************************************************************************
*   Static variable :   AAAQCoreApplication::DISP
*
*   Description     :   Dump the content fo a QSettings
*
*************************************************************************/

void AAAQCoreApplication::DISP(QSettings* settings){

    std::stringstream  	bufStream;

    QStringList	ak = settings->allKeys();

    QStringList::const_iterator constIterator;

    bufStream << "size =" << ak.count() << "\n";

    for (constIterator = ak.constBegin(); constIterator != ak.constEnd(); ++constIterator){
        const QString k = (*constIterator);
        const QVariant   v = settings->value(k);
        bufStream << "k=" << k.toLatin1().constData() << " v=" << v.toByteArray().constData();
        bufStream << "\n";
    }
    bufStream << "\n";

    AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
}


void AAAQCoreApplication::DISP(const QSettings::SettingsMap &map)
{
    std::stringstream  	bufStream;
    QSettings::SettingsMap::ConstIterator  constIterator;

    bufStream << "size =" << map.count() << "\n";

    for (constIterator = map.constBegin(); constIterator != map.constEnd(); ++constIterator){
        const QString k = constIterator.key();
        const QVariant v = constIterator.value();
        bufStream << "k=" << k.toLatin1().constData() << " v=" << v.toByteArray().constData();
        bufStream << "\n";
    }
    bufStream << "\n";

    AAA_RPT0(_CRT_WARN, bufStream.str().c_str());

}

/************************************************************************
*   Function        :   AAAQCoreApplication::AAAQCoreApplication
*
*   Description     :   constructor of the AAAQCoreApplication, call QCoreApplication constructor
*
*   Arguments       :
*
*   Last Modif.     : DLA - PMSTA25072 - 161019
*
*************************************************************************/
AAAQCoreApplication::AAAQCoreApplication(int &argc, char **argv): QCoreApplication(argc, argv)
{
    AAAQCoreApplication::m_inMemoryQSettingsFormat[AAAQCoreApplication::InMemoryConfigurationQSetting::listenerConfigurationQSetting] =
        QSettings::registerFormat("none1", readQSettingNone, writeQSettingNone);
    AAAQCoreApplication::m_inMemoryQSettingsFormat[AAAQCoreApplication::InMemoryConfigurationQSetting::sessionConfigurationQSetting] =
        QSettings::registerFormat("none3", readQSettingNone, writeQSettingNone);
}

/************************************************************************
*   Static variable :   AAAQCoreApplication::m_inMemoryQSettingsFormat
*
*   Description     :   contains a way to not persist Qsetting to transfer data to QtWebApp
*
*
*************************************************************************/

QSettings::Format  AAAQCoreApplication::m_inMemoryQSettingsFormat[2];

/************************************************************************
*   Static variable :   AAAQCoreApplication::getInMemoryQSettingsFormat
*
*   Description     :   return the QSettings::Format to not persist Qsetting
*
*************************************************************************/

const QSettings::Format& AAAQCoreApplication::getInMemoryQSettingsFormat(AAAQCoreApplication::InMemoryConfigurationQSetting config)
{
    return AAAQCoreApplication::m_inMemoryQSettingsFormat[config];
}

/************************************************************************
*   Static variable :   AAAQCoreApplication::readQSettingNone
*
*   Description     :   dummy reader to not persist Qsetting
*
*************************************************************************/

bool AAAQCoreApplication::readQSettingNone(QIODevice &, QSettings::SettingsMap & /*map*/)
{
    // AAAQCoreApplication::DISP(map);
    return true;
}

/************************************************************************
*   Static variable :   AAAQCoreApplication::writeQSettingNone
*
*   Description     :   dummy writer to not persist Qsetting
*
*************************************************************************/

bool AAAQCoreApplication::writeQSettingNone(QIODevice &, const QSettings::SettingsMap & /*map*/)
{
    // AAAQCoreApplication::DISP(map);
    return true;
}


/************************************************************************
*   Function        :   AAAQCoreApplication::HTTP_StartServerHandler()
*
*   Description     :   Complete the initialisation of aaa_srv when the HTTP server is running
*
*   Arguments       :
*
*   Last Modif.     : DLA - PMSTA25072 - 161019
*                     PMSTA-25090 - 191016 - PMO : Fusion not completing with HttpConnectionHandler problem
*                     PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
void AAAQCoreApplication::HTTP_StartServerHandler()
{
    FLAG_T   fusionServer = FALSE,
        dispatchServer = FALSE,
        financialServer = FALSE,
        reportServer = FALSE,
        proxyServer = FALSE;
    ID_T busEntityId = ZERO_ID;
    std::string msg;


    /*** BEGIN DVP070 ***/
    if ((SERV_GetServerInfo(A_ServConnect_DispatchFlg, &dispatchServer) != RET_SUCCEED) ||
        (SERV_GetServerInfo(A_ServConnect_FusionFlg, &fusionServer) != RET_SUCCEED) ||
        (SERV_GetServerInfo(A_ServConnect_FinancialFlg, &financialServer) != RET_SUCCEED) ||
        (SERV_GetServerInfo(A_ServConnect_ReportFlg, &reportServer) != RET_SUCCEED) ||
        (SERV_GetServerInfo(A_ServConnect_ProxyServFlg, &proxyServer) != RET_SUCCEED) ||
        (SERV_GetServerInfo(A_ServConnect_BusEntityId, &busEntityId) != RET_SUCCEED))
    {
        msg = "Cannot get server_connect record.";
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
        msg += " Not ";         /* Not Ok to log */
        printf(msg.c_str());
        quit();
    }
    /*** END  DVP070 ***/
    /* TGU - PMSTA 13754 - 120223 - No Role defined in server_connect means no financial server :) */
    if (dispatchServer == FALSE && fusionServer == FALSE &&  financialServer == FALSE && reportServer == FALSE && proxyServer == FALSE)
    {
        msg = "At least one Role must be defined in server_connect.";
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
        msg += " Not ";         /* Not Ok to log */
        printf(msg.c_str());
        quit();
    }
    /* PMSTA-40887 - JBC - 200718 */
    if(dispatchServer == TRUE && !GEN_UseDispatcher())
    {
        msg = "Server Cannot have Dispatcher Role when USE_DISPATCHER_FLAG=0.";
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
        msg += " Not ";         /* Not Ok to log */
        printf(msg.c_str());
        quit();
    }

    if(GEN_IsMultiEntity() &&  dispatchServer == TRUE && busEntityId != ZERO_ID)
    {
        msg = "Server Cannot have a Dispatcher Role and a specified Business Entity.";
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
        msg += " Not ";         /* Not Ok to log */
        printf(msg.c_str());
        quit();
    }

    /* check integrity of disp / no disp */
    if(fusionServer == TRUE && dispatchServer == FALSE)
    {
        MemoryPool          mp;
        DBA_DYNFLD_STP      servConnectSt = mp.allocDynst(FILEINFO, S_ServConnect);
        DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_ADMIN);
        /* get_sh_dispatch_server */
        RET_CODE ret = dbiConnHelper.dbaGet(ServConnect, UNUSED, nullptr, &servConnectSt);

        if(GEN_UseDispatcher() && ret != RET_SUCCEED)
        {
            msg = "Server with Dispatcher Role must exist in server_connect when USE_DISPATCHER_FLAG=1.";
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
            msg += " Not ";         /* Not Ok to log */
            printf(msg.c_str());
            quit();
        }

        if(!GEN_UseDispatcher() && ret == RET_SUCCEED)
        {
            msg = "Server with Dispatcher Role cannot exist in server_connect when USE_DISPATCHER_FLAG=0.";
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,msg.c_str());
            msg += " Not ";         /* Not Ok to log */
            printf(msg.c_str());
            quit();
        }
    }


    if (SYS_GetEnv("AAATESTFUSION") != NULL)
    {
        fusionServer = TRUE;
    }

    if ((TRUE == dispatchServer) || (GEN_UseDispatcher() == false))  /* PMSTA-32293 - DLA - 180924 */
    {
        /* PMSTA-26764 - 230317 - PMO
         * Conditional start of technical dispatcher server thread
         */
        if (GEN_UseDispatcher() == true)
        {
            SYS_SpawnAdministrativeThread(SERV_StartAllThreadDispatcher, nullptr, "Starting dispatcher threads");
        }
		/*
		 * Dispatcher must launch tax lot thread
		 *  Cluster launches active fusion and tax lot
		 */
        SYS_SpawnAdministrativeThread(SERV_StartAllThreadCluster, nullptr, "Starting  active cluster threads");
    }
    else
    {
        /**** BEGIN DVP196 ****/
        /* Allocate a service thread which will send a notification to the dispatch server */
        if ((fusionServer == TRUE) && SYS_GetEnv("AAATESTFUSION") == NULL)
        {
            ThreadArgId *serverId = new ThreadArgId();
            SERV_GetServerInfo(A_ServConnect_Id, &serverId->idValue);

            SYS_SpawnAdministrativeThread(SERV_SendNotifToDispatch, serverId, "Send Notification To Dispatcher");
        }
    }

    SERV_SetStartedServer();
    SERV_SetRpcRegistered();    /* PMSTA-25090 - 191016 - PMO */


#ifdef AAAPURIFY
    PurifyNewLeaks();
#endif

}


/************************************************************************
*   Function        :   HttpServer::start
*
*   Description     :   Start the HTTP server
*
*   Arguments       :
*
*   Return          :   the value set to exit()  (which is 0 if exit() is called via quit()).
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
int HttpServer::start()
{
    if (nullptr == m_HttpListener)
    {
        printf("- HTTP Server NOT started... %s\n", Console::ColorizeError("FAILED").c_str());
        return 114; // Exit code-- The Server must not run
    }
    else
    {
        std::string  serverName;
        GEN_GetApplInfo(ApplServerName, serverName);

        printf("- Server Initialization (name:%s)... ", serverName.c_str());

        printf("%s\n- Callback Initialization... ", Console::ColorizeOk("ok").c_str());
        /* DLA - PMSTA25072 - 161019 */
        QTimer::singleShot(0, m_QtCoreApplication, SLOT(HTTP_StartServerHandler()));

        /* Start the HTTP server thread */
        printf("%s\n- HTTP Server starting... ", Console::ColorizeOk("ok").c_str());

        int execStatus = m_QtCoreApplication->exec();
        return execStatus;
    }
}

/************************************************************************
*   Function        :   HttpServer::stopInProgress
*
*   Description     :   Stop the HTTP server listener
*
*************************************************************************/
void HttpServer::stopInProgress()
{
    if (nullptr != m_HttpListener)
    {
        m_HttpListener->close();
    }
}

/************************************************************************
*   Function        :   HttpServer::init
*
*   Description     :   init the HttpServerSessionConfiguration
*
*   Arguments       :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/

void HttpServer::init(HttpServerSessionConfiguration& sessionConfig)
{

    QSettings * sessionSettings = new QSettings(m_HttpServerFileConfiguration.getRefConfigFileName(), QSettings::IniFormat, m_QtCoreApplication);
    sessionSettings->beginGroup("sessions"); /* DLA - PMSTA-24715 - 160909 */

    sessionConfig.setExpirationTimeSec(sessionSettings->value("expirationTime", sessionConfig.getExpirationTimeSec()).toInt()); /* DLA - PMSTA-24715 - 160909 */
    sessionConfig.setCookieName(sessionSettings->value("cookieName", "sessionid").toString());
    sessionConfig.setCookiePath(sessionSettings->value("cookiePath", "/").toString());           /* PMSTA-49856 - FME - 2022-07-18 Cookie must be set as top level */
    sessionConfig.setCookieComment(sessionSettings->value("cookieComment", "").toString());
    sessionConfig.setCookieDomain(sessionSettings->value("cookieDomain", "").toString());
    sessionConfig.setCookieSecure(sessionSettings->value("cookieSecure", false).toBool());
    sessionConfig.setRealmName(sessionSettings->value("realmName", "").toString());


    // AAAQCoreApplication::DISP(sessionSettings);

}

/************************************************************************
*   Function        :   HttpServer::init
*
*   Description     :   init the HttpServerListenerConfiguration
*
*   Arguments       :
*
*   Creation Date   :
*
*   Last Modif.     :   PMSTA-36212 - 160719 - PMO : Call stack crash while evaluating large input control in the server
*
*************************************************************************/
void HttpServer::init(HttpServerListenerConfiguration& listenerConfig)
{
    QSettings  listenerSettings(m_HttpServerFileConfiguration.getRefConfigFileName(), QSettings::IniFormat, m_QtCoreApplication);
    QSettings  serverSettings(m_HttpServerFileConfiguration.getRefConfigFileName(), QSettings::IniFormat, m_QtCoreApplication);

    QStringList groups = serverSettings.childGroups();
    bool serverDefined = groups.contains(m_ServerName);
    bool needSSLcertificates = false;
	bool mutualTLSrequired = false;

    if (serverDefined)
    {
        serverSettings.beginGroup(m_ServerName);
        bool portDefined;
        bool externalPortDefined;
        int port = serverSettings.value("listener.port", 0).toInt(&portDefined);
        int external_port = serverSettings.value("listener.external_port", 0).toInt(&externalPortDefined);
        if (listenerConfig.setListeningInterface(serverSettings.value("listener.host").toString()) == false) /* DLA - PMSTA-25079 - 161213 */
        {
            /* No valid interface found for the hostname given*/
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "listener.host=", serverSettings.value("listener.host").toString().toLocal8Bit().constData(), "declared in aaa_srv.ini is invalid or doesn't use valid adapter");
            SYS_Shutdown(EXIT_FAILURE);        /* DLA - PMSTA-26546 - 170314 */
        }
        else
        {
            listenerConfig.setListeningInterfaceName(serverSettings.value("listener.host").toString()); /* PMSTA - 32186 CMILOS 05032019 */
        }

        listenerConfig.setListeningExternalInterface(serverSettings.value("listener.external_host").toString());

        listenerConfig.setListeningPort(port);
        listenerConfig.setListeningExternalPort(external_port);
        bool internalSSLrequired = serverSettings.value("listener.ssl", false).toBool();
        listenerConfig.setUse_ssl(internalSSLrequired);
        if (internalSSLrequired)
        {
            needSSLcertificates = true;
        }
        /* PMSTA-30135 CMILOS 140219 */
        if (serverSettings.value("listener.external_ssl").toString().isEmpty())
        {
            /* use the internal scheme setting when external setting is not defined */
            listenerConfig.setUse_external_ssl(serverSettings.value("listener.ssl", false).toBool());
        }
        else
        {
            listenerConfig.setUse_external_ssl(serverSettings.value("listener.external_ssl", false).toBool());
        }
        bool interfaceDisabled = serverSettings.value("listener.disabled", false).toBool();
        listenerConfig.setNeedToStart(!interfaceDisabled);
        if (interfaceDisabled) {
            AAALogger::get(AAALogger::Logger::Configuration).info("Interface disabled by configuration for <" + std::string(m_ServerName.toLocal8Bit().data()) + "> ");
        }

		mutualTLSrequired = serverSettings.value("listener.mutualTLS", false).toBool();
		listenerConfig.setMutual_tls(mutualTLSrequired);
    }
    else
    {
        AAALogger::get(AAALogger::Logger::Configuration).info("No entry for <" + std::string(m_ServerName.toLocal8Bit().data()) + "> found in configuration");

        listenerConfig.setNeedToStart(false);
    }

    listenerSettings.beginGroup("listener");

	if (mutualTLSrequired)
	{
		const std::string  trustStoreFileName = listenerSettings.value("trustStore").toString().toLocal8Bit().constData();
		std::string trustStoreFilefullPath;
		SYS_GetAbsoluteFilePath(trustStoreFileName, trustStoreFilefullPath, /*relativeToAAAHome*/ true);
		if (SYS_FileExists(trustStoreFilefullPath.c_str()))
		{
			listenerConfig.setTrustStoreFilePath(QString(trustStoreFilefullPath.c_str()));
		}
		else
		{
			std::ostringstream osstls;
			osstls << "In Mutual TLS 'trustStore' entry not valid in config: " << trustStoreFilefullPath << ";";
			MSG_SendMesg(RET_ENV_ERR_WRONGCONFIG, 1, FILEINFO, osstls.str().c_str());

			AAALogger::get(AAALogger::Logger::HttpServer).fatal(osstls.str());
			SYS_Shutdown(EXIT_FAILURE);
		}
	}

    bool certificateDefined = false;
    bool privateKeyDefined = false;

    const std::string  certificateFileName = listenerSettings.value("certificate").toString().toLocal8Bit().constData();
    std::string certificateFilefullPath;
    SYS_GetAbsoluteFilePath(certificateFileName, certificateFilefullPath, /*relativeToAAAHome*/ true);
    if (SYS_FileExists(certificateFilefullPath.c_str()))
    {
        certificateDefined = true;
        listenerConfig.setCertificateFilePath(QString(certificateFilefullPath.c_str()));
    }
    const std::string  privateKeyFileName = listenerSettings.value("privateKey").toString().toLocal8Bit().constData();
    std::string privateKeyFilefullPath;
    SYS_GetAbsoluteFilePath(privateKeyFileName, privateKeyFilefullPath, /*relativeToAAAHome*/ true);

    if (SYS_FileExists(privateKeyFilefullPath.c_str()))
    {
        privateKeyDefined = true;
        listenerConfig.setPrivateKeyFilePath(QString(privateKeyFilefullPath.c_str()));
    }

    // Fetch sslProtocolVersion from config file and if not defined select only the secured one
    std::string  sslProtocolVersion = listenerSettings.value("sslProtocolVersion").toString().toLocal8Bit().constData(); /* PMSTA-47921 Sudeep 29092022 */
    if (sslProtocolVersion.length() == 0)
    {
        sslProtocolVersion = "TlsV1_2OrLater"; /* PMSTA-48672 -FME- 2022-01-22 */
    }
    listenerConfig.setSslProtocolVersion(QString(sslProtocolVersion.c_str()));

    if (needSSLcertificates && !(certificateDefined && privateKeyDefined))
    {
        std::ostringstream oss;
        oss << "SSL config not correct: ";
        if (!certificateDefined)
        {
            oss << " 'certificate' entry not valid in config: " << certificateFilefullPath << ";";
        }
        if (!privateKeyDefined)
        {
            oss << " 'privateKey' entry  not valid  in config: " << privateKeyFilefullPath << ";";
        }
        MSG_SendMesg(RET_ENV_ERR_WRONGCONFIG, 1, FILEINFO, oss.str().c_str());

        AAALogger::get(AAALogger::Logger::HttpServer).fatal(oss.str());
        SYS_Shutdown(EXIT_FAILURE);        /* DLA - PMSTA-26546 - 170314 */
    }
    if (needSSLcertificates)
    {
        bool sslSupportedByQT = QSslSocket::supportsSsl(); // This force the loading of libssl & libcrypt  cf qt5/qtbase/src/network/ssl/qsslsocket_openssl.cpp
        std::ostringstream oss;

        oss << "QSslSocket config: supportsSsl=" << sslSupportedByQT;

#if (QT_VERSION >= QT_VERSION_CHECK(5, 0, 0))
        oss << " sslLibraryBuildVersion=" << QSslSocket::sslLibraryBuildVersionString().toLocal8Bit().constData()
            << " sslLibraryVersionString=" << QSslSocket::sslLibraryVersionString().toLocal8Bit().constData();
#endif

        AAALogger::get(AAALogger::Logger::HttpServer).info(oss.str());

        // PMSTA-44253 2021-03-12 FME: fails if ssl is not supported but required, to avoid further errors afterwards in https communication
        if (false == sslSupportedByQT)
        {
            std::string fatalErrorMessage = "Fatal SSL required by config, but unavailable within QT (hint on unix check LD_LIBRARY_PATH to lookup libssl & libcrypt) " + oss.str();

            MSG_SendMesg(RET_ENV_ERR_WRONGCONFIG, 1, FILEINFO, fatalErrorMessage.c_str());

            AAALogger::get(AAALogger::Logger::HttpServer).fatal(fatalErrorMessage);
            SYS_Shutdown(EXIT_FAILURE);
        }

    }

    // @TODO LJE get it from serverConnect
    INT_T cleanUp, realTimeout;
    SMALLINT_T minThread, maxThread;

    SERV_GetServerInfo(A_ServConnect_MinConnection, &minThread);
    if (minThread == 0)
    {
        minThread = 1;
    }
    SERV_GetServerInfo(A_ServConnect_MaxConnect, &maxThread);
    if (maxThread == 0)
    {
        maxThread = 50;
    }
    SERV_GetServerInfo(A_ServConnect_ThreadCleanupIntervalS, &cleanUp);
    if (cleanUp == 0)
    {
        cleanUp = 60;
    }
    SERV_GetServerInfo(A_ServConnect_ReadTimeoutS, &realTimeout);
    if (realTimeout == 0)
    {
        realTimeout = 180; /* PMSTA-38708 - FME - 20200124 */
    }
    listenerConfig.setMinThreads(minThread);
    listenerConfig.setMaxThreads(maxThread);
    listenerConfig.setCleanupIntervalsec(cleanUp);
    listenerConfig.setReadTimeoutSec(realTimeout);


    int maxRequestSize = static_cast<int>(SYS_GetEnvSizeOrDefValue("AAAHTTPMAXREQUESTSIZE", 10000000));
    listenerConfig.setMaxRequestSize(maxRequestSize);

    int maxMultipartSize = static_cast<int>(SYS_GetEnvSizeOrDefValue("AAAHTTPMAXMULTIPARTSIZE", 10000000));
    listenerConfig.setMaxMultiPartSize(maxMultipartSize);

    listenerConfig.setStackSize(static_cast<int>(SYS_GetStackSize()));      /* PMSTA-36212 - 160719 - PMO */

}


/************************************************************************
*   Function        :   HttpServer::getQtCoreApplication
*
*   Description     :   Get The QT application
*
*   Arguments       :
*
*   Return          :   The QT application
*
*   Creation Date   :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*   Last Modif.     :
*
*************************************************************************/
AAAQCoreApplication * HttpServer::getQtCoreApplication()
{
    return m_QtCoreApplication;
}


/************************************************************************
*   Function        :   Http_ReadRpcParameters
*
*   Description     :   Get the Http request parameters and add then in rpcContextHttp
*
*   Arguments       :   HttpRequest& request, RpcContextHttp&  rpcContextHttp
*
*   Return          :   true if  param are set or no param
*
*   Last Modif.     :   PMSTA-32235 - 160519 - PMO : KD-5627 - Provide the possibility to export objects and packages from the GUI
*                       PMSTA-49293 - 2022-06-23 - FME 
*
* ************************************************************************/
bool Http_ReadRpcParameters(HttpRequest& request, RpcContextHttp&  rpcContextHttp, const RpcProperties& rpcProperties)
{
    std::string msgStr;
    bool        ret              = true;
    QByteArray  bodyData         = request.getBody();
    bool        emptyParamNeeded = false;
    bool        bRpcInputArgSet  = false;   /* PMSTA-28698 - LJE - 180622 */
    RET_CODE    inputResult      = RET_SUCCEED;

    if (bodyData.data() != nullptr &&
        bodyData.data()[0] != END_OF_STRING &&
        /* PMSTA-46148 - LJE - 210909 */
        rpcProperties.getArgDynStEnum() != NullDynSt)
    {
        BuildBindOption buildBindOption(BuildBindOption::Categ::MdAttribute);
        ReaderParserRapidJson jParser(buildBindOption, &rpcContextHttp.getMemoryPool());

        jParser.parse(bodyData.data());
        if (jParser.getCurrDynNbr() > 0)
        {
            jParser.setNextResultSet();

            if (rpcProperties.getArgDynStEnum() == jParser.getCurrDataDynStEn() ||
                rpcProperties.getRequestDynStEnum() == jParser.getCurrDataDynStEn())
            {
                jParser.buildBindMapFromRpc(rpcProperties, jParser.getCurrDataDynStEn());
                
                inputResult = rpcContextHttp.setRpcInputArg(jParser.getNextDynStp(ReaderParser::MEMORY_OWNED_BY::Requester));
                ret = (inputResult == RET_SUCCEED);
                if (inputResult == RET_DBA_ERR_CANNOTCONNECT)  /* PMSTA-49293 - FME - 2022-06-23 */
                {
                    rpcContextHttp.setTaRetCode(inputResult);
                    msgStr = "Unauthorized RPC input parameter: " + rpcProperties.getRpcName();
                }

                bRpcInputArgSet = true;
            }
        }

        if (jParser.isError())
        {
            msgStr = "Invalid RPC input parameter: " + rpcProperties.getRpcName();

            for (size_t idxError = 0; idxError < jParser.nbError(); idxError++)
            {
                msgStr += "\n";
                msgStr += jParser.getError(idxError);
            }
            ret = false;
        }
    }
    else if (rpcProperties.getProcInfo() == nullptr ||
             rpcProperties.getProcInfo()->procParamDefPtr == nullptr ||
             rpcProperties.getProcInfo()->procParamDefPtr[0].fldNbrPtr == UNUSED)
    {
        emptyParamNeeded = true;
        ret = true;
    }
    else    /* DLA - PMSTA-27552 - 170717 */
    {
        bool mandatoryParam = false;
        for (int i = 0; rpcProperties.getProcInfo()->procParamDefPtr[i].fldNbrPtr != UNUSED; i++)
        {
            if (rpcProperties.getProcInfo()->procParamDefPtr[i].mandatFlg == TRUE)
            {
                mandatoryParam = true;
                break;
            }
        }
        if (mandatoryParam == false)
        {
            DBA_DYNFLD_STP emptyDynStp = ALLOC_DYNST(rpcProperties.getArgDynStEnum());
            ret = (rpcContextHttp.setRpcInputArg(emptyDynStp) == RET_SUCCEED);
            bRpcInputArgSet = true;
        }
    }

    /* PMSTA-28698 - LJE - 180622 */
    if (ret == true  && bRpcInputArgSet == false)
    {
        ret = (rpcContextHttp.setRpcInputArg(nullptr) == RET_SUCCEED);
        bRpcInputArgSet = true;

        /* Is big raw data as input into the body PMSTA-32235 - 160519 - PMO */
        if (rpcProperties.getArgDynStEnum()     == NullDynSt &&
            bodyData.data()   != nullptr                     &&
            bodyData.length() > 0                            &&
            rpcProperties.isJSonParam())
        {
            emptyParamNeeded = true;
            rpcContextHttp.setHttpBody(bodyData.data());

            const QByteArray logLevel = getRequestHeader(request, "X-ImportLogLevelCd");
            if (logLevel.isEmpty() == false)
            {
                rpcContextHttp.setImportLogLevel(logLevel.data());
            }
            const QByteArray entityProfile = getRequestHeader(request, "X-EntityProfileCd");
            if (entityProfile.isEmpty() == false)
            {
                rpcContextHttp.setEntityProfile(entityProfile.data());
            }
        }
    }

    /* Check input argument */
    if (ret == true &&
        (rpcProperties.getArgDynStEnum() != NullDynSt || rpcProperties.getRequestDynStEnum() != NullDynSt) &&
        (rpcContextHttp.getRpcInputArg() != nullptr || emptyParamNeeded == false)) /* Allow empty parameter if nothing it's declared in the definition */
    {
        if (rpcContextHttp.getRpcInputArg() == nullptr ||
            (rpcProperties.isProxy() == false &&
             GET_DYNSTENUM(rpcContextHttp.getRpcInputArg()) != rpcProperties.getArgDynStEnum() &&
             GET_DYNSTENUM(rpcContextHttp.getRpcInputArg()) != rpcProperties.getRequestDynStEnum()))
        {
            if (msgStr.empty())
            {
                msgStr = "Invalid RPC input parameter (wrong input entity): " + rpcProperties.getRpcName();
            }
            rpcContextHttp.setTaRetCode(RET_GEN_ERR_INVARG);
            ret = false;
        }
    }

    if (ret == false)
    {
        if (msgStr.empty())
        {
            msgStr = "Invalid RPC input parameter: " + rpcProperties.getRpcName();
        }

        if (rpcContextHttp.getTaRetCode() == RET_SUCCEED) /* If in error and the retcode not already set, force it PMSTA-49293 FME 2022-06-23 */
        {
            rpcContextHttp.setTaRetCode((inputResult != RET_SUCCEED ? inputResult : RET_GEN_ERR_INVARG));
        }
        MSG_SendMesg(FILEINFO, msgStr);
    }

    return ret;
}


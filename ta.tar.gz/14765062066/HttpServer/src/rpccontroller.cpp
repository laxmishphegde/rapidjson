/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include "unidef.h"
#include "dba.h"

#include "rpccontroller.h"
#include "httpserver.h"
#include "httpsessionstore.h"

extern QByteArray getRequestHeader(const HttpRequest& request, const QByteArray& hKey);

/************************************************************************
*   Function        :   
*
*   Description     :   
*
*   Arguments       :   
*
*   Return          :   
*
*   Creation Date   :   Daniel Lachat
*
*   Last Modif.     :
*
*************************************************************************/
RpcController::RpcController(HttpSessionStore* sessionStore, QObject* parent) :
HttpRequestHandler(parent), sessionStore_(sessionStore)
{
}

/************************************************************************
*   Function        :   
*
*   Description     :   
*
*   Arguments       :   
*
*   Return          :   
*
*   Creation Date   :   Daniel Lachat
*
*   Last Modif.     :
*
*************************************************************************/
void RpcController::service(HttpRequest& request, HttpResponse& response)
{

    QByteArray path = request.getPath();
    HttpSession session = sessionStore_->getSession(request, response);

	if (path.startsWith("/rpc/"))
	{
		QByteArray rpcName = path.remove(0, 5); // "/rpc/" 
		HTTP_RpcExecutor(request, response, rpcName, session);

        /* Dirty workaround till TAP is made stateless.
         * Remove the session object used in OAuth request processing
         * from the session store, otherwise this session will be send if the
         * next request is a basic auth
         */
        const QByteArray authorizationHeader = getRequestHeader(request, "Authorization");
        if (authorizationHeader.isEmpty() == false && authorizationHeader.startsWith("Bearer "))
        {
            HttpSession sessionToDelete = sessionStore_->getSession(session.getId());
            sessionStore_->removeSession(sessionToDelete);
        }
	}
	else{
		response.setStatus(404, "not found");
		response.write("404 not found", true);
	}
}


/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
ApplSessionController::ApplSessionController(HttpSessionStore* sessionStore, QObject* parent) :
    HttpRequestHandler(parent), sessionStore_(sessionStore)
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
void ApplSessionController::service(HttpRequest& request, HttpResponse& response)
{
    QByteArray path = request.getPath();

    if (path.startsWith("/applsess/"))
    {
        HttpSession session = sessionStore_->getSession(request, response);
        QByteArray rpcName = path.remove(0, 10); // 10 is the length of "/applsess/" 

        HTTP_RpcExecutor(request, response, rpcName, session);
    }
    else if (path.startsWith("/connection"))
    {
        /* The respense to this request simply indicates that the server is up n running   */
        response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_OK));
    }
    else
    {
        response.setStatus(404, "not found");
        response.write("404 not found", true);
    }
}

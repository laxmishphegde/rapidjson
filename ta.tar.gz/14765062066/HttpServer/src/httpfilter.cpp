/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include "unidef.h"

#include "httpfilter.h"
#include "httprequest.h"
#include "httpresponse.h"
#include "httprequesthandler.h"
#include "httpsession.h"
#include "httpsessionstore.h"
#include "aaalogger.h"
#include "aaatelemetry.h"

#include "password.h"
#include "dbiconnection.h"
#include "httpserver.h"

#ifdef NTWIN
#pragma warning (push)
#pragma warning(disable:4101)
#pragma warning(disable:4127)
#pragma warning(disable:4267)
#pragma warning(disable:4702)
#pragma warning(disable:4996)
#endif
#include "jwt/jwt.hpp"
#ifdef NTWIN
#pragma warning (pop)
#endif

#include <QSslKey>
#include <QSslCertificate>
#include "sysformat.h"

#include "jwthandler.h"

std::string getJWTValidationError(jwt::VerificationError * err)
{
    if (dynamic_cast<jwt::TokenExpiredError *>(err) != nullptr)
    {
        return "JWT token expired";
    }
    return "JWT token validation error";
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpFilterChain::HttpFilterChain(HttpRequestHandler* requestHandler, QObject* parent)
    : QObject(parent), requestHandler_(requestHandler)
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpFilterChain::~HttpFilterChain()
{
    while (!this->filters_.isEmpty())
        delete this->filters_.takeFirst();
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
void HttpFilterChain::appendOwned(HttpFilter* filter)
{
    this->filters_.append(filter);
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
bool HttpFilterChain::doFilter(HttpRequest& request, HttpResponse& response)
{
    bool result = true;
    if (!filters_.isEmpty())
    {
        HttpFilter* current = filters_.takeFirst();
        current->doFilter(request, response, *this);
        delete current;
    }
    else
    {
        Q_ASSERT_X(requestHandler_ != nullptr, "HttpFilterChain::doFilter", "No request handler defined");
        requestHandler_->service(request, response);
    }

    return result;
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpFilter::HttpFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpFilter::~HttpFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpLoggingFilter::HttpLoggingFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpLoggingFilter::~HttpLoggingFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
void HttpLoggingFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    INT64_T startTime_ms = DATE_currentMilliSecsSinceEpoch();
    
    AAATracer::AAAScopedSpan loggingSpan(AAATelemetry::GetTracer(AAATracer::TraceName::HttpServerDetailed).startNewSpan("loggingFilter"));


    AAALogger::putMDC(AAALogger::MDC_keys::RequestMethod, request.getMethod().data());
    AAALogger::putMDC(AAALogger::MDC_keys::Uri, request.getPath().data());

    const QByteArray correlationID = getRequestHeader(request,"X-Correlation-ID");
    if (!correlationID.isEmpty())
    {
        AAALogger::putMDC(AAALogger::MDC_keys::CorrelationID, correlationID.data());
    }

    const AAALogger& accessLog = AAALogger::get(AAALogger::Logger::HttpAccessServer);

	if (accessLog.isDebugEnabled())
    {
        std::ostringstream  logMessage;
        if (request.getParameterMap().count() > 0)
        {
            logMessage << "RequestParameters={";
            QMapIterator<QByteArray, QByteArray> paramIter(request.getParameterMap());
            while (paramIter.hasNext())
            {
                paramIter.next();
                logMessage << paramIter.key().data() << "=" << paramIter.value().data();
                if (paramIter.hasNext())
                {
                    logMessage << ",";
                }
            }
            logMessage << "} ";
        }
        if (accessLog.isTraceEnabled()) // Headers & Cookies only in Trace level
        {
            if (request.getHeaderMap().count() > 0)
            {
                logMessage << "Headers={";

                QMapIterator<QByteArray, QByteArray> headerIter(request.getHeaderMap());
                while (headerIter.hasNext())
                {
                    headerIter.next();
                    logMessage << headerIter.key().data() << "=" << headerIter.value().data();
                    if (headerIter.hasNext())
                    {
                        logMessage << ",";
                    }
                }
                logMessage << "} ";
            }
            if (request.getCookieMap().count() > 0)
            {
                logMessage << "Cookies={";
                QMapIterator<QByteArray, QByteArray> cookiesIter(request.getCookieMap());
                while (cookiesIter.hasNext())
                {
                    cookiesIter.next();
                    logMessage << cookiesIter.key().data() << "=" << cookiesIter.value().data();
                    if (cookiesIter.hasNext())
                    {
                        logMessage << ",";
                    }
                }
                logMessage << "} ";
            }
        }
        if (request.getBody().size() > 0)
        {
            logMessage << "RequestBody=" << request.getBody().data() << "";
        }
        accessLog.debug(logMessage.str());
    }


    // ----- DO the job ------

    chain.doFilter(request, response);

    INT64_T duration_ms = DATE_currentMilliSecsSinceEpoch() - startTime_ms;
    {
        std::ostringstream oss;
        oss << duration_ms;
        AAALogger::putMDC(AAALogger::MDC_keys::Duration, oss.str());
    }
    const std::string _statusCodeStr(QByteArray::number(response.getStatusCode()).data());
	AAALogger::putMDC(AAALogger::MDC_keys::Status, _statusCodeStr);

    // Put again in the MDC RequestMethod & Uri as it has maybe be cleared by HttpClient::_executeMethod
    AAALogger::putMDC(AAALogger::MDC_keys::RequestMethod, request.getMethod().data());
    AAALogger::putMDC(AAALogger::MDC_keys::Uri, request.getPath().data());


    accessLog.info(request.getPath().data()); //@TODO verify/synchronized with what is logged in JAVA


    static bool counterRegistered = false;
    const std::string metricName("http_request");
    auto meter = AAATelemetry::GetMeter(AAAMeter::MeterName::HttpServer);

    if (counterRegistered == false) 
    {
        counterRegistered = true;
        meter->m_attributeDetails = AAAMeter::LabelDetail::NoDetails;

        meter->registerHistogramMeter(metricName, "Http Requests", "ms");
    }

    std::map<std::string, std::string> attributes;
    attributes.emplace(std::make_pair("http_code", _statusCodeStr));

    meter->getHistogramMeter(metricName)->Record(duration_ms, attributes);


    AAALogger::clearMDC();
}



/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpTracerFilter::HttpTracerFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpTracerFilter::~HttpTracerFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
void HttpTracerFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    const std::string URI(request.getPath().data());
    std::unordered_map<std::string, std::string > allHeaders;

    QMapIterator<QByteArray, QByteArray> headerIter(request.getHeaderMap());
    while (headerIter.hasNext())
    {
        headerIter.next();
        const std::string headerKey(headerIter.key().data());
        const std::string headerValue(headerIter.value().data());

        allHeaders.insert(std::make_pair(headerKey, headerValue));
    }

    AAATracer::AAASpan topSpan = AAATelemetry::GetTracer(AAATracer::TraceName::HttpServer).continueSpanFrom(URI, allHeaders, AAATracer::LinkNature::CHILD_OF);
    topSpan.setTag("thread.id", OS_GetTid());
    // see https://opentelemetry.io/docs/reference/specification/trace/semantic_conventions/http/
    topSpan.setTag("http.method", request.getMethod().data());
    topSpan.setTag("http.target", URI);

    AAALogger::putMDC(AAALogger::MDC_keys::CorrelationID, topSpan.getTraceId()); // @TODO create a MDC_keys::TraceID

    // ----- DO the job ------
    chain.doFilter(request, response);

    topSpan.setTag("http.status_code", response.getStatusCode());

    topSpan.finish();
}


/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpBasicAuthenticationFilter::HttpBasicAuthenticationFilter(const QByteArray realmName, HttpSessionStore* sessionStore)
    : HttpFilter(), realmName_(realmName), sessionStore_(sessionStore)
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpBasicAuthenticationFilter::~HttpBasicAuthenticationFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
void HttpBasicAuthenticationFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    HttpSession session = sessionStore_->getSession(request, response);
    bool authorized = determineIfAuthorized(request, response, session);

    if (authorized)
    {
        chain.doFilter(request, response);
    }
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :   Daniel Lachat
*
*************************************************************************/
bool HttpBasicAuthenticationFilter::determineIfAuthorized(const HttpRequest& request, HttpResponse& response, HttpSession& session)
{
    AAATracer::AAAScopedSpan authSpan(AAATelemetry::GetTracer(AAATracer::TraceName::HttpServerDetailed).startNewSpan("determineIfAuthorized"));

    bool result=false;
    /* PMSTA-34344 - TEB - 191007 */
    AAALogger httpServerAccessLogger = AAALogger::get(AAALogger::Logger::HttpAccessServer);

	if (session.contains("userId") == false && session.contains("applSessionCd") == false)    /* PMSTA-34344 - TEB - 190805 */
	{
        /* PMSTA-34344 - TEB - 191007 */
        if (httpServerAccessLogger.isDebugEnabled())
        {
            std::ostringstream  loggingStream;
            loggingStream << " HttpBasicAuthenticationFilter::determineIfAuthorized no userId nor applSessionCd in session ";
            httpServerAccessLogger.debug(loggingStream.str());
        }

		const QByteArray authorizationHeader = getRequestHeader(request,"Authorization");

		if (authorizationHeader.isEmpty() == false)
        {
            const char * BASIC_HEADER = "Basic";
            if (authorizationHeader.startsWith(BASIC_HEADER)) {
                const QByteArray base64UserPassword = authorizationHeader.right(authorizationHeader.length() - qstrlen(BASIC_HEADER));
                const QByteArray userPassword = QByteArray::fromBase64(base64UserPassword);
                int userIdPasswordSep = userPassword.indexOf(':');
                if (userIdPasswordSep > 0)
                {
                    const QByteArray userId = userPassword.left(userIdPasswordSep);
                    PasswordEncrypted pE;
                    pE.setClearPassword(PasswordClear(userPassword.right(userPassword.length() - userIdPasswordSep - 1)));
					if (HTTP_Authentication(request, session, userId , pE))
					{
						result = true;
                        if (httpServerAccessLogger.isDebugEnabled())
                        {
                            std::ostringstream  loggingStream;
                            loggingStream << " HttpBasicAuthenticationFilter::determineIfAuthorized validated for userId [" << userId.data() << "]";
                            httpServerAccessLogger.debug(loggingStream.str());
                        }
					}
                    else
                    {
                        result = false;
                    }
				}
			}
            else if (authorizationHeader.startsWith("Bearer"))
            {
                /* Header has Bearer token, so this is a case of JWT validation, no need for basic auth */
                result = true;
            }

            if (result == false)
            {
                QByteArray basicRealmValue("Basic realm=");
                basicRealmValue.append('"').append(realmName_).append('"');
                response.setHeader("WWW-Authenticate", basicRealmValue);
                response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_FORBIDDEN));
                response.write("403 Forbidden", true);
            }
        }
        else
        {
            QByteArray basicRealmValue("Basic realm=");
            basicRealmValue.append('"').append(realmName_).append('"');
            response.setHeader("WWW-Authenticate", basicRealmValue);
            response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_UNAUTHORIZED));
            response.write("401 Authorization Required", true);
        }
    }
    else if (session.contains("applSessionCd"))
    {
        if (httpServerAccessLogger.isDebugEnabled())
        {
            const std::string  applSessCd = std::string(session.get("applSessionCd").toString().toLocal8Bit().constData());

            std::ostringstream  loggingStream;
            loggingStream << " HttpBasicAuthenticationFilter::determineIfAuthorized validated for applSessionCd [" << applSessCd << "]";
            httpServerAccessLogger.debug(loggingStream.str());
        }
        result = true;
    }
    else if (session.contains("userId"))
    {
        if (httpServerAccessLogger.isDebugEnabled())
        {
            const std::string  usrId = std::string(session.get("userId").toString().toLocal8Bit().constData());

            std::ostringstream  loggingStream;
            loggingStream << " HttpBasicAuthenticationFilter::determineIfAuthorized validated for userId [" << usrId << "] in session ";
            httpServerAccessLogger.debug(loggingStream.str());
        }
        result = true;
	}

    /* PMSTA-43741 - LJE - 210222 */
    if (result == true && 
        session.contains("applSessionCd") == false)
    {
        const QByteArray applSessionCd = getRequestHeader(request,"X-applSessionCd");
        if (applSessionCd.isEmpty() == false)
        {
            session.set("applSessionCd", applSessionCd);

            const QByteArray guiProxy = getRequestHeader(request, "X-guiProxy");
            if (guiProxy == "true")
            {
                session.set("guiProxy", guiProxy);
            }
        }
    }

	return result;
}

HttpOAuthAuthenticationFilter::HttpOAuthAuthenticationFilter(const QByteArray realmName, HttpSessionStore* sessionStore)
    : HttpFilter(), realmName_(realmName), sessionStore_(sessionStore)
{
}

HttpOAuthAuthenticationFilter::~HttpOAuthAuthenticationFilter()
{
}

void HttpOAuthAuthenticationFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    HttpSession session = sessionStore_->getSession(request, response);
    bool authorized = determineIfAuthorized(request, response, session);

    if (authorized)
    {
        chain.doFilter(request, response);
    }
}

bool HttpOAuthAuthenticationFilter::determineIfAuthorized(const HttpRequest& request, HttpResponse& response, HttpSession& session)
{
    bool ret = false; // not authorized by default, so false.
    const QByteArray authorizationHeader = getRequestHeader(request, "Authorization");
    constexpr char* BEARER_HEADER = "Bearer ";
    std::string jwtValidationError;

    AAALogger::get(AAALogger::Logger::HttpServer).debug("Validating JWT");
    
    /*
    1. Check whether the token has expired
    2. Validate the token using the public key
    3. Check whether the user in the token is the user in the request body for which appl_session creation is requested
    4. ??
    */
    if (authorizationHeader.isEmpty() == false)
    {
        if (authorizationHeader.startsWith(BEARER_HEADER))
        {
            const QByteArray base64JWT = authorizationHeader.right(authorizationHeader.length() - qstrlen(BEARER_HEADER));
            jwt::string_view token = base64JWT.constData();
            std::error_code ec;

            /* get the JWT header, in the header there will be key id for the
             * public key to validate the token */
            auto tokenParts = jwt::jwt_object::three_parts(token);
            if (tokenParts.size() == 3)
            {
                jwt::jwt_header jwtHeader;
                jwtHeader.decode(tokenParts[0], ec); // use exception version
                std::string jwtKeyId = jwtHeader.create_json_obj().at("kid");
                std::string jwtAlgo = jwtHeader.create_json_obj().at("alg");

                try
                {
                    /* get the public key from certificate from the cache for the key id */
                    std::string publicKey(JSONWebKeyCertificateCache::getJSONWebKeyCertificateCache().getPublicKeyFromJSONWebKeyCertificate(jwtKeyId));

                    /*
                     * TODO - check the public key certificate expired */

                     /* Use the public key to decode the token
                      * if the verification fails, then decode call will fail */
                    try
                    {
                        auto dec_obj = jwt::decode(token, jwt::params::algorithms({ jwtAlgo }), jwt::params::secret(publicKey));
                        ret = true; // if it reaches here, then token is validated, otherwise decode would have thrown exception
                    }
                    catch (jwt::VerificationError& err)
                    {
                        ret = false;
                        jwtValidationError = getJWTValidationError(&err);
                        MSG_SendMesg(FILEINFO, std::string("Error in validating JWT in HTTP request : " + jwtValidationError));
                    }

                    /* if JWT validation successful, then set the httpsession user */
                    if (ret == true)
                    {
                        std::string user;
                        DBA_GetProxyUser(user);
                        /* since it's a JWT token login, use proxy user in the session */
                        session.set("userId", user.c_str());
                    }
                }
                catch (JSONWebKeyCertificateNotFoundException & e)
                {
                    std::string message(e.what());
                    MSG_SendMesg(FILEINFO, message);
                }
            }
            else
            {
                MSG_SendMesg(FILEINFO, std::string("Error - Invalid JWT format"));
            }

        }
        else if (authorizationHeader.startsWith("Basic"))
        {
            /* Header has Basic token, so this is a case of basic auth, no need for JWT validation */
            ret = true;
        }

        if (ret == false)
        {
            QByteArray oAuthRealmValue("Bearer Error = ");
            oAuthRealmValue.append('"').append(realmName_).append('"');
            response.setHeader("WWW-Authenticate", oAuthRealmValue);
            response.setHeader("WWW-Authenticate", jwtValidationError.c_str());
            response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_FORBIDDEN));
            response.write("403 Forbidden", true);
        }
    }
    else
    {
        QByteArray oAuthRealmValue("Bearer Error = ");
        oAuthRealmValue.append('"').append(realmName_).append('"');
        response.setHeader("WWW-Authenticate", oAuthRealmValue);
        response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_UNAUTHORIZED));
        response.write("401 Authorization Required", true);
    }
 
    return ret;
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpSessionFilter::HttpSessionFilter(HttpSessionStore* sessionStore)
    : HttpFilter(), sessionStore_(sessionStore)
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpSessionFilter::~HttpSessionFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
void HttpSessionFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    chain.doFilter(request, response);
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
AAARealmServerAuthenticationFilter::AAARealmServerAuthenticationFilter(const QByteArray realmName, HttpSessionStore* sessionStore)
    : HttpFilter(), realmName_(realmName), sessionStore_(sessionStore)
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
AAARealmServerAuthenticationFilter::~AAARealmServerAuthenticationFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
void AAARealmServerAuthenticationFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    HttpSession session = sessionStore_->getSession(request, response);

    bool authorized = determineIfAuthorized(request, session);

    if (authorized)
    {
        chain.doFilter(request, response);
    }
    else
    {
        QByteArray basicRealmValue("Basic realm=");
        basicRealmValue.append('"').append(realmName_).append('"');
        response.setHeader("WWW-Authenticate", basicRealmValue);
        response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_UNAUTHORIZED));
        response.write("401 Authorization Required", true);
    }
}


/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
bool AAARealmServerAuthenticationFilter::determineIfAuthorized(const HttpRequest& request, HttpSession& session)
{
    bool result = false;

    if (session.contains("userId") == false)
    {
        const QByteArray authorizationHeader = getRequestHeader(request,"Authorization");

        if (authorizationHeader.isEmpty() == false)
        {
            const char * BASIC_HEADER = "Basic";
            if (authorizationHeader.startsWith(BASIC_HEADER)) {
                const QByteArray base64UserPassword = authorizationHeader.right(authorizationHeader.length() - qstrlen(BASIC_HEADER));
                const QByteArray userPassword = QByteArray::fromBase64(base64UserPassword);
                int userIdPasswordSep = userPassword.indexOf(':');
                if (userIdPasswordSep > 0)
                {
                    const QByteArray userId = userPassword.left(userIdPasswordSep);
                    PasswordEncrypted pE;
                    pE.setClearPassword(PasswordClear(userPassword.right(userPassword.length() - userIdPasswordSep - 1)));
                    session.remove("userId");
                    session.remove("password");

                    if (HTTP_Authentication(request, session, userId, pE))
                    {
                        session.set("userId", userId);
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }
                }
            }
        }
    }
    else
    {
        result = true;
    }

    return result;
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
HttpIPAccessFilter::~HttpIPAccessFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
void HttpIPAccessFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
	chain.doFilter(request, response);
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
HttpApplSessionFilter::HttpApplSessionFilter(HttpSessionStore* sessionStore)
    : HttpFilter(), sessionStore_(sessionStore)
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
HttpApplSessionFilter::~HttpApplSessionFilter()
{
}

/************************************************************************
*   Function        :
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   :
*
*   Last Modif.     :
*
*************************************************************************/
void HttpApplSessionFilter::doFilter(HttpRequest& request, HttpResponse& response, HttpFilterChain& chain)
{
    chain.doFilter(request, response);
}

QByteArray getRequestHeader(const HttpRequest& request, const QByteArray& hKey)
{
    QMapIterator<QByteArray, QByteArray> hIter(request.getHeaderMap());
    bool found = false;
    QByteArray qba;

    while (found == false && hIter.hasNext())
    {
        hIter.next();
        qba = hIter.key().data();
        found = QString::compare(QString(qba), QString(hKey), Qt::CaseInsensitive) == 0;
    }

    return request.getHeader((found == true) ? qba : hKey);
}
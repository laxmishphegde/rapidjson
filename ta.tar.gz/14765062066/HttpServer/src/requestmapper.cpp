/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include "unidef.h"
#include "dba.h"

#include "requestmapper.h"
#include "httpsessionstore.h"

#include "httpfilter.h"
#include "httpserver.h"
#include "rpccontroller.h"


#include "ddlgendbi.h"

/************************************************************************
*   Function        :   
*
*   Description     :   
*
*   Arguments       :   
*
*   Return          :   
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
RequestMapper::RequestMapper(QObject* parent )
	: HttpRequestHandler(parent)
    , m_sessionStore(0)
{
}

/************************************************************************
*   Function        :   
*
*   Description     :   
*
*   Arguments       :   
*
*   Return          :   
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :
*
*************************************************************************/
RequestMapper::~RequestMapper() 
{
}

void RequestMapper::configureSessionStore(HttpServerSessionConfiguration& sessionStoreConfiguration)
{
    m_RealmName = sessionStoreConfiguration.getRealmName();
    QSettings* sessionStoreSettings = sessionStoreConfiguration.getQSettings(this);
    m_sessionStore = new HttpSessionStore(sessionStoreSettings, this);
}
/************************************************************************
*   Function        :   
*
*   Description     :   
*
*   Arguments       :   
*
*   Return          :   
*
*   Creation Date   :   Francois Mercier
*
*   Last Modif.     :   PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
*
*************************************************************************/
void RequestMapper::service(HttpRequest& request, HttpResponse& response) 
{
    ThreadDescriptor threadDescriptor(ThreadBind::TB_CURRENT_THREAD);

    QByteArray path = request.getPath();

    /* PMSTA-34344 - TEB - 190405 */
    if (path.startsWith("/applsess/"))
    {

        /* Creation of an appl session */
        HttpRequestHandler* requestHandler = new ApplSessionController(this->m_sessionStore);
        HttpFilterChain chain(requestHandler);

        HttpFilter* tracerf = new HttpTracerFilter();
        chain.appendOwned(tracerf);

        HttpFilter* f = new AAARealmServerAuthenticationFilter(m_RealmName.toLatin1(), this->m_sessionStore);
        chain.appendOwned(f);

        /* PMSTA-43502 - LJE - 210208 */
        HttpFilter* loggerf = new HttpLoggingFilter();
        chain.appendOwned(loggerf);

        chain.doFilter(request, response);

        delete requestHandler;
    }
    /*  isready RPC                     */  /*  HFI-PMSTA-42221-201105  */
    else if (path == "/isready")
    {
        int statusCode = HTTP_STATUS_OK;
        
        /* PMSTA-51420 - FME -  2022-12-01 */
        if (request.getParameter("check").compare("db", Qt::CaseInsensitive) == 0)
        {
            /* This can be a DoS entrypoint: mitigation done by introducing a Token */
            static const std::string AAAReadynessToken = SYS_GetEnvStringOrDefValue("AAAReadynessToken", "");
            if (AAAReadynessToken.length() == 0 || request.getParameter("token").compare(AAAReadynessToken.c_str()) == 0)
            {
                DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
                if (dbiConnHelper.isValidAndInit() == false)
                {
                    statusCode = HTTP_STATUS_SERVICE_UNAVAILABLE;
                }
                else
                {
                    // Execute a simple query to verify Database connectivity
                    int* mustBeOne = nullptr;

                    RequestHelper  requestHelper(dbiConnHelper);
                    requestHelper.setReadOnly(true);

                    requestHelper.setCommand("select 1 " + DdlGenDbi::getEmptyFrom(dbiConnHelper.getConnection()->getDbaRDBMS()));
                    requestHelper.addNewOutputData(IntType);
                    requestHelper.getBindVariablePtr(mustBeOne);

                    if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
                    {
                        statusCode = HTTP_STATUS_SERVICE_UNAVAILABLE;
                    } 
                    else if (mustBeOne == nullptr || (*mustBeOne) != 1)
                    {
                        statusCode = HTTP_STATUS_IM_A_TEAPOT; 
                    }
                }
            }
            else 
            {
                statusCode = HTTP_STATUS_EXPECTATION_FAILED;
            }
        }
        response.setStatus(HTTP_STATUS_AND_TEXTC(statusCode));
        response.write(HTTP_reasonPhrase(statusCode).c_str(), true);
    }
    else if (path.startsWith("/connection"))
    {
        HttpRequestHandler* requestHandler = new ApplSessionController(this->m_sessionStore);
        HttpFilterChain chain(requestHandler);

        HttpFilter* f = new HttpBasicAuthenticationFilter(m_RealmName.toLatin1(), this->m_sessionStore);
        chain.appendOwned(f);

        chain.doFilter(request, response);

        if (response.hasSentLastPart() == false)
        {
            response.setStatus(HTTP_STATUS_AND_TEXTC(HTTP_STATUS_OK));
            response.write("OK", true);
        }

        delete requestHandler;
    }
    else
    {
        HttpRequestHandler* requestHandler = new RpcController(this->m_sessionStore);
        HttpFilterChain chain(requestHandler);
        
        HttpFilter* tracerf = new HttpTracerFilter();
        chain.appendOwned(tracerf);

        HttpFilter* f = new HttpBasicAuthenticationFilter(m_RealmName.toLatin1(), this->m_sessionStore);
        chain.appendOwned(f);

        HttpFilter* oAuthf = new HttpOAuthAuthenticationFilter(m_RealmName.toLatin1(), this->m_sessionStore);
        chain.appendOwned(oAuthf);

        HttpFilter* applsessionf = new HttpApplSessionFilter(this->m_sessionStore);
        chain.appendOwned(applsessionf);

        HttpFilter* loggerf = new HttpLoggingFilter();
        chain.appendOwned(loggerf);

        chain.doFilter(request, response);

        delete requestHandler;

    }
}

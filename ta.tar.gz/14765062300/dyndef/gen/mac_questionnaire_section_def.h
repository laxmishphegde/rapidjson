/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestSectionDefNatEn         GET_A_QuestSectionDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestSectionDefNatEn>  (GET_ENUM(p, A_QuestSectionDef_NatEn)));
}

inline QuestSectionDefNatEn         _GET_A_QuestSectionDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestSectionDefNatEn>  (_GET_ENUM(p, A_QuestSectionDef_NatEn)));
}

inline void                         SET_A_QuestSectionDef_NatEn(DBA_DYNFLD_STP p, QuestSectionDefNatEn enumValue)
{
    SET_ENUM(p, A_QuestSectionDef_NatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PackageDefinitionNatEn       GET_A_PackageDefinition_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (GET_ENUM(p, A_PackageDefinition_NatEn)));
}
inline PackageDefinitionNatEn       GET_S_PackageDefinition_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (GET_ENUM(p, S_PackageDefinition_NatEn)));
}
inline PackageDefinitionStatusEn    GET_A_PackageDefinition_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionStatusEn>  (GET_ENUM(p, A_PackageDefinition_StatusEn)));
}
inline PackageDefinitionStatusEn    GET_S_PackageDefinition_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionStatusEn>  (GET_ENUM(p, S_PackageDefinition_StatusEn)));
}
inline PackageDefinitionSimulationStatusEn GET_A_PackageDefinition_SimulationStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionSimulationStatusEn>  (GET_ENUM(p, A_PackageDefinition_SimulationStatusEn)));
}

inline PackageDefinitionNatEn       _GET_A_PackageDefinition_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (_GET_ENUM(p, A_PackageDefinition_NatEn)));
}
inline PackageDefinitionNatEn       _GET_S_PackageDefinition_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (_GET_ENUM(p, S_PackageDefinition_NatEn)));
}
inline PackageDefinitionStatusEn    _GET_A_PackageDefinition_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionStatusEn>  (_GET_ENUM(p, A_PackageDefinition_StatusEn)));
}
inline PackageDefinitionStatusEn    _GET_S_PackageDefinition_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionStatusEn>  (_GET_ENUM(p, S_PackageDefinition_StatusEn)));
}
inline PackageDefinitionSimulationStatusEn _GET_A_PackageDefinition_SimulationStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionSimulationStatusEn>  (_GET_ENUM(p, A_PackageDefinition_SimulationStatusEn)));
}

inline void                         SET_A_PackageDefinition_NatEn(DBA_DYNFLD_STP p, PackageDefinitionNatEn enumValue)
{
    SET_ENUM(p, A_PackageDefinition_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PackageDefinition_NatEn(DBA_DYNFLD_STP p, PackageDefinitionNatEn enumValue)
{
    SET_ENUM(p, S_PackageDefinition_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PackageDefinition_StatusEn(DBA_DYNFLD_STP p, PackageDefinitionStatusEn enumValue)
{
    SET_ENUM(p, A_PackageDefinition_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PackageDefinition_StatusEn(DBA_DYNFLD_STP p, PackageDefinitionStatusEn enumValue)
{
    SET_ENUM(p, S_PackageDefinition_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PackageDefinition_SimulationStatusEn(DBA_DYNFLD_STP p, PackageDefinitionSimulationStatusEn enumValue)
{
    SET_ENUM(p, A_PackageDefinition_SimulationStatusEn, static_cast<unsigned char>(enumValue));
}


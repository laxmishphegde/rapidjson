/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline RiskValueEltTimeHorizonUnitEn GET_A_RiskValueElt_TimeHorizonUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskValueEltTimeHorizonUnitEn>  (GET_ENUM(p, A_RiskValueElt_TimeHorizonUnitEn)));
}
inline RiskValueEltTimeHorizonUnitEn GET_S_RiskValueElt_TimeHorizonUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskValueEltTimeHorizonUnitEn>  (GET_ENUM(p, S_RiskValueElt_TimeHorizonUnitEn)));
}
inline RiskValueEltStatusEn         GET_A_RiskValueElt_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskValueEltStatusEn>  (GET_ENUM(p, A_RiskValueElt_StatusEn)));
}

inline RiskValueEltTimeHorizonUnitEn _GET_A_RiskValueElt_TimeHorizonUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskValueEltTimeHorizonUnitEn>  (_GET_ENUM(p, A_RiskValueElt_TimeHorizonUnitEn)));
}
inline RiskValueEltTimeHorizonUnitEn _GET_S_RiskValueElt_TimeHorizonUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskValueEltTimeHorizonUnitEn>  (_GET_ENUM(p, S_RiskValueElt_TimeHorizonUnitEn)));
}
inline RiskValueEltStatusEn         _GET_A_RiskValueElt_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskValueEltStatusEn>  (_GET_ENUM(p, A_RiskValueElt_StatusEn)));
}

inline void                         SET_A_RiskValueElt_TimeHorizonUnitEn(DBA_DYNFLD_STP p, RiskValueEltTimeHorizonUnitEn enumValue)
{
    SET_ENUM(p, A_RiskValueElt_TimeHorizonUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_RiskValueElt_TimeHorizonUnitEn(DBA_DYNFLD_STP p, RiskValueEltTimeHorizonUnitEn enumValue)
{
    SET_ENUM(p, S_RiskValueElt_TimeHorizonUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_RiskValueElt_StatusEn(DBA_DYNFLD_STP p, RiskValueEltStatusEn enumValue)
{
    SET_ENUM(p, A_RiskValueElt_StatusEn, static_cast<unsigned char>(enumValue));
}


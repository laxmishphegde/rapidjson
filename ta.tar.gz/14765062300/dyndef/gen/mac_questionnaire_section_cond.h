/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestionnaireSectionCondActionEn GET_A_QuestionnaireSectionCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireSectionCondActionEn>  (GET_ENUM(p, A_QuestionnaireSectionCond_ActionEn)));
}
inline QuestionnaireSectionCondActionEn GET_S_QuestionnaireSectionCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireSectionCondActionEn>  (GET_ENUM(p, S_QuestionnaireSectionCond_ActionEn)));
}

inline QuestionnaireSectionCondActionEn _GET_A_QuestionnaireSectionCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireSectionCondActionEn>  (_GET_ENUM(p, A_QuestionnaireSectionCond_ActionEn)));
}
inline QuestionnaireSectionCondActionEn _GET_S_QuestionnaireSectionCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireSectionCondActionEn>  (_GET_ENUM(p, S_QuestionnaireSectionCond_ActionEn)));
}

inline void                         SET_A_QuestionnaireSectionCond_ActionEn(DBA_DYNFLD_STP p, QuestionnaireSectionCondActionEn enumValue)
{
    SET_ENUM(p, A_QuestionnaireSectionCond_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_QuestionnaireSectionCond_ActionEn(DBA_DYNFLD_STP p, QuestionnaireSectionCondActionEn enumValue)
{
    SET_ENUM(p, S_QuestionnaireSectionCond_ActionEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TaxLotOpRuleCompoLongShortPositionEn GET_A_TaxLotOpRuleCompo_LongShortPositionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoLongShortPositionEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_LongShortPositionEn)));
}
inline TaxLotOpRuleCompoLongShortPositionEn GET_S_TaxLotOpRuleCompo_LongShortPositionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoLongShortPositionEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_LongShortPositionEn)));
}
inline PtfFusionRuleEn              GET_A_TaxLotOpRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_FusionRuleEn)));
}
inline PtfFusionRuleEn              GET_S_TaxLotOpRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_FusionRuleEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn GET_A_TaxLotOpRuleCompo_TaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_TaxLotImpactEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn GET_S_TaxLotOpRuleCompo_TaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_TaxLotImpactEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn GET_A_TaxLotOpRuleCompo_GlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_GlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn GET_S_TaxLotOpRuleCompo_GlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_GlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn GET_A_TaxLotOpRuleCompo_AcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_AcqDateSetEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn GET_S_TaxLotOpRuleCompo_AcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_AcqDateSetEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn GET_A_TaxLotOpRuleCompo_AdjTaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_AdjTaxLotImpactEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn GET_S_TaxLotOpRuleCompo_AdjTaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_AdjTaxLotImpactEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn GET_A_TaxLotOpRuleCompo_AdjGlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_AdjGlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn GET_S_TaxLotOpRuleCompo_AdjGlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_AdjGlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn GET_A_TaxLotOpRuleCompo_AdjAcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (GET_ENUM(p, A_TaxLotOpRuleCompo_AdjAcqDateSetEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn GET_S_TaxLotOpRuleCompo_AdjAcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (GET_ENUM(p, S_TaxLotOpRuleCompo_AdjAcqDateSetEn)));
}

inline TaxLotOpRuleCompoLongShortPositionEn _GET_A_TaxLotOpRuleCompo_LongShortPositionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoLongShortPositionEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_LongShortPositionEn)));
}
inline TaxLotOpRuleCompoLongShortPositionEn _GET_S_TaxLotOpRuleCompo_LongShortPositionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoLongShortPositionEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_LongShortPositionEn)));
}
inline PtfFusionRuleEn              _GET_A_TaxLotOpRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_FusionRuleEn)));
}
inline PtfFusionRuleEn              _GET_S_TaxLotOpRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_FusionRuleEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn _GET_A_TaxLotOpRuleCompo_TaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_TaxLotImpactEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn _GET_S_TaxLotOpRuleCompo_TaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_TaxLotImpactEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn _GET_A_TaxLotOpRuleCompo_GlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_GlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn _GET_S_TaxLotOpRuleCompo_GlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_GlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn _GET_A_TaxLotOpRuleCompo_AcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_AcqDateSetEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn _GET_S_TaxLotOpRuleCompo_AcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_AcqDateSetEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn _GET_A_TaxLotOpRuleCompo_AdjTaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_AdjTaxLotImpactEn)));
}
inline TaxLotOpRuleCompoTaxLotImpactEn _GET_S_TaxLotOpRuleCompo_AdjTaxLotImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoTaxLotImpactEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_AdjTaxLotImpactEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn _GET_A_TaxLotOpRuleCompo_AdjGlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_AdjGlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoGlobalTaxLotEn _GET_S_TaxLotOpRuleCompo_AdjGlobalTaxLotEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoGlobalTaxLotEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_AdjGlobalTaxLotEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn _GET_A_TaxLotOpRuleCompo_AdjAcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (_GET_ENUM(p, A_TaxLotOpRuleCompo_AdjAcqDateSetEn)));
}
inline TaxLotOpRuleCompoAcqDateSetEn _GET_S_TaxLotOpRuleCompo_AdjAcqDateSetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOpRuleCompoAcqDateSetEn>  (_GET_ENUM(p, S_TaxLotOpRuleCompo_AdjAcqDateSetEn)));
}

inline void                         SET_A_TaxLotOpRuleCompo_LongShortPositionEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoLongShortPositionEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_LongShortPositionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_LongShortPositionEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoLongShortPositionEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_LongShortPositionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p, PtfFusionRuleEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_FusionRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_FusionRuleEn(DBA_DYNFLD_STP p, PtfFusionRuleEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_FusionRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_TaxLotImpactEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoTaxLotImpactEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_TaxLotImpactEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_TaxLotImpactEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoTaxLotImpactEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_TaxLotImpactEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_GlobalTaxLotEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoGlobalTaxLotEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_GlobalTaxLotEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_GlobalTaxLotEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoGlobalTaxLotEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_GlobalTaxLotEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_AcqDateSetEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoAcqDateSetEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_AcqDateSetEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_AcqDateSetEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoAcqDateSetEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_AcqDateSetEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_AdjTaxLotImpactEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoTaxLotImpactEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_AdjTaxLotImpactEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_AdjTaxLotImpactEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoTaxLotImpactEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_AdjTaxLotImpactEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_AdjGlobalTaxLotEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoGlobalTaxLotEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_AdjGlobalTaxLotEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_AdjGlobalTaxLotEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoGlobalTaxLotEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_AdjGlobalTaxLotEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLotOpRuleCompo_AdjAcqDateSetEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoAcqDateSetEn enumValue)
{
    SET_ENUM(p, A_TaxLotOpRuleCompo_AdjAcqDateSetEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLotOpRuleCompo_AdjAcqDateSetEn(DBA_DYNFLD_STP p, TaxLotOpRuleCompoAcqDateSetEn enumValue)
{
    SET_ENUM(p, S_TaxLotOpRuleCompo_AdjAcqDateSetEn, static_cast<unsigned char>(enumValue));
}


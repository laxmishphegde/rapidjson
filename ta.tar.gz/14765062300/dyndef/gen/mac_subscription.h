/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline SubscriptionNatEn            GET_A_Subscription_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionNatEn>  (GET_ENUM(p, A_Subscription_NatEn)));
}
inline SubscriptionNatEn            GET_S_Subscription_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionNatEn>  (GET_ENUM(p, S_Subscription_NatEn)));
}
inline SubscriptionActionEn         GET_A_Subscription_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionActionEn>  (GET_ENUM(p, A_Subscription_ActionEn)));
}
inline SubscriptionModuleEn         GET_A_Subscription_ModuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionModuleEn>  (GET_ENUM(p, A_Subscription_ModuleEn)));
}
inline SubscriptionBusEntitySelectionEn GET_A_Subscription_BusEntitySelectionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionBusEntitySelectionEn>  (GET_ENUM(p, A_Subscription_BusEntitySelectionEn)));
}
inline SubscriptionEventGroupingEn  GET_A_Subscription_EventGroupingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionEventGroupingEn>  (GET_ENUM(p, A_Subscription_EventGroupingEn)));
}

inline SubscriptionNatEn            _GET_A_Subscription_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionNatEn>  (_GET_ENUM(p, A_Subscription_NatEn)));
}
inline SubscriptionNatEn            _GET_S_Subscription_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionNatEn>  (_GET_ENUM(p, S_Subscription_NatEn)));
}
inline SubscriptionActionEn         _GET_A_Subscription_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionActionEn>  (_GET_ENUM(p, A_Subscription_ActionEn)));
}
inline SubscriptionModuleEn         _GET_A_Subscription_ModuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionModuleEn>  (_GET_ENUM(p, A_Subscription_ModuleEn)));
}
inline SubscriptionBusEntitySelectionEn _GET_A_Subscription_BusEntitySelectionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionBusEntitySelectionEn>  (_GET_ENUM(p, A_Subscription_BusEntitySelectionEn)));
}
inline SubscriptionEventGroupingEn  _GET_A_Subscription_EventGroupingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionEventGroupingEn>  (_GET_ENUM(p, A_Subscription_EventGroupingEn)));
}

inline void                         SET_A_Subscription_NatEn(DBA_DYNFLD_STP p, SubscriptionNatEn enumValue)
{
    SET_ENUM(p, A_Subscription_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Subscription_NatEn(DBA_DYNFLD_STP p, SubscriptionNatEn enumValue)
{
    SET_ENUM(p, S_Subscription_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Subscription_ActionEn(DBA_DYNFLD_STP p, SubscriptionActionEn enumValue)
{
    SET_ENUM(p, A_Subscription_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Subscription_ModuleEn(DBA_DYNFLD_STP p, SubscriptionModuleEn enumValue)
{
    SET_ENUM(p, A_Subscription_ModuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Subscription_BusEntitySelectionEn(DBA_DYNFLD_STP p, SubscriptionBusEntitySelectionEn enumValue)
{
    SET_ENUM(p, A_Subscription_BusEntitySelectionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Subscription_EventGroupingEn(DBA_DYNFLD_STP p, SubscriptionEventGroupingEn enumValue)
{
    SET_ENUM(p, A_Subscription_EventGroupingEn, static_cast<unsigned char>(enumValue));
}


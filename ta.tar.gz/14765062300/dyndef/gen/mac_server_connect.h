/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ServConnectStatusEn          GET_A_ServConnect_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectStatusEn>  (GET_ENUM(p, A_ServConnect_StatusEn)));
}
inline ServConnectStatusEn          GET_S_ServConnect_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectStatusEn>  (GET_ENUM(p, S_ServConnect_StatusEn)));
}
inline ServConnectNatEn             GET_A_ServConnect_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectNatEn>  (GET_ENUM(p, A_ServConnect_NatEn)));
}
inline ServConnectNatEn             GET_S_ServConnect_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectNatEn>  (GET_ENUM(p, S_ServConnect_NatEn)));
}
inline ServConnectSchemeEn          GET_A_ServConnect_SchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectSchemeEn>  (GET_ENUM(p, A_ServConnect_SchemeEn)));
}

inline ServConnectStatusEn          _GET_A_ServConnect_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectStatusEn>  (_GET_ENUM(p, A_ServConnect_StatusEn)));
}
inline ServConnectStatusEn          _GET_S_ServConnect_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectStatusEn>  (_GET_ENUM(p, S_ServConnect_StatusEn)));
}
inline ServConnectNatEn             _GET_A_ServConnect_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectNatEn>  (_GET_ENUM(p, A_ServConnect_NatEn)));
}
inline ServConnectNatEn             _GET_S_ServConnect_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectNatEn>  (_GET_ENUM(p, S_ServConnect_NatEn)));
}
inline ServConnectSchemeEn          _GET_A_ServConnect_SchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServConnectSchemeEn>  (_GET_ENUM(p, A_ServConnect_SchemeEn)));
}

inline void                         SET_A_ServConnect_StatusEn(DBA_DYNFLD_STP p, ServConnectStatusEn enumValue)
{
    SET_ENUM(p, A_ServConnect_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ServConnect_StatusEn(DBA_DYNFLD_STP p, ServConnectStatusEn enumValue)
{
    SET_ENUM(p, S_ServConnect_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ServConnect_NatEn(DBA_DYNFLD_STP p, ServConnectNatEn enumValue)
{
    SET_ENUM(p, A_ServConnect_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ServConnect_NatEn(DBA_DYNFLD_STP p, ServConnectNatEn enumValue)
{
    SET_ENUM(p, S_ServConnect_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ServConnect_SchemeEn(DBA_DYNFLD_STP p, ServConnectSchemeEn enumValue)
{
    SET_ENUM(p, A_ServConnect_SchemeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TascPrecExecutionStatusEn    GET_A_TascPrecExecution_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascPrecExecutionStatusEn>  (GET_ENUM(p, A_TascPrecExecution_StatusEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_A_TascPrecExecution_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, A_TascPrecExecution_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_S_TascPrecExecution_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, S_TascPrecExecution_MeRecordLocationEn)));
}

inline TascPrecExecutionStatusEn    _GET_A_TascPrecExecution_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascPrecExecutionStatusEn>  (_GET_ENUM(p, A_TascPrecExecution_StatusEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_A_TascPrecExecution_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, A_TascPrecExecution_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_S_TascPrecExecution_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, S_TascPrecExecution_MeRecordLocationEn)));
}

inline void                         SET_A_TascPrecExecution_StatusEn(DBA_DYNFLD_STP p, TascPrecExecutionStatusEn enumValue)
{
    SET_ENUM(p, A_TascPrecExecution_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TascPrecExecution_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, A_TascPrecExecution_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TascPrecExecution_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, S_TascPrecExecution_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}


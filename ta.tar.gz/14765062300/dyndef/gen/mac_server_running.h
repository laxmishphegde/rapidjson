/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ServRunningSchemeEn          GET_A_ServRunning_SchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServRunningSchemeEn>  (GET_ENUM(p, A_ServRunning_SchemeEn)));
}
inline ServRunningSchemeEn          GET_A_ServRunning_InternalSchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServRunningSchemeEn>  (GET_ENUM(p, A_ServRunning_InternalSchemeEn)));
}

inline ServRunningSchemeEn          _GET_A_ServRunning_SchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServRunningSchemeEn>  (_GET_ENUM(p, A_ServRunning_SchemeEn)));
}
inline ServRunningSchemeEn          _GET_A_ServRunning_InternalSchemeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServRunningSchemeEn>  (_GET_ENUM(p, A_ServRunning_InternalSchemeEn)));
}

inline void                         SET_A_ServRunning_SchemeEn(DBA_DYNFLD_STP p, ServRunningSchemeEn enumValue)
{
    SET_ENUM(p, A_ServRunning_SchemeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ServRunning_InternalSchemeEn(DBA_DYNFLD_STP p, ServRunningSchemeEn enumValue)
{
    SET_ENUM(p, A_ServRunning_InternalSchemeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline NotifInstanceLinkedNotifType GET_A_NotifInstance_LinkedNotifType(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceLinkedNotifType>  (GET_ENUM(p, A_NotifInstance_LinkedNotifType)));
}
inline NotifInstanceNotifImportanceEn GET_A_NotifInstance_NotifImportanceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceNotifImportanceEn>  (GET_ENUM(p, A_NotifInstance_NotifImportanceEn)));
}
inline NotifInstanceNotifNatEn      GET_A_NotifInstance_NotifNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceNotifNatEn>  (GET_ENUM(p, A_NotifInstance_NotifNatEn)));
}
inline NotifInstanceNotifPriorityEn GET_A_NotifInstance_NotifPriorityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceNotifPriorityEn>  (GET_ENUM(p, A_NotifInstance_NotifPriorityEn)));
}
inline NotifInstanceOriginEn        GET_A_NotifInstance_OriginEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceOriginEn>  (GET_ENUM(p, A_NotifInstance_OriginEn)));
}

inline NotifInstanceLinkedNotifType _GET_A_NotifInstance_LinkedNotifType(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceLinkedNotifType>  (_GET_ENUM(p, A_NotifInstance_LinkedNotifType)));
}
inline NotifInstanceNotifImportanceEn _GET_A_NotifInstance_NotifImportanceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceNotifImportanceEn>  (_GET_ENUM(p, A_NotifInstance_NotifImportanceEn)));
}
inline NotifInstanceNotifNatEn      _GET_A_NotifInstance_NotifNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceNotifNatEn>  (_GET_ENUM(p, A_NotifInstance_NotifNatEn)));
}
inline NotifInstanceNotifPriorityEn _GET_A_NotifInstance_NotifPriorityEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceNotifPriorityEn>  (_GET_ENUM(p, A_NotifInstance_NotifPriorityEn)));
}
inline NotifInstanceOriginEn        _GET_A_NotifInstance_OriginEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<NotifInstanceOriginEn>  (_GET_ENUM(p, A_NotifInstance_OriginEn)));
}

inline void                         SET_A_NotifInstance_LinkedNotifType(DBA_DYNFLD_STP p, NotifInstanceLinkedNotifType enumValue)
{
    SET_ENUM(p, A_NotifInstance_LinkedNotifType, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_NotifInstance_NotifImportanceEn(DBA_DYNFLD_STP p, NotifInstanceNotifImportanceEn enumValue)
{
    SET_ENUM(p, A_NotifInstance_NotifImportanceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_NotifInstance_NotifNatEn(DBA_DYNFLD_STP p, NotifInstanceNotifNatEn enumValue)
{
    SET_ENUM(p, A_NotifInstance_NotifNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_NotifInstance_NotifPriorityEn(DBA_DYNFLD_STP p, NotifInstanceNotifPriorityEn enumValue)
{
    SET_ENUM(p, A_NotifInstance_NotifPriorityEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_NotifInstance_OriginEn(DBA_DYNFLD_STP p, NotifInstanceOriginEn enumValue)
{
    SET_ENUM(p, A_NotifInstance_OriginEn, static_cast<unsigned char>(enumValue));
}


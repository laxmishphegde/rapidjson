/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline RiskRuleCompoRiskCalcCalculationEn GET_A_RiskRuleCompoRiskCalc_CalculationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskRuleCompoRiskCalcCalculationEn>  (GET_ENUM(p, A_RiskRuleCompoRiskCalc_CalculationEn)));
}
inline RiskRuleCompoRiskCalcCalculationEn GET_S_RiskRuleCompoRiskCalc_CalculationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskRuleCompoRiskCalcCalculationEn>  (GET_ENUM(p, S_RiskRuleCompoRiskCalc_CalculationEn)));
}

inline RiskRuleCompoRiskCalcCalculationEn _GET_A_RiskRuleCompoRiskCalc_CalculationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskRuleCompoRiskCalcCalculationEn>  (_GET_ENUM(p, A_RiskRuleCompoRiskCalc_CalculationEn)));
}
inline RiskRuleCompoRiskCalcCalculationEn _GET_S_RiskRuleCompoRiskCalc_CalculationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<RiskRuleCompoRiskCalcCalculationEn>  (_GET_ENUM(p, S_RiskRuleCompoRiskCalc_CalculationEn)));
}

inline void                         SET_A_RiskRuleCompoRiskCalc_CalculationEn(DBA_DYNFLD_STP p, RiskRuleCompoRiskCalcCalculationEn enumValue)
{
    SET_ENUM(p, A_RiskRuleCompoRiskCalc_CalculationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_RiskRuleCompoRiskCalc_CalculationEn(DBA_DYNFLD_STP p, RiskRuleCompoRiskCalcCalculationEn enumValue)
{
    SET_ENUM(p, S_RiskRuleCompoRiskCalc_CalculationEn, static_cast<unsigned char>(enumValue));
}


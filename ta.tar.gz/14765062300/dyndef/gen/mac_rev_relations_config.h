/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdLegalEntityTypeEn       GET_A_RevRelationsConfig_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, A_RevRelationsConfig_LegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       GET_S_RevRelationsConfig_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, S_RevRelationsConfig_LegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       GET_A_RevRelationsConfig_RevLegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, A_RevRelationsConfig_RevLegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       GET_S_RevRelationsConfig_RevLegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (GET_ENUM(p, S_RevRelationsConfig_RevLegalEntityTypeEn)));
}

inline ThirdLegalEntityTypeEn       _GET_A_RevRelationsConfig_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, A_RevRelationsConfig_LegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       _GET_S_RevRelationsConfig_LegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, S_RevRelationsConfig_LegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       _GET_A_RevRelationsConfig_RevLegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, A_RevRelationsConfig_RevLegalEntityTypeEn)));
}
inline ThirdLegalEntityTypeEn       _GET_S_RevRelationsConfig_RevLegalEntityTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdLegalEntityTypeEn>  (_GET_ENUM(p, S_RevRelationsConfig_RevLegalEntityTypeEn)));
}

inline void                         SET_A_RevRelationsConfig_LegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, A_RevRelationsConfig_LegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_RevRelationsConfig_LegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, S_RevRelationsConfig_LegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_RevRelationsConfig_RevLegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, A_RevRelationsConfig_RevLegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_RevRelationsConfig_RevLegalEntityTypeEn(DBA_DYNFLD_STP p, ThirdLegalEntityTypeEn enumValue)
{
    SET_ENUM(p, S_RevRelationsConfig_RevLegalEntityTypeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ListBuildHistoryStatusEn     GET_A_ListBuildHistory_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListBuildHistoryStatusEn>  (GET_ENUM(p, A_ListBuildHistory_StatusEn)));
}
inline ListBuildHistoryStatusEn     GET_S_ListBuildHistory_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListBuildHistoryStatusEn>  (GET_ENUM(p, S_ListBuildHistory_StatusEn)));
}

inline ListBuildHistoryStatusEn     _GET_A_ListBuildHistory_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListBuildHistoryStatusEn>  (_GET_ENUM(p, A_ListBuildHistory_StatusEn)));
}
inline ListBuildHistoryStatusEn     _GET_S_ListBuildHistory_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ListBuildHistoryStatusEn>  (_GET_ENUM(p, S_ListBuildHistory_StatusEn)));
}

inline void                         SET_A_ListBuildHistory_StatusEn(DBA_DYNFLD_STP p, ListBuildHistoryStatusEn enumValue)
{
    SET_ENUM(p, A_ListBuildHistory_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ListBuildHistory_StatusEn(DBA_DYNFLD_STP p, ListBuildHistoryStatusEn enumValue)
{
    SET_ENUM(p, S_ListBuildHistory_StatusEn, static_cast<unsigned char>(enumValue));
}


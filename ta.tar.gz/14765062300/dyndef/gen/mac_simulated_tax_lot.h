/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TaxLotMovementNatEn          GET_A_SimulatedTaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (GET_ENUM(p, A_SimulatedTaxLot_MovementNatEn)));
}
inline TaxLotMovementNatEn          GET_S_SimulatedTaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (GET_ENUM(p, S_SimulatedTaxLot_MovementNatEn)));
}
inline TaxLotInputNatEn             GET_A_SimulatedTaxLot_InputNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotInputNatEn>  (GET_ENUM(p, A_SimulatedTaxLot_InputNatEn)));
}
inline TaxLotImpactEn               GET_A_SimulatedTaxLot_ImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotImpactEn>  (GET_ENUM(p, A_SimulatedTaxLot_ImpactEn)));
}
inline TaxLotStatusEn               GET_A_SimulatedTaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (GET_ENUM(p, A_SimulatedTaxLot_StatusEn)));
}
inline TaxLotStatusEn               GET_S_SimulatedTaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (GET_ENUM(p, S_SimulatedTaxLot_StatusEn)));
}
inline TaxLotOrderEn                GET_A_SimulatedTaxLot_OrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOrderEn>  (GET_ENUM(p, A_SimulatedTaxLot_OrderEn)));
}

inline TaxLotMovementNatEn          _GET_A_SimulatedTaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (_GET_ENUM(p, A_SimulatedTaxLot_MovementNatEn)));
}
inline TaxLotMovementNatEn          _GET_S_SimulatedTaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (_GET_ENUM(p, S_SimulatedTaxLot_MovementNatEn)));
}
inline TaxLotInputNatEn             _GET_A_SimulatedTaxLot_InputNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotInputNatEn>  (_GET_ENUM(p, A_SimulatedTaxLot_InputNatEn)));
}
inline TaxLotImpactEn               _GET_A_SimulatedTaxLot_ImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotImpactEn>  (_GET_ENUM(p, A_SimulatedTaxLot_ImpactEn)));
}
inline TaxLotStatusEn               _GET_A_SimulatedTaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (_GET_ENUM(p, A_SimulatedTaxLot_StatusEn)));
}
inline TaxLotStatusEn               _GET_S_SimulatedTaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (_GET_ENUM(p, S_SimulatedTaxLot_StatusEn)));
}
inline TaxLotOrderEn                _GET_A_SimulatedTaxLot_OrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOrderEn>  (_GET_ENUM(p, A_SimulatedTaxLot_OrderEn)));
}

inline void                         SET_A_SimulatedTaxLot_MovementNatEn(DBA_DYNFLD_STP p, TaxLotMovementNatEn enumValue)
{
    SET_ENUM(p, A_SimulatedTaxLot_MovementNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_SimulatedTaxLot_MovementNatEn(DBA_DYNFLD_STP p, TaxLotMovementNatEn enumValue)
{
    SET_ENUM(p, S_SimulatedTaxLot_MovementNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SimulatedTaxLot_InputNatEn(DBA_DYNFLD_STP p, TaxLotInputNatEn enumValue)
{
    SET_ENUM(p, A_SimulatedTaxLot_InputNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SimulatedTaxLot_ImpactEn(DBA_DYNFLD_STP p, TaxLotImpactEn enumValue)
{
    SET_ENUM(p, A_SimulatedTaxLot_ImpactEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SimulatedTaxLot_StatusEn(DBA_DYNFLD_STP p, TaxLotStatusEn enumValue)
{
    SET_ENUM(p, A_SimulatedTaxLot_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_SimulatedTaxLot_StatusEn(DBA_DYNFLD_STP p, TaxLotStatusEn enumValue)
{
    SET_ENUM(p, S_SimulatedTaxLot_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SimulatedTaxLot_OrderEn(DBA_DYNFLD_STP p, TaxLotOrderEn enumValue)
{
    SET_ENUM(p, A_SimulatedTaxLot_OrderEn, static_cast<unsigned char>(enumValue));
}


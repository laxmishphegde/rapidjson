/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ModelConstrNatEn             GET_A_ModelConstr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrNatEn>  (GET_ENUM(p, A_ModelConstr_NatEn)));
}
inline ModelConstrNatEn             GET_S_ModelConstr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrNatEn>  (GET_ENUM(p, S_ModelConstr_NatEn)));
}
inline ModelConstrRoundUnitEn       GET_A_ModelConstr_RoundUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrRoundUnitEn>  (GET_ENUM(p, A_ModelConstr_RoundUnitEn)));
}
inline ModelConstrCategoryEn        GET_A_ModelConstr_CategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrCategoryEn>  (GET_ENUM(p, A_ModelConstr_CategoryEn)));
}

inline ModelConstrNatEn             _GET_A_ModelConstr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrNatEn>  (_GET_ENUM(p, A_ModelConstr_NatEn)));
}
inline ModelConstrNatEn             _GET_S_ModelConstr_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrNatEn>  (_GET_ENUM(p, S_ModelConstr_NatEn)));
}
inline ModelConstrRoundUnitEn       _GET_A_ModelConstr_RoundUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrRoundUnitEn>  (_GET_ENUM(p, A_ModelConstr_RoundUnitEn)));
}
inline ModelConstrCategoryEn        _GET_A_ModelConstr_CategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ModelConstrCategoryEn>  (_GET_ENUM(p, A_ModelConstr_CategoryEn)));
}

inline void                         SET_A_ModelConstr_NatEn(DBA_DYNFLD_STP p, ModelConstrNatEn enumValue)
{
    SET_ENUM(p, A_ModelConstr_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ModelConstr_NatEn(DBA_DYNFLD_STP p, ModelConstrNatEn enumValue)
{
    SET_ENUM(p, S_ModelConstr_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ModelConstr_RoundUnitEn(DBA_DYNFLD_STP p, ModelConstrRoundUnitEn enumValue)
{
    SET_ENUM(p, A_ModelConstr_RoundUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ModelConstr_CategoryEn(DBA_DYNFLD_STP p, ModelConstrCategoryEn enumValue)
{
    SET_ENUM(p, A_ModelConstr_CategoryEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PackageCompositionActionEn   GET_A_PackageInstallationCompo_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (GET_ENUM(p, A_PackageInstallationCompo_ActionEn)));
}
inline PackageCompositionActionEn   GET_S_PackageInstallationCompo_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (GET_ENUM(p, S_PackageInstallationCompo_ActionEn)));
}
inline PackageInstallationStatusEn  GET_A_PackageInstallationCompo_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (GET_ENUM(p, A_PackageInstallationCompo_StatusEn)));
}
inline PackageInstallationStatusEn  GET_S_PackageInstallationCompo_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (GET_ENUM(p, S_PackageInstallationCompo_StatusEn)));
}
inline XdEntityXdActionEn           GET_A_PackageInstallationCompo_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (GET_ENUM(p, A_PackageInstallationCompo_XdActionEn)));
}
inline XdEntityXdStatusEn           GET_A_PackageInstallationCompo_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (GET_ENUM(p, A_PackageInstallationCompo_XdStatusEn)));
}

inline PackageCompositionActionEn   _GET_A_PackageInstallationCompo_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (_GET_ENUM(p, A_PackageInstallationCompo_ActionEn)));
}
inline PackageCompositionActionEn   _GET_S_PackageInstallationCompo_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (_GET_ENUM(p, S_PackageInstallationCompo_ActionEn)));
}
inline PackageInstallationStatusEn  _GET_A_PackageInstallationCompo_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (_GET_ENUM(p, A_PackageInstallationCompo_StatusEn)));
}
inline PackageInstallationStatusEn  _GET_S_PackageInstallationCompo_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (_GET_ENUM(p, S_PackageInstallationCompo_StatusEn)));
}
inline XdEntityXdActionEn           _GET_A_PackageInstallationCompo_XdActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdActionEn>  (_GET_ENUM(p, A_PackageInstallationCompo_XdActionEn)));
}
inline XdEntityXdStatusEn           _GET_A_PackageInstallationCompo_XdStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdEntityXdStatusEn>  (_GET_ENUM(p, A_PackageInstallationCompo_XdStatusEn)));
}

inline void                         SET_A_PackageInstallationCompo_ActionEn(DBA_DYNFLD_STP p, PackageCompositionActionEn enumValue)
{
    SET_ENUM(p, A_PackageInstallationCompo_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PackageInstallationCompo_ActionEn(DBA_DYNFLD_STP p, PackageCompositionActionEn enumValue)
{
    SET_ENUM(p, S_PackageInstallationCompo_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PackageInstallationCompo_StatusEn(DBA_DYNFLD_STP p, PackageInstallationStatusEn enumValue)
{
    SET_ENUM(p, A_PackageInstallationCompo_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PackageInstallationCompo_StatusEn(DBA_DYNFLD_STP p, PackageInstallationStatusEn enumValue)
{
    SET_ENUM(p, S_PackageInstallationCompo_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PackageInstallationCompo_XdActionEn(DBA_DYNFLD_STP p, XdEntityXdActionEn enumValue)
{
    SET_ENUM(p, A_PackageInstallationCompo_XdActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PackageInstallationCompo_XdStatusEn(DBA_DYNFLD_STP p, XdEntityXdStatusEn enumValue)
{
    SET_ENUM(p, A_PackageInstallationCompo_XdStatusEn, static_cast<unsigned char>(enumValue));
}


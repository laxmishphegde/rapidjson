/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline StratNatEn                   GET_A_Strat_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratNatEn>  (GET_ENUM(p, A_Strat_NatEn)));
}
inline StratNatEn                   GET_S_Strat_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratNatEn>  (GET_ENUM(p, S_Strat_NatEn)));
}
inline StratSubNatEn                GET_A_Strat_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratSubNatEn>  (GET_ENUM(p, A_Strat_SubNatEn)));
}
inline StratRelativeMarginFlg       GET_A_Strat_RelativeMarginFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratRelativeMarginFlg>  (GET_ENUM(p, A_Strat_RelativeMarginFlg)));
}
inline InterCondCompoundFreqUnitEn  GET_A_Strat_BenchFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_Strat_BenchFreqUnitEn)));
}
inline PtfRetDetLevelEn             GET_A_Strat_RetDetLevEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetDetLevelEn>  (GET_ENUM(p, A_Strat_RetDetLevEn)));
}
inline StratHeartUploadEn           GET_A_Strat_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratHeartUploadEn>  (GET_ENUM(p, A_Strat_HeartUploadEn)));
}
inline InterCondCompoundFreqUnitEn  GET_A_Strat_ComplianceFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (GET_ENUM(p, A_Strat_ComplianceFreqUnitEn)));
}
inline InstrIslamicComplianceEn     GET_A_Strat_IslamicComplianceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (GET_ENUM(p, A_Strat_IslamicComplianceEn)));
}
inline StratAllocationNatEn         GET_A_Strat_AllocationNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratAllocationNatEn>  (GET_ENUM(p, A_Strat_AllocationNatEn)));
}
inline StratInvestNatEn             GET_A_Strat_InvestNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratInvestNatEn>  (GET_ENUM(p, A_Strat_InvestNatEn)));
}
inline StratInstrDispParentEn       GET_A_Strat_InstrDispParentEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratInstrDispParentEn>  (GET_ENUM(p, A_Strat_InstrDispParentEn)));
}
inline StratApplicationScopeEn      GET_A_Strat_ApplicationScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratApplicationScopeEn>  (GET_ENUM(p, A_Strat_ApplicationScopeEn)));
}
inline StratSoftLockEn              GET_A_Strat_SoftLockEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratSoftLockEn>  (GET_ENUM(p, A_Strat_SoftLockEn)));
}

inline StratNatEn                   _GET_A_Strat_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratNatEn>  (_GET_ENUM(p, A_Strat_NatEn)));
}
inline StratNatEn                   _GET_S_Strat_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratNatEn>  (_GET_ENUM(p, S_Strat_NatEn)));
}
inline StratSubNatEn                _GET_A_Strat_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratSubNatEn>  (_GET_ENUM(p, A_Strat_SubNatEn)));
}
inline StratRelativeMarginFlg       _GET_A_Strat_RelativeMarginFlg(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratRelativeMarginFlg>  (_GET_ENUM(p, A_Strat_RelativeMarginFlg)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_Strat_BenchFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_Strat_BenchFreqUnitEn)));
}
inline PtfRetDetLevelEn             _GET_A_Strat_RetDetLevEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetDetLevelEn>  (_GET_ENUM(p, A_Strat_RetDetLevEn)));
}
inline StratHeartUploadEn           _GET_A_Strat_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratHeartUploadEn>  (_GET_ENUM(p, A_Strat_HeartUploadEn)));
}
inline InterCondCompoundFreqUnitEn  _GET_A_Strat_ComplianceFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InterCondCompoundFreqUnitEn>  (_GET_ENUM(p, A_Strat_ComplianceFreqUnitEn)));
}
inline InstrIslamicComplianceEn     _GET_A_Strat_IslamicComplianceEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (_GET_ENUM(p, A_Strat_IslamicComplianceEn)));
}
inline StratAllocationNatEn         _GET_A_Strat_AllocationNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratAllocationNatEn>  (_GET_ENUM(p, A_Strat_AllocationNatEn)));
}
inline StratInvestNatEn             _GET_A_Strat_InvestNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratInvestNatEn>  (_GET_ENUM(p, A_Strat_InvestNatEn)));
}
inline StratInstrDispParentEn       _GET_A_Strat_InstrDispParentEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratInstrDispParentEn>  (_GET_ENUM(p, A_Strat_InstrDispParentEn)));
}
inline StratApplicationScopeEn      _GET_A_Strat_ApplicationScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratApplicationScopeEn>  (_GET_ENUM(p, A_Strat_ApplicationScopeEn)));
}
inline StratSoftLockEn              _GET_A_Strat_SoftLockEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratSoftLockEn>  (_GET_ENUM(p, A_Strat_SoftLockEn)));
}

inline void                         SET_A_Strat_NatEn(DBA_DYNFLD_STP p, StratNatEn enumValue)
{
    SET_ENUM(p, A_Strat_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Strat_NatEn(DBA_DYNFLD_STP p, StratNatEn enumValue)
{
    SET_ENUM(p, S_Strat_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_SubNatEn(DBA_DYNFLD_STP p, StratSubNatEn enumValue)
{
    SET_ENUM(p, A_Strat_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_RelativeMarginFlg(DBA_DYNFLD_STP p, StratRelativeMarginFlg enumValue)
{
    SET_ENUM(p, A_Strat_RelativeMarginFlg, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_BenchFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Strat_BenchFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_RetDetLevEn(DBA_DYNFLD_STP p, PtfRetDetLevelEn enumValue)
{
    SET_ENUM(p, A_Strat_RetDetLevEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_HeartUploadEn(DBA_DYNFLD_STP p, StratHeartUploadEn enumValue)
{
    SET_ENUM(p, A_Strat_HeartUploadEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_ComplianceFreqUnitEn(DBA_DYNFLD_STP p, InterCondCompoundFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Strat_ComplianceFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_IslamicComplianceEn(DBA_DYNFLD_STP p, InstrIslamicComplianceEn enumValue)
{
    SET_ENUM(p, A_Strat_IslamicComplianceEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_AllocationNatEn(DBA_DYNFLD_STP p, StratAllocationNatEn enumValue)
{
    SET_ENUM(p, A_Strat_AllocationNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_InvestNatEn(DBA_DYNFLD_STP p, StratInvestNatEn enumValue)
{
    SET_ENUM(p, A_Strat_InvestNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_InstrDispParentEn(DBA_DYNFLD_STP p, StratInstrDispParentEn enumValue)
{
    SET_ENUM(p, A_Strat_InstrDispParentEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_ApplicationScopeEn(DBA_DYNFLD_STP p, StratApplicationScopeEn enumValue)
{
    SET_ENUM(p, A_Strat_ApplicationScopeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Strat_SoftLockEn(DBA_DYNFLD_STP p, StratSoftLockEn enumValue)
{
    SET_ENUM(p, A_Strat_SoftLockEn, static_cast<unsigned char>(enumValue));
}


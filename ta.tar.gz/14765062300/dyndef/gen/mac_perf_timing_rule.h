/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline InstrNatEn                   GET_A_PerfTimingRule_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_PerfTimingRule_InstrNatEn)));
}
inline InstrNatEn                   GET_S_PerfTimingRule_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, S_PerfTimingRule_InstrNatEn)));
}
inline PerfTimingRuleTimingRuleEn   GET_A_PerfTimingRule_TimingRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfTimingRuleTimingRuleEn>  (GET_ENUM(p, A_PerfTimingRule_TimingRuleEn)));
}
inline PerfTimingRuleTimingRuleEn   GET_S_PerfTimingRule_TimingRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfTimingRuleTimingRuleEn>  (GET_ENUM(p, S_PerfTimingRule_TimingRuleEn)));
}

inline InstrNatEn                   _GET_A_PerfTimingRule_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_PerfTimingRule_InstrNatEn)));
}
inline InstrNatEn                   _GET_S_PerfTimingRule_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, S_PerfTimingRule_InstrNatEn)));
}
inline PerfTimingRuleTimingRuleEn   _GET_A_PerfTimingRule_TimingRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfTimingRuleTimingRuleEn>  (_GET_ENUM(p, A_PerfTimingRule_TimingRuleEn)));
}
inline PerfTimingRuleTimingRuleEn   _GET_S_PerfTimingRule_TimingRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfTimingRuleTimingRuleEn>  (_GET_ENUM(p, S_PerfTimingRule_TimingRuleEn)));
}

inline void                         SET_A_PerfTimingRule_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_PerfTimingRule_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PerfTimingRule_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, S_PerfTimingRule_InstrNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfTimingRule_TimingRuleEn(DBA_DYNFLD_STP p, PerfTimingRuleTimingRuleEn enumValue)
{
    SET_ENUM(p, A_PerfTimingRule_TimingRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PerfTimingRule_TimingRuleEn(DBA_DYNFLD_STP p, PerfTimingRuleTimingRuleEn enumValue)
{
    SET_ENUM(p, S_PerfTimingRule_TimingRuleEn, static_cast<unsigned char>(enumValue));
}


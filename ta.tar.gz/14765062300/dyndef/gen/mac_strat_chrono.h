/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline StratChronoNatEn             GET_A_StratChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratChronoNatEn>  (GET_ENUM(p, A_StratChrono_NatEn)));
}
inline StratChronoNatEn             GET_S_StratChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratChronoNatEn>  (GET_ENUM(p, S_StratChrono_NatEn)));
}

inline StratChronoNatEn             _GET_A_StratChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratChronoNatEn>  (_GET_ENUM(p, A_StratChrono_NatEn)));
}
inline StratChronoNatEn             _GET_S_StratChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<StratChronoNatEn>  (_GET_ENUM(p, S_StratChrono_NatEn)));
}

inline void                         SET_A_StratChrono_NatEn(DBA_DYNFLD_STP p, StratChronoNatEn enumValue)
{
    SET_ENUM(p, A_StratChrono_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_StratChrono_NatEn(DBA_DYNFLD_STP p, StratChronoNatEn enumValue)
{
    SET_ENUM(p, S_StratChrono_NatEn, static_cast<unsigned char>(enumValue));
}


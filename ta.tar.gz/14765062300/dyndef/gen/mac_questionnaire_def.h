/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestDefNatEn                GET_A_QuestDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefNatEn>  (GET_ENUM(p, A_QuestDef_NatEn)));
}
inline QuestDefStatusEn             GET_A_QuestDef_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefStatusEn>  (GET_ENUM(p, A_QuestDef_StatusEn)));
}
inline QuestDefCategoryEn           GET_A_QuestDef_CategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefCategoryEn>  (GET_ENUM(p, A_QuestDef_CategoryEn)));
}
inline QuestDefScoringNatEn         GET_A_QuestDef_ScoringNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefScoringNatEn>  (GET_ENUM(p, A_QuestDef_ScoringNatEn)));
}

inline QuestDefNatEn                _GET_A_QuestDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefNatEn>  (_GET_ENUM(p, A_QuestDef_NatEn)));
}
inline QuestDefStatusEn             _GET_A_QuestDef_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefStatusEn>  (_GET_ENUM(p, A_QuestDef_StatusEn)));
}
inline QuestDefCategoryEn           _GET_A_QuestDef_CategoryEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefCategoryEn>  (_GET_ENUM(p, A_QuestDef_CategoryEn)));
}
inline QuestDefScoringNatEn         _GET_A_QuestDef_ScoringNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefScoringNatEn>  (_GET_ENUM(p, A_QuestDef_ScoringNatEn)));
}

inline void                         SET_A_QuestDef_NatEn(DBA_DYNFLD_STP p, QuestDefNatEn enumValue)
{
    SET_ENUM(p, A_QuestDef_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_QuestDef_StatusEn(DBA_DYNFLD_STP p, QuestDefStatusEn enumValue)
{
    SET_ENUM(p, A_QuestDef_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_QuestDef_CategoryEn(DBA_DYNFLD_STP p, QuestDefCategoryEn enumValue)
{
    SET_ENUM(p, A_QuestDef_CategoryEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_QuestDef_ScoringNatEn(DBA_DYNFLD_STP p, QuestDefScoringNatEn enumValue)
{
    SET_ENUM(p, A_QuestDef_ScoringNatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdCustomerCustRoleEn      GET_A_PtfThirdCompo_OwnershipRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (GET_ENUM(p, A_PtfThirdCompo_OwnershipRuleEn)));
}
inline ThirdCustomerCustRoleEn      GET_S_PtfThirdCompo_OwnershipRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (GET_ENUM(p, S_PtfThirdCompo_OwnershipRuleEn)));
}

inline ThirdCustomerCustRoleEn      _GET_A_PtfThirdCompo_OwnershipRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (_GET_ENUM(p, A_PtfThirdCompo_OwnershipRuleEn)));
}
inline ThirdCustomerCustRoleEn      _GET_S_PtfThirdCompo_OwnershipRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (_GET_ENUM(p, S_PtfThirdCompo_OwnershipRuleEn)));
}

inline void                         SET_A_PtfThirdCompo_OwnershipRuleEn(DBA_DYNFLD_STP p, ThirdCustomerCustRoleEn enumValue)
{
    SET_ENUM(p, A_PtfThirdCompo_OwnershipRuleEn, enumValue);
}
inline void                         SET_S_PtfThirdCompo_OwnershipRuleEn(DBA_DYNFLD_STP p, ThirdCustomerCustRoleEn enumValue)
{
    SET_ENUM(p, S_PtfThirdCompo_OwnershipRuleEn, enumValue);
}


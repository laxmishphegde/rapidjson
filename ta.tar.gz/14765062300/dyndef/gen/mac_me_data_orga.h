/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline MeDataOrgaDataScopeEn        GET_A_MeDataOrga_DataScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaDataScopeEn>  (GET_ENUM(p, A_MeDataOrga_DataScopeEn)));
}
inline MeDataOrgaActionEn           GET_A_MeDataOrga_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaActionEn>  (GET_ENUM(p, A_MeDataOrga_ActionEn)));
}
inline MeDataOrgaActionEn           GET_S_MeDataOrga_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaActionEn>  (GET_ENUM(p, S_MeDataOrga_ActionEn)));
}
inline MeDataOrgaStatusEn           GET_A_MeDataOrga_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (GET_ENUM(p, A_MeDataOrga_StatusEn)));
}
inline MeDataOrgaStatusEn           GET_S_MeDataOrga_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (GET_ENUM(p, S_MeDataOrga_StatusEn)));
}

inline MeDataOrgaDataScopeEn        _GET_A_MeDataOrga_DataScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaDataScopeEn>  (_GET_ENUM(p, A_MeDataOrga_DataScopeEn)));
}
inline MeDataOrgaActionEn           _GET_A_MeDataOrga_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaActionEn>  (_GET_ENUM(p, A_MeDataOrga_ActionEn)));
}
inline MeDataOrgaActionEn           _GET_S_MeDataOrga_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaActionEn>  (_GET_ENUM(p, S_MeDataOrga_ActionEn)));
}
inline MeDataOrgaStatusEn           _GET_A_MeDataOrga_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (_GET_ENUM(p, A_MeDataOrga_StatusEn)));
}
inline MeDataOrgaStatusEn           _GET_S_MeDataOrga_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (_GET_ENUM(p, S_MeDataOrga_StatusEn)));
}

inline void                         SET_A_MeDataOrga_DataScopeEn(DBA_DYNFLD_STP p, MeDataOrgaDataScopeEn enumValue)
{
    SET_ENUM(p, A_MeDataOrga_DataScopeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MeDataOrga_ActionEn(DBA_DYNFLD_STP p, MeDataOrgaActionEn enumValue)
{
    SET_ENUM(p, A_MeDataOrga_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MeDataOrga_ActionEn(DBA_DYNFLD_STP p, MeDataOrgaActionEn enumValue)
{
    SET_ENUM(p, S_MeDataOrga_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MeDataOrga_StatusEn(DBA_DYNFLD_STP p, MeDataOrgaStatusEn enumValue)
{
    SET_ENUM(p, A_MeDataOrga_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MeDataOrga_StatusEn(DBA_DYNFLD_STP p, MeDataOrgaStatusEn enumValue)
{
    SET_ENUM(p, S_MeDataOrga_StatusEn, static_cast<unsigned char>(enumValue));
}


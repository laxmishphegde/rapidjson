/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PackageCompositionActionEn   GET_A_PackageComposition_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (GET_ENUM(p, A_PackageComposition_ActionEn)));
}
inline PackageCompositionActionEn   GET_S_PackageComposition_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (GET_ENUM(p, S_PackageComposition_ActionEn)));
}
inline PackageDefinitionSimulationStatusEn GET_A_PackageComposition_SimulationStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionSimulationStatusEn>  (GET_ENUM(p, A_PackageComposition_SimulationStatusEn)));
}

inline PackageCompositionActionEn   _GET_A_PackageComposition_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (_GET_ENUM(p, A_PackageComposition_ActionEn)));
}
inline PackageCompositionActionEn   _GET_S_PackageComposition_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageCompositionActionEn>  (_GET_ENUM(p, S_PackageComposition_ActionEn)));
}
inline PackageDefinitionSimulationStatusEn _GET_A_PackageComposition_SimulationStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionSimulationStatusEn>  (_GET_ENUM(p, A_PackageComposition_SimulationStatusEn)));
}

inline void                         SET_A_PackageComposition_ActionEn(DBA_DYNFLD_STP p, PackageCompositionActionEn enumValue)
{
    SET_ENUM(p, A_PackageComposition_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PackageComposition_ActionEn(DBA_DYNFLD_STP p, PackageCompositionActionEn enumValue)
{
    SET_ENUM(p, S_PackageComposition_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PackageComposition_SimulationStatusEn(DBA_DYNFLD_STP p, PackageDefinitionSimulationStatusEn enumValue)
{
    SET_ENUM(p, A_PackageComposition_SimulationStatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline SimulatedWashSaleLossStatusEn GET_A_SimulatedWashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SimulatedWashSaleLossStatusEn>  (GET_ENUM(p, A_SimulatedWashSaleLoss_StatusEn)));
}
inline SimulatedWashSaleLossStatusEn GET_S_SimulatedWashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SimulatedWashSaleLossStatusEn>  (GET_ENUM(p, S_SimulatedWashSaleLoss_StatusEn)));
}

inline SimulatedWashSaleLossStatusEn _GET_A_SimulatedWashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SimulatedWashSaleLossStatusEn>  (_GET_ENUM(p, A_SimulatedWashSaleLoss_StatusEn)));
}
inline SimulatedWashSaleLossStatusEn _GET_S_SimulatedWashSaleLoss_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SimulatedWashSaleLossStatusEn>  (_GET_ENUM(p, S_SimulatedWashSaleLoss_StatusEn)));
}

inline void                         SET_A_SimulatedWashSaleLoss_StatusEn(DBA_DYNFLD_STP p, SimulatedWashSaleLossStatusEn enumValue)
{
    SET_ENUM(p, A_SimulatedWashSaleLoss_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_SimulatedWashSaleLoss_StatusEn(DBA_DYNFLD_STP p, SimulatedWashSaleLossStatusEn enumValue)
{
    SET_ENUM(p, S_SimulatedWashSaleLoss_StatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline DictAttributeTemplateMeRecordLocationEn GET_A_TascJobTable_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, A_TascJobTable_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_S_TascJobTable_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, S_TascJobTable_MeRecordLocationEn)));
}

inline DictAttributeTemplateMeRecordLocationEn _GET_A_TascJobTable_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, A_TascJobTable_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_S_TascJobTable_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, S_TascJobTable_MeRecordLocationEn)));
}

inline void                         SET_A_TascJobTable_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, A_TascJobTable_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TascJobTable_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, S_TascJobTable_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}


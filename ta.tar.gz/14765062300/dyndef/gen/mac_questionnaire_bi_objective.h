/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestionnaireBiObjectiveRecomNatEn GET_A_QuestionnaireBiObjective_RecomNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireBiObjectiveRecomNatEn>  (GET_ENUM(p, A_QuestionnaireBiObjective_RecomNatEn)));
}
inline QuestionnaireBiObjectiveOperatorEn GET_A_QuestionnaireBiObjective_OperatorEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireBiObjectiveOperatorEn>  (GET_ENUM(p, A_QuestionnaireBiObjective_OperatorEn)));
}
inline QuestionnaireBiObjectiveValueDataTypeEn GET_A_QuestionnaireBiObjective_ValueDataTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireBiObjectiveValueDataTypeEn>  (GET_ENUM(p, A_QuestionnaireBiObjective_ValueDataTypeEn)));
}

inline QuestionnaireBiObjectiveRecomNatEn _GET_A_QuestionnaireBiObjective_RecomNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireBiObjectiveRecomNatEn>  (_GET_ENUM(p, A_QuestionnaireBiObjective_RecomNatEn)));
}
inline QuestionnaireBiObjectiveOperatorEn _GET_A_QuestionnaireBiObjective_OperatorEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireBiObjectiveOperatorEn>  (_GET_ENUM(p, A_QuestionnaireBiObjective_OperatorEn)));
}
inline QuestionnaireBiObjectiveValueDataTypeEn _GET_A_QuestionnaireBiObjective_ValueDataTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireBiObjectiveValueDataTypeEn>  (_GET_ENUM(p, A_QuestionnaireBiObjective_ValueDataTypeEn)));
}

inline void                         SET_A_QuestionnaireBiObjective_RecomNatEn(DBA_DYNFLD_STP p, QuestionnaireBiObjectiveRecomNatEn enumValue)
{
    SET_ENUM(p, A_QuestionnaireBiObjective_RecomNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_QuestionnaireBiObjective_OperatorEn(DBA_DYNFLD_STP p, QuestionnaireBiObjectiveOperatorEn enumValue)
{
    SET_ENUM(p, A_QuestionnaireBiObjective_OperatorEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_QuestionnaireBiObjective_ValueDataTypeEn(DBA_DYNFLD_STP p, QuestionnaireBiObjectiveValueDataTypeEn enumValue)
{
    SET_ENUM(p, A_QuestionnaireBiObjective_ValueDataTypeEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline OutboxEventSchemaNatEn       GET_A_OutboxEventSchema_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxEventSchemaNatEn>  (GET_ENUM(p, A_OutboxEventSchema_NatEn)));
}

inline OutboxEventSchemaNatEn       _GET_A_OutboxEventSchema_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxEventSchemaNatEn>  (_GET_ENUM(p, A_OutboxEventSchema_NatEn)));
}

inline void                         SET_A_OutboxEventSchema_NatEn(DBA_DYNFLD_STP p, OutboxEventSchemaNatEn enumValue)
{
    SET_ENUM(p, A_OutboxEventSchema_NatEn, static_cast<unsigned char>(enumValue));
}


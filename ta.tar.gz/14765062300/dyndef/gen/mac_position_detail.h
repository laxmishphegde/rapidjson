/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PerfTimingRuleTimingRuleEn   GET_A_PositionDetail_TimingRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfTimingRuleTimingRuleEn>  (GET_ENUM(p, A_PositionDetail_TimingRuleEn)));
}

inline PerfTimingRuleTimingRuleEn   _GET_A_PositionDetail_TimingRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfTimingRuleTimingRuleEn>  (_GET_ENUM(p, A_PositionDetail_TimingRuleEn)));
}

inline void                         SET_A_PositionDetail_TimingRuleEn(DBA_DYNFLD_STP p, PerfTimingRuleTimingRuleEn enumValue)
{
    SET_ENUM(p, A_PositionDetail_TimingRuleEn, static_cast<unsigned char>(enumValue));
}


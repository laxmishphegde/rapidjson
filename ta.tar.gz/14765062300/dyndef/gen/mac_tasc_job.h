/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TascJobAccessEn              GET_A_TascJob_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascJobAccessEn>  (GET_ENUM(p, A_TascJob_AccessEn)));
}
inline TascJobModeEn                GET_A_TascJob_ModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascJobModeEn>  (GET_ENUM(p, A_TascJob_ModeEn)));
}
inline TascJobValidEn               GET_A_TascJob_ValidEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascJobValidEn>  (GET_ENUM(p, A_TascJob_ValidEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_A_TascJob_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, A_TascJob_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_S_TascJob_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, S_TascJob_MeRecordLocationEn)));
}

inline TascJobAccessEn              _GET_A_TascJob_AccessEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascJobAccessEn>  (_GET_ENUM(p, A_TascJob_AccessEn)));
}
inline TascJobModeEn                _GET_A_TascJob_ModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascJobModeEn>  (_GET_ENUM(p, A_TascJob_ModeEn)));
}
inline TascJobValidEn               _GET_A_TascJob_ValidEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TascJobValidEn>  (_GET_ENUM(p, A_TascJob_ValidEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_A_TascJob_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, A_TascJob_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_S_TascJob_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, S_TascJob_MeRecordLocationEn)));
}

inline void                         SET_A_TascJob_AccessEn(DBA_DYNFLD_STP p, TascJobAccessEn enumValue)
{
    SET_ENUM(p, A_TascJob_AccessEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TascJob_ModeEn(DBA_DYNFLD_STP p, TascJobModeEn enumValue)
{
    SET_ENUM(p, A_TascJob_ModeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TascJob_ValidEn(DBA_DYNFLD_STP p, TascJobValidEn enumValue)
{
    SET_ENUM(p, A_TascJob_ValidEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TascJob_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, A_TascJob_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TascJob_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, S_TascJob_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}


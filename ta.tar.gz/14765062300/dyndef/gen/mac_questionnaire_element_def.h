/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestEltDefNatEn             GET_A_QuestEltDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestEltDefNatEn>  (GET_ENUM(p, A_QuestEltDef_NatEn)));
}
inline QuestEltDefNatEn             GET_S_QuestEltDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestEltDefNatEn>  (GET_ENUM(p, S_QuestEltDef_NatEn)));
}
inline QuestEltDefDefValueEn        GET_A_QuestEltDef_DefValueEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestEltDefDefValueEn>  (GET_ENUM(p, A_QuestEltDef_DefValueEn)));
}

inline QuestEltDefNatEn             _GET_A_QuestEltDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestEltDefNatEn>  (_GET_ENUM(p, A_QuestEltDef_NatEn)));
}
inline QuestEltDefNatEn             _GET_S_QuestEltDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestEltDefNatEn>  (_GET_ENUM(p, S_QuestEltDef_NatEn)));
}
inline QuestEltDefDefValueEn        _GET_A_QuestEltDef_DefValueEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestEltDefDefValueEn>  (_GET_ENUM(p, A_QuestEltDef_DefValueEn)));
}

inline void                         SET_A_QuestEltDef_NatEn(DBA_DYNFLD_STP p, QuestEltDefNatEn enumValue)
{
    SET_ENUM(p, A_QuestEltDef_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_QuestEltDef_NatEn(DBA_DYNFLD_STP p, QuestEltDefNatEn enumValue)
{
    SET_ENUM(p, S_QuestEltDef_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_QuestEltDef_DefValueEn(DBA_DYNFLD_STP p, QuestEltDefDefValueEn enumValue)
{
    SET_ENUM(p, A_QuestEltDef_DefValueEn, static_cast<unsigned char>(enumValue));
}


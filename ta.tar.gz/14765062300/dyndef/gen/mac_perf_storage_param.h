/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PtfRetFreqUnitEn             GET_A_PerfStorageParam_FrequencyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (GET_ENUM(p, A_PerfStorageParam_FrequencyEn)));
}
inline PtfRetFreqUnitEn             GET_S_PerfStorageParam_FrequencyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (GET_ENUM(p, S_PerfStorageParam_FrequencyEn)));
}
inline PerfStorageParamCheckedDataEn GET_A_PerfStorageParam_CheckedDataEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfStorageParamCheckedDataEn>  (GET_ENUM(p, A_PerfStorageParam_CheckedDataEn)));
}

inline PtfRetFreqUnitEn             _GET_A_PerfStorageParam_FrequencyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (_GET_ENUM(p, A_PerfStorageParam_FrequencyEn)));
}
inline PtfRetFreqUnitEn             _GET_S_PerfStorageParam_FrequencyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (_GET_ENUM(p, S_PerfStorageParam_FrequencyEn)));
}
inline PerfStorageParamCheckedDataEn _GET_A_PerfStorageParam_CheckedDataEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfStorageParamCheckedDataEn>  (_GET_ENUM(p, A_PerfStorageParam_CheckedDataEn)));
}

inline void                         SET_A_PerfStorageParam_FrequencyEn(DBA_DYNFLD_STP p, PtfRetFreqUnitEn enumValue)
{
    SET_ENUM(p, A_PerfStorageParam_FrequencyEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PerfStorageParam_FrequencyEn(DBA_DYNFLD_STP p, PtfRetFreqUnitEn enumValue)
{
    SET_ENUM(p, S_PerfStorageParam_FrequencyEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfStorageParam_CheckedDataEn(DBA_DYNFLD_STP p, PerfStorageParamCheckedDataEn enumValue)
{
    SET_ENUM(p, A_PerfStorageParam_CheckedDataEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TacticalModelOpNatEn         GET_A_TacticalModel_OpNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TacticalModelOpNatEn>  (GET_ENUM(p, A_TacticalModel_OpNatEn)));
}
inline TacticalModelOpNatEn         GET_S_TacticalModel_OpNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TacticalModelOpNatEn>  (GET_ENUM(p, S_TacticalModel_OpNatEn)));
}

inline TacticalModelOpNatEn         _GET_A_TacticalModel_OpNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TacticalModelOpNatEn>  (_GET_ENUM(p, A_TacticalModel_OpNatEn)));
}
inline TacticalModelOpNatEn         _GET_S_TacticalModel_OpNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TacticalModelOpNatEn>  (_GET_ENUM(p, S_TacticalModel_OpNatEn)));
}

inline void                         SET_A_TacticalModel_OpNatEn(DBA_DYNFLD_STP p, TacticalModelOpNatEn enumValue)
{
    SET_ENUM(p, A_TacticalModel_OpNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TacticalModel_OpNatEn(DBA_DYNFLD_STP p, TacticalModelOpNatEn enumValue)
{
    SET_ENUM(p, S_TacticalModel_OpNatEn, static_cast<unsigned char>(enumValue));
}


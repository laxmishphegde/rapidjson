/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PerfCalcDefReturnMethodEn    GET_A_PerfAnalysisParam_ReturnMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefReturnMethodEn>  (GET_ENUM(p, A_PerfAnalysisParam_ReturnMethodEn)));
}
inline PerfCalcDefReturnMethodEn    GET_S_PerfAnalysisParam_ReturnMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefReturnMethodEn>  (GET_ENUM(p, S_PerfAnalysisParam_ReturnMethodEn)));
}
inline PerfAnalysisParamConvRuleEn  GET_A_PerfAnalysisParam_ConvRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfAnalysisParamConvRuleEn>  (GET_ENUM(p, A_PerfAnalysisParam_ConvRuleEn)));
}
inline PerfAnalysisParamMergeRuleEn GET_A_PerfAnalysisParam_MergeRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfAnalysisParamMergeRuleEn>  (GET_ENUM(p, A_PerfAnalysisParam_MergeRuleEn)));
}
inline PerfAnalysisParamChainRuleEn GET_A_PerfAnalysisParam_ChainRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfAnalysisParamChainRuleEn>  (GET_ENUM(p, A_PerfAnalysisParam_ChainRuleEn)));
}

inline PerfCalcDefReturnMethodEn    _GET_A_PerfAnalysisParam_ReturnMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefReturnMethodEn>  (_GET_ENUM(p, A_PerfAnalysisParam_ReturnMethodEn)));
}
inline PerfCalcDefReturnMethodEn    _GET_S_PerfAnalysisParam_ReturnMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefReturnMethodEn>  (_GET_ENUM(p, S_PerfAnalysisParam_ReturnMethodEn)));
}
inline PerfAnalysisParamConvRuleEn  _GET_A_PerfAnalysisParam_ConvRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfAnalysisParamConvRuleEn>  (_GET_ENUM(p, A_PerfAnalysisParam_ConvRuleEn)));
}
inline PerfAnalysisParamMergeRuleEn _GET_A_PerfAnalysisParam_MergeRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfAnalysisParamMergeRuleEn>  (_GET_ENUM(p, A_PerfAnalysisParam_MergeRuleEn)));
}
inline PerfAnalysisParamChainRuleEn _GET_A_PerfAnalysisParam_ChainRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfAnalysisParamChainRuleEn>  (_GET_ENUM(p, A_PerfAnalysisParam_ChainRuleEn)));
}

inline void                         SET_A_PerfAnalysisParam_ReturnMethodEn(DBA_DYNFLD_STP p, PerfCalcDefReturnMethodEn enumValue)
{
    SET_ENUM(p, A_PerfAnalysisParam_ReturnMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PerfAnalysisParam_ReturnMethodEn(DBA_DYNFLD_STP p, PerfCalcDefReturnMethodEn enumValue)
{
    SET_ENUM(p, S_PerfAnalysisParam_ReturnMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfAnalysisParam_ConvRuleEn(DBA_DYNFLD_STP p, PerfAnalysisParamConvRuleEn enumValue)
{
    SET_ENUM(p, A_PerfAnalysisParam_ConvRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfAnalysisParam_MergeRuleEn(DBA_DYNFLD_STP p, PerfAnalysisParamMergeRuleEn enumValue)
{
    SET_ENUM(p, A_PerfAnalysisParam_MergeRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfAnalysisParam_ChainRuleEn(DBA_DYNFLD_STP p, PerfAnalysisParamChainRuleEn enumValue)
{
    SET_ENUM(p, A_PerfAnalysisParam_ChainRuleEn, static_cast<unsigned char>(enumValue));
}


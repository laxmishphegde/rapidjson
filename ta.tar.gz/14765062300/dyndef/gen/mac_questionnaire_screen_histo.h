/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestDefStatusEn             GET_A_QuestScreenHisto_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefStatusEn>  (GET_ENUM(p, A_QuestScreenHisto_StatusEn)));
}

inline QuestDefStatusEn             _GET_A_QuestScreenHisto_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestDefStatusEn>  (_GET_ENUM(p, A_QuestScreenHisto_StatusEn)));
}

inline void                         SET_A_QuestScreenHisto_StatusEn(DBA_DYNFLD_STP p, QuestDefStatusEn enumValue)
{
    SET_ENUM(p, A_QuestScreenHisto_StatusEn, enumValue);
}


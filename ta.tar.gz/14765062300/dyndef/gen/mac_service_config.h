/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ServiceConfigNatEn           GET_A_ServiceConfig_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigNatEn>  (GET_ENUM(p, A_ServiceConfig_NatEn)));
}
inline ServiceConfigNatEn           GET_S_ServiceConfig_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigNatEn>  (GET_ENUM(p, S_ServiceConfig_NatEn)));
}
inline ServiceConfigStatusEn        GET_A_ServiceConfig_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigStatusEn>  (GET_ENUM(p, A_ServiceConfig_StatusEn)));
}
inline ServiceConfigStatusEn        GET_S_ServiceConfig_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigStatusEn>  (GET_ENUM(p, S_ServiceConfig_StatusEn)));
}

inline ServiceConfigNatEn           _GET_A_ServiceConfig_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigNatEn>  (_GET_ENUM(p, A_ServiceConfig_NatEn)));
}
inline ServiceConfigNatEn           _GET_S_ServiceConfig_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigNatEn>  (_GET_ENUM(p, S_ServiceConfig_NatEn)));
}
inline ServiceConfigStatusEn        _GET_A_ServiceConfig_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigStatusEn>  (_GET_ENUM(p, A_ServiceConfig_StatusEn)));
}
inline ServiceConfigStatusEn        _GET_S_ServiceConfig_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ServiceConfigStatusEn>  (_GET_ENUM(p, S_ServiceConfig_StatusEn)));
}

inline void                         SET_A_ServiceConfig_NatEn(DBA_DYNFLD_STP p, ServiceConfigNatEn enumValue)
{
    SET_ENUM(p, A_ServiceConfig_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ServiceConfig_NatEn(DBA_DYNFLD_STP p, ServiceConfigNatEn enumValue)
{
    SET_ENUM(p, S_ServiceConfig_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ServiceConfig_StatusEn(DBA_DYNFLD_STP p, ServiceConfigStatusEn enumValue)
{
    SET_ENUM(p, A_ServiceConfig_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ServiceConfig_StatusEn(DBA_DYNFLD_STP p, ServiceConfigStatusEn enumValue)
{
    SET_ENUM(p, S_ServiceConfig_StatusEn, static_cast<unsigned char>(enumValue));
}


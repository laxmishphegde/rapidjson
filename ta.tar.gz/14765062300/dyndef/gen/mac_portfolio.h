/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PtfFusionRuleEn              GET_A_Ptf_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (GET_ENUM(p, A_Ptf_FusionRuleEn)));
}
inline PtfFusionDateRuleEn          GET_A_Ptf_FusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionDateRuleEn>  (GET_ENUM(p, A_Ptf_FusionDateRuleEn)));
}
inline PtfFusionDateRuleEn          GET_S_Ptf_FusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionDateRuleEn>  (GET_ENUM(p, S_Ptf_FusionDateRuleEn)));
}
inline PtfNatEn                     GET_A_Ptf_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNatEn>  (GET_ENUM(p, A_Ptf_NatEn)));
}
inline PtfPosLogicalEn              GET_A_Ptf_PosLogicalEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfPosLogicalEn>  (GET_ENUM(p, A_Ptf_PosLogicalEn)));
}
inline PtfGroupEn                   GET_A_Ptf_GroupEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfGroupEn>  (GET_ENUM(p, A_Ptf_GroupEn)));
}
inline PtfRetFreqUnitEn             GET_A_Ptf_RetFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (GET_ENUM(p, A_Ptf_RetFreqUnitEn)));
}
inline PtfRetDetLevelEn             GET_A_Ptf_RetDetLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetDetLevelEn>  (GET_ENUM(p, A_Ptf_RetDetLevelEn)));
}
inline PtfRetFreqUnitEn             GET_A_Ptf_PerfFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (GET_ENUM(p, A_Ptf_PerfFreqUnitEn)));
}
inline PtfRetDetLevelEn             GET_A_Ptf_PerfDetLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetDetLevelEn>  (GET_ENUM(p, A_Ptf_PerfDetLevelEn)));
}
inline PtfDefaultRecomEn            GET_A_Ptf_DefaultRecomEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfDefaultRecomEn>  (GET_ENUM(p, A_Ptf_DefaultRecomEn)));
}
inline PtfHeartUploadEn             GET_A_Ptf_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHeartUploadEn>  (GET_ENUM(p, A_Ptf_HeartUploadEn)));
}
inline PtfOldFusionDateRuleEn       GET_A_Ptf_OldFusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOldFusionDateRuleEn>  (GET_ENUM(p, A_Ptf_OldFusionDateRuleEn)));
}
inline PtfOldFusionDateRuleEn       GET_S_Ptf_OldFusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOldFusionDateRuleEn>  (GET_ENUM(p, S_Ptf_OldFusionDateRuleEn)));
}
inline PtfDividendAccrualEn         GET_A_Ptf_DividendAccrualEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfDividendAccrualEn>  (GET_ENUM(p, A_Ptf_DividendAccrualEn)));
}
inline PtfNegativeCashEn            GET_A_Ptf_NegativeCashEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNegativeCashEn>  (GET_ENUM(p, A_Ptf_NegativeCashEn)));
}
inline PtfStatusEn                  GET_A_Ptf_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfStatusEn>  (GET_ENUM(p, A_Ptf_StatusEn)));
}
inline InstrIslamicComplianceEn     GET_A_Ptf_ShariaEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (GET_ENUM(p, A_Ptf_ShariaEn)));
}
inline PtfMarginLendingEn           GET_A_Ptf_MarginLendingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfMarginLendingEn>  (GET_ENUM(p, A_Ptf_MarginLendingEn)));
}
inline PtfCreditStatusEn            GET_A_Ptf_CreditStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfCreditStatusEn>  (GET_ENUM(p, A_Ptf_CreditStatusEn)));
}
inline PtfTaxLotMngtEn              GET_A_Ptf_TaxLotMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfTaxLotMngtEn>  (GET_ENUM(p, A_Ptf_TaxLotMngtEn)));
}
inline PtfLastRebalancingStatusEn   GET_A_Ptf_LastRebalancingStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfLastRebalancingStatusEn>  (GET_ENUM(p, A_Ptf_LastRebalancingStatusEn)));
}
inline PtfCurrentWithdreqStatusEn   GET_A_Ptf_CurrentWithdreqStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfCurrentWithdreqStatusEn>  (GET_ENUM(p, A_Ptf_CurrentWithdreqStatusEn)));
}
inline PtfHcPositionDiffEn          GET_A_Ptf_HcPositionDiffEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHcPositionDiffEn>  (GET_ENUM(p, A_Ptf_HcPositionDiffEn)));
}
inline PtfHcTaxlotDiffEn            GET_A_Ptf_HcTaxlotDiffEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHcTaxlotDiffEn>  (GET_ENUM(p, A_Ptf_HcTaxlotDiffEn)));
}
inline PtfCashBookingModelEn        GET_A_Ptf_CashBookingModelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfCashBookingModelEn>  (GET_ENUM(p, A_Ptf_CashBookingModelEn)));
}
inline PtfOrderNettingEn            GET_A_Ptf_OrderNettingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOrderNettingEn>  (GET_ENUM(p, A_Ptf_OrderNettingEn)));
}
inline PtfOverlayStatusEn           GET_A_Ptf_OverlayStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOverlayStatusEn>  (GET_ENUM(p, A_Ptf_OverlayStatusEn)));
}
inline PtfQuasiCashEn               GET_A_Ptf_QuasiCashEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfQuasiCashEn>  (GET_ENUM(p, A_Ptf_QuasiCashEn)));
}
inline PtfOrderAllocRuleEn          GET_A_Ptf_OrderAllocRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOrderAllocRuleEn>  (GET_ENUM(p, A_Ptf_OrderAllocRuleEn)));
}
inline PtfOrderBuyAllocRuleEn       GET_A_Ptf_OrderBuyAllocRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOrderBuyAllocRuleEn>  (GET_ENUM(p, A_Ptf_OrderBuyAllocRuleEn)));
}
inline PtfHcPerfDiffEn              GET_A_Ptf_HcPerfDiffEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHcPerfDiffEn>  (GET_ENUM(p, A_Ptf_HcPerfDiffEn)));
}
inline PtfHierGroupOrderEn          GET_A_Ptf_HierGroupOrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHierGroupOrderEn>  (GET_ENUM(p, A_Ptf_HierGroupOrderEn)));
}
inline PtfSubNatEn                  GET_A_Ptf_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfSubNatEn>  (GET_ENUM(p, A_Ptf_SubNatEn)));
}
inline PtfOverlayManagedEn          GET_A_Ptf_OverlayManagedEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOverlayManagedEn>  (GET_ENUM(p, A_Ptf_OverlayManagedEn)));
}
inline PtfMvDrpReportFreqEn         GET_A_Ptf_MvDrpReportFreqEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfMvDrpReportFreqEn>  (GET_ENUM(p, A_Ptf_MvDrpReportFreqEn)));
}
inline DictAttributeTemplatePrivilegeEn GET_A_Ptf_PrivilegeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplatePrivilegeEn>  (GET_ENUM(p, A_Ptf_PrivilegeEn)));
}
inline DictAttributeTemplateDlmEn   GET_A_Ptf_DlmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateDlmEn>  (GET_ENUM(p, A_Ptf_DlmEn)));
}

inline PtfFusionRuleEn              _GET_A_Ptf_FusionRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionRuleEn>  (_GET_ENUM(p, A_Ptf_FusionRuleEn)));
}
inline PtfFusionDateRuleEn          _GET_A_Ptf_FusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionDateRuleEn>  (_GET_ENUM(p, A_Ptf_FusionDateRuleEn)));
}
inline PtfFusionDateRuleEn          _GET_S_Ptf_FusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfFusionDateRuleEn>  (_GET_ENUM(p, S_Ptf_FusionDateRuleEn)));
}
inline PtfNatEn                     _GET_A_Ptf_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNatEn>  (_GET_ENUM(p, A_Ptf_NatEn)));
}
inline PtfPosLogicalEn              _GET_A_Ptf_PosLogicalEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfPosLogicalEn>  (_GET_ENUM(p, A_Ptf_PosLogicalEn)));
}
inline PtfGroupEn                   _GET_A_Ptf_GroupEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfGroupEn>  (_GET_ENUM(p, A_Ptf_GroupEn)));
}
inline PtfRetFreqUnitEn             _GET_A_Ptf_RetFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (_GET_ENUM(p, A_Ptf_RetFreqUnitEn)));
}
inline PtfRetDetLevelEn             _GET_A_Ptf_RetDetLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetDetLevelEn>  (_GET_ENUM(p, A_Ptf_RetDetLevelEn)));
}
inline PtfRetFreqUnitEn             _GET_A_Ptf_PerfFreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (_GET_ENUM(p, A_Ptf_PerfFreqUnitEn)));
}
inline PtfRetDetLevelEn             _GET_A_Ptf_PerfDetLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetDetLevelEn>  (_GET_ENUM(p, A_Ptf_PerfDetLevelEn)));
}
inline PtfDefaultRecomEn            _GET_A_Ptf_DefaultRecomEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfDefaultRecomEn>  (_GET_ENUM(p, A_Ptf_DefaultRecomEn)));
}
inline PtfHeartUploadEn             _GET_A_Ptf_HeartUploadEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHeartUploadEn>  (_GET_ENUM(p, A_Ptf_HeartUploadEn)));
}
inline PtfOldFusionDateRuleEn       _GET_A_Ptf_OldFusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOldFusionDateRuleEn>  (_GET_ENUM(p, A_Ptf_OldFusionDateRuleEn)));
}
inline PtfOldFusionDateRuleEn       _GET_S_Ptf_OldFusionDateRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOldFusionDateRuleEn>  (_GET_ENUM(p, S_Ptf_OldFusionDateRuleEn)));
}
inline PtfDividendAccrualEn         _GET_A_Ptf_DividendAccrualEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfDividendAccrualEn>  (_GET_ENUM(p, A_Ptf_DividendAccrualEn)));
}
inline PtfNegativeCashEn            _GET_A_Ptf_NegativeCashEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfNegativeCashEn>  (_GET_ENUM(p, A_Ptf_NegativeCashEn)));
}
inline PtfStatusEn                  _GET_A_Ptf_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfStatusEn>  (_GET_ENUM(p, A_Ptf_StatusEn)));
}
inline InstrIslamicComplianceEn     _GET_A_Ptf_ShariaEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrIslamicComplianceEn>  (_GET_ENUM(p, A_Ptf_ShariaEn)));
}
inline PtfMarginLendingEn           _GET_A_Ptf_MarginLendingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfMarginLendingEn>  (_GET_ENUM(p, A_Ptf_MarginLendingEn)));
}
inline PtfCreditStatusEn            _GET_A_Ptf_CreditStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfCreditStatusEn>  (_GET_ENUM(p, A_Ptf_CreditStatusEn)));
}
inline PtfTaxLotMngtEn              _GET_A_Ptf_TaxLotMngtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfTaxLotMngtEn>  (_GET_ENUM(p, A_Ptf_TaxLotMngtEn)));
}
inline PtfLastRebalancingStatusEn   _GET_A_Ptf_LastRebalancingStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfLastRebalancingStatusEn>  (_GET_ENUM(p, A_Ptf_LastRebalancingStatusEn)));
}
inline PtfCurrentWithdreqStatusEn   _GET_A_Ptf_CurrentWithdreqStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfCurrentWithdreqStatusEn>  (_GET_ENUM(p, A_Ptf_CurrentWithdreqStatusEn)));
}
inline PtfHcPositionDiffEn          _GET_A_Ptf_HcPositionDiffEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHcPositionDiffEn>  (_GET_ENUM(p, A_Ptf_HcPositionDiffEn)));
}
inline PtfHcTaxlotDiffEn            _GET_A_Ptf_HcTaxlotDiffEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHcTaxlotDiffEn>  (_GET_ENUM(p, A_Ptf_HcTaxlotDiffEn)));
}
inline PtfCashBookingModelEn        _GET_A_Ptf_CashBookingModelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfCashBookingModelEn>  (_GET_ENUM(p, A_Ptf_CashBookingModelEn)));
}
inline PtfOrderNettingEn            _GET_A_Ptf_OrderNettingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOrderNettingEn>  (_GET_ENUM(p, A_Ptf_OrderNettingEn)));
}
inline PtfOverlayStatusEn           _GET_A_Ptf_OverlayStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOverlayStatusEn>  (_GET_ENUM(p, A_Ptf_OverlayStatusEn)));
}
inline PtfQuasiCashEn               _GET_A_Ptf_QuasiCashEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfQuasiCashEn>  (_GET_ENUM(p, A_Ptf_QuasiCashEn)));
}
inline PtfOrderAllocRuleEn          _GET_A_Ptf_OrderAllocRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOrderAllocRuleEn>  (_GET_ENUM(p, A_Ptf_OrderAllocRuleEn)));
}
inline PtfOrderBuyAllocRuleEn       _GET_A_Ptf_OrderBuyAllocRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOrderBuyAllocRuleEn>  (_GET_ENUM(p, A_Ptf_OrderBuyAllocRuleEn)));
}
inline PtfHcPerfDiffEn              _GET_A_Ptf_HcPerfDiffEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHcPerfDiffEn>  (_GET_ENUM(p, A_Ptf_HcPerfDiffEn)));
}
inline PtfHierGroupOrderEn          _GET_A_Ptf_HierGroupOrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfHierGroupOrderEn>  (_GET_ENUM(p, A_Ptf_HierGroupOrderEn)));
}
inline PtfSubNatEn                  _GET_A_Ptf_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfSubNatEn>  (_GET_ENUM(p, A_Ptf_SubNatEn)));
}
inline PtfOverlayManagedEn          _GET_A_Ptf_OverlayManagedEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfOverlayManagedEn>  (_GET_ENUM(p, A_Ptf_OverlayManagedEn)));
}
inline PtfMvDrpReportFreqEn         _GET_A_Ptf_MvDrpReportFreqEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfMvDrpReportFreqEn>  (_GET_ENUM(p, A_Ptf_MvDrpReportFreqEn)));
}
inline DictAttributeTemplatePrivilegeEn _GET_A_Ptf_PrivilegeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplatePrivilegeEn>  (_GET_ENUM(p, A_Ptf_PrivilegeEn)));
}
inline DictAttributeTemplateDlmEn   _GET_A_Ptf_DlmEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateDlmEn>  (_GET_ENUM(p, A_Ptf_DlmEn)));
}

inline void                         SET_A_Ptf_FusionRuleEn(DBA_DYNFLD_STP p, PtfFusionRuleEn enumValue)
{
    SET_ENUM(p, A_Ptf_FusionRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_FusionDateRuleEn(DBA_DYNFLD_STP p, PtfFusionDateRuleEn enumValue)
{
    SET_ENUM(p, A_Ptf_FusionDateRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Ptf_FusionDateRuleEn(DBA_DYNFLD_STP p, PtfFusionDateRuleEn enumValue)
{
    SET_ENUM(p, S_Ptf_FusionDateRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_NatEn(DBA_DYNFLD_STP p, PtfNatEn enumValue)
{
    SET_ENUM(p, A_Ptf_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_PosLogicalEn(DBA_DYNFLD_STP p, PtfPosLogicalEn enumValue)
{
    SET_ENUM(p, A_Ptf_PosLogicalEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_GroupEn(DBA_DYNFLD_STP p, PtfGroupEn enumValue)
{
    SET_ENUM(p, A_Ptf_GroupEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_RetFreqUnitEn(DBA_DYNFLD_STP p, PtfRetFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Ptf_RetFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_RetDetLevelEn(DBA_DYNFLD_STP p, PtfRetDetLevelEn enumValue)
{
    SET_ENUM(p, A_Ptf_RetDetLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_PerfFreqUnitEn(DBA_DYNFLD_STP p, PtfRetFreqUnitEn enumValue)
{
    SET_ENUM(p, A_Ptf_PerfFreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_PerfDetLevelEn(DBA_DYNFLD_STP p, PtfRetDetLevelEn enumValue)
{
    SET_ENUM(p, A_Ptf_PerfDetLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_DefaultRecomEn(DBA_DYNFLD_STP p, PtfDefaultRecomEn enumValue)
{
    SET_ENUM(p, A_Ptf_DefaultRecomEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_HeartUploadEn(DBA_DYNFLD_STP p, PtfHeartUploadEn enumValue)
{
    SET_ENUM(p, A_Ptf_HeartUploadEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_OldFusionDateRuleEn(DBA_DYNFLD_STP p, PtfOldFusionDateRuleEn enumValue)
{
    SET_ENUM(p, A_Ptf_OldFusionDateRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_Ptf_OldFusionDateRuleEn(DBA_DYNFLD_STP p, PtfOldFusionDateRuleEn enumValue)
{
    SET_ENUM(p, S_Ptf_OldFusionDateRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_DividendAccrualEn(DBA_DYNFLD_STP p, PtfDividendAccrualEn enumValue)
{
    SET_ENUM(p, A_Ptf_DividendAccrualEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_NegativeCashEn(DBA_DYNFLD_STP p, PtfNegativeCashEn enumValue)
{
    SET_ENUM(p, A_Ptf_NegativeCashEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_StatusEn(DBA_DYNFLD_STP p, PtfStatusEn enumValue)
{
    SET_ENUM(p, A_Ptf_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_ShariaEn(DBA_DYNFLD_STP p, InstrIslamicComplianceEn enumValue)
{
    SET_ENUM(p, A_Ptf_ShariaEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_MarginLendingEn(DBA_DYNFLD_STP p, PtfMarginLendingEn enumValue)
{
    SET_ENUM(p, A_Ptf_MarginLendingEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_CreditStatusEn(DBA_DYNFLD_STP p, PtfCreditStatusEn enumValue)
{
    SET_ENUM(p, A_Ptf_CreditStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_TaxLotMngtEn(DBA_DYNFLD_STP p, PtfTaxLotMngtEn enumValue)
{
    SET_ENUM(p, A_Ptf_TaxLotMngtEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_LastRebalancingStatusEn(DBA_DYNFLD_STP p, PtfLastRebalancingStatusEn enumValue)
{
    SET_ENUM(p, A_Ptf_LastRebalancingStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_CurrentWithdreqStatusEn(DBA_DYNFLD_STP p, PtfCurrentWithdreqStatusEn enumValue)
{
    SET_ENUM(p, A_Ptf_CurrentWithdreqStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_HcPositionDiffEn(DBA_DYNFLD_STP p, PtfHcPositionDiffEn enumValue)
{
    SET_ENUM(p, A_Ptf_HcPositionDiffEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_HcTaxlotDiffEn(DBA_DYNFLD_STP p, PtfHcTaxlotDiffEn enumValue)
{
    SET_ENUM(p, A_Ptf_HcTaxlotDiffEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_CashBookingModelEn(DBA_DYNFLD_STP p, PtfCashBookingModelEn enumValue)
{
    SET_ENUM(p, A_Ptf_CashBookingModelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_OrderNettingEn(DBA_DYNFLD_STP p, PtfOrderNettingEn enumValue)
{
    SET_ENUM(p, A_Ptf_OrderNettingEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_OverlayStatusEn(DBA_DYNFLD_STP p, PtfOverlayStatusEn enumValue)
{
    SET_ENUM(p, A_Ptf_OverlayStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_QuasiCashEn(DBA_DYNFLD_STP p, PtfQuasiCashEn enumValue)
{
    SET_ENUM(p, A_Ptf_QuasiCashEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_OrderAllocRuleEn(DBA_DYNFLD_STP p, PtfOrderAllocRuleEn enumValue)
{
    SET_ENUM(p, A_Ptf_OrderAllocRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_OrderBuyAllocRuleEn(DBA_DYNFLD_STP p, PtfOrderBuyAllocRuleEn enumValue)
{
    SET_ENUM(p, A_Ptf_OrderBuyAllocRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_HcPerfDiffEn(DBA_DYNFLD_STP p, PtfHcPerfDiffEn enumValue)
{
    SET_ENUM(p, A_Ptf_HcPerfDiffEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_HierGroupOrderEn(DBA_DYNFLD_STP p, PtfHierGroupOrderEn enumValue)
{
    SET_ENUM(p, A_Ptf_HierGroupOrderEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_SubNatEn(DBA_DYNFLD_STP p, PtfSubNatEn enumValue)
{
    SET_ENUM(p, A_Ptf_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_OverlayManagedEn(DBA_DYNFLD_STP p, PtfOverlayManagedEn enumValue)
{
    SET_ENUM(p, A_Ptf_OverlayManagedEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_MvDrpReportFreqEn(DBA_DYNFLD_STP p, PtfMvDrpReportFreqEn enumValue)
{
    SET_ENUM(p, A_Ptf_MvDrpReportFreqEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_PrivilegeEn(DBA_DYNFLD_STP p, DictAttributeTemplatePrivilegeEn enumValue)
{
    SET_ENUM(p, A_Ptf_PrivilegeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Ptf_DlmEn(DBA_DYNFLD_STP p, DictAttributeTemplateDlmEn enumValue)
{
    SET_ENUM(p, A_Ptf_DlmEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline OutboxSchemaNatEn            GET_A_OutboxSchema_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxSchemaNatEn>  (GET_ENUM(p, A_OutboxSchema_NatEn)));
}
inline OutboxSchemaNatEn            GET_S_OutboxSchema_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxSchemaNatEn>  (GET_ENUM(p, S_OutboxSchema_NatEn)));
}

inline OutboxSchemaNatEn            _GET_A_OutboxSchema_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxSchemaNatEn>  (_GET_ENUM(p, A_OutboxSchema_NatEn)));
}
inline OutboxSchemaNatEn            _GET_S_OutboxSchema_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxSchemaNatEn>  (_GET_ENUM(p, S_OutboxSchema_NatEn)));
}

inline void                         SET_A_OutboxSchema_NatEn(DBA_DYNFLD_STP p, OutboxSchemaNatEn enumValue)
{
    SET_ENUM(p, A_OutboxSchema_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_OutboxSchema_NatEn(DBA_DYNFLD_STP p, OutboxSchemaNatEn enumValue)
{
    SET_ENUM(p, S_OutboxSchema_NatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline MifidMvDrpTrackStatusEn      GET_A_MifidMvDrpTrack_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MifidMvDrpTrackStatusEn>  (GET_ENUM(p, A_MifidMvDrpTrack_StatusEn)));
}

inline MifidMvDrpTrackStatusEn      _GET_A_MifidMvDrpTrack_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MifidMvDrpTrackStatusEn>  (_GET_ENUM(p, A_MifidMvDrpTrack_StatusEn)));
}

inline void                         SET_A_MifidMvDrpTrack_StatusEn(DBA_DYNFLD_STP p, MifidMvDrpTrackStatusEn enumValue)
{
    SET_ENUM(p, A_MifidMvDrpTrack_StatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestHistoStatusEn           GET_A_QuestHisto_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestHistoStatusEn>  (GET_ENUM(p, A_QuestHisto_StatusEn)));
}

inline QuestHistoStatusEn           _GET_A_QuestHisto_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestHistoStatusEn>  (_GET_ENUM(p, A_QuestHisto_StatusEn)));
}

inline void                         SET_A_QuestHisto_StatusEn(DBA_DYNFLD_STP p, QuestHistoStatusEn enumValue)
{
    SET_ENUM(p, A_QuestHisto_StatusEn, enumValue);
}


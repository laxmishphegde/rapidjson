/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ObjectModifStatActionEn      GET_A_ObjectModifStat_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ObjectModifStatActionEn>  (GET_ENUM(p, A_ObjectModifStat_ActionEn)));
}
inline ObjectModifStatActionEn      GET_S_ObjectModifStat_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ObjectModifStatActionEn>  (GET_ENUM(p, S_ObjectModifStat_ActionEn)));
}

inline ObjectModifStatActionEn      _GET_A_ObjectModifStat_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ObjectModifStatActionEn>  (_GET_ENUM(p, A_ObjectModifStat_ActionEn)));
}
inline ObjectModifStatActionEn      _GET_S_ObjectModifStat_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ObjectModifStatActionEn>  (_GET_ENUM(p, S_ObjectModifStat_ActionEn)));
}

inline void                         SET_A_ObjectModifStat_ActionEn(DBA_DYNFLD_STP p, ObjectModifStatActionEn enumValue)
{
    SET_ENUM(p, A_ObjectModifStat_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ObjectModifStat_ActionEn(DBA_DYNFLD_STP p, ObjectModifStatActionEn enumValue)
{
    SET_ENUM(p, S_ObjectModifStat_ActionEn, static_cast<unsigned char>(enumValue));
}


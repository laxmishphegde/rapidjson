/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline MeDataOrgaScopeLevelEn       GET_A_MeDataOrgaScope_LevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaScopeLevelEn>  (GET_ENUM(p, A_MeDataOrgaScope_LevelEn)));
}
inline MeDataOrgaScopeLevelEn       GET_S_MeDataOrgaScope_LevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaScopeLevelEn>  (GET_ENUM(p, S_MeDataOrgaScope_LevelEn)));
}
inline MeDataOrgaStatusEn           GET_A_MeDataOrgaScope_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (GET_ENUM(p, A_MeDataOrgaScope_StatusEn)));
}
inline MeDataOrgaStatusEn           GET_S_MeDataOrgaScope_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (GET_ENUM(p, S_MeDataOrgaScope_StatusEn)));
}

inline MeDataOrgaScopeLevelEn       _GET_A_MeDataOrgaScope_LevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaScopeLevelEn>  (_GET_ENUM(p, A_MeDataOrgaScope_LevelEn)));
}
inline MeDataOrgaScopeLevelEn       _GET_S_MeDataOrgaScope_LevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaScopeLevelEn>  (_GET_ENUM(p, S_MeDataOrgaScope_LevelEn)));
}
inline MeDataOrgaStatusEn           _GET_A_MeDataOrgaScope_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (_GET_ENUM(p, A_MeDataOrgaScope_StatusEn)));
}
inline MeDataOrgaStatusEn           _GET_S_MeDataOrgaScope_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MeDataOrgaStatusEn>  (_GET_ENUM(p, S_MeDataOrgaScope_StatusEn)));
}

inline void                         SET_A_MeDataOrgaScope_LevelEn(DBA_DYNFLD_STP p, MeDataOrgaScopeLevelEn enumValue)
{
    SET_ENUM(p, A_MeDataOrgaScope_LevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MeDataOrgaScope_LevelEn(DBA_DYNFLD_STP p, MeDataOrgaScopeLevelEn enumValue)
{
    SET_ENUM(p, S_MeDataOrgaScope_LevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MeDataOrgaScope_StatusEn(DBA_DYNFLD_STP p, MeDataOrgaStatusEn enumValue)
{
    SET_ENUM(p, A_MeDataOrgaScope_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MeDataOrgaScope_StatusEn(DBA_DYNFLD_STP p, MeDataOrgaStatusEn enumValue)
{
    SET_ENUM(p, S_MeDataOrgaScope_StatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PackageDefinitionNatEn       GET_A_PackageEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (GET_ENUM(p, A_PackageEntity_NatEn)));
}

inline PackageDefinitionNatEn       _GET_A_PackageEntity_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageDefinitionNatEn>  (_GET_ENUM(p, A_PackageEntity_NatEn)));
}

inline void                         SET_A_PackageEntity_NatEn(DBA_DYNFLD_STP p, PackageDefinitionNatEn enumValue)
{
    SET_ENUM(p, A_PackageEntity_NatEn, static_cast<unsigned char>(enumValue));
}


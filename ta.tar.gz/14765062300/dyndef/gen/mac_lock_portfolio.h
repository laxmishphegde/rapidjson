/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline LockPortfolioNatEn           GET_A_LockPortfolio_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LockPortfolioNatEn>  (GET_ENUM(p, A_LockPortfolio_NatEn)));
}
inline LockPortfolioNatEn           GET_S_LockPortfolio_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LockPortfolioNatEn>  (GET_ENUM(p, S_LockPortfolio_NatEn)));
}

inline LockPortfolioNatEn           _GET_A_LockPortfolio_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LockPortfolioNatEn>  (_GET_ENUM(p, A_LockPortfolio_NatEn)));
}
inline LockPortfolioNatEn           _GET_S_LockPortfolio_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LockPortfolioNatEn>  (_GET_ENUM(p, S_LockPortfolio_NatEn)));
}

inline void                         SET_A_LockPortfolio_NatEn(DBA_DYNFLD_STP p, LockPortfolioNatEn enumValue)
{
    SET_ENUM(p, A_LockPortfolio_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_LockPortfolio_NatEn(DBA_DYNFLD_STP p, LockPortfolioNatEn enumValue)
{
    SET_ENUM(p, S_LockPortfolio_NatEn, static_cast<unsigned char>(enumValue));
}


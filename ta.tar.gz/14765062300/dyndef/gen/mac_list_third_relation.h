/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdCustomerCustRoleEn      GET_A_ListThirdRelation_RelationshipTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (GET_ENUM(p, A_ListThirdRelation_RelationshipTypeEn)));
}
inline ThirdCustomerCustRoleEn      GET_S_ListThirdRelation_RelationshipTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (GET_ENUM(p, S_ListThirdRelation_RelationshipTypeEn)));
}

inline ThirdCustomerCustRoleEn      _GET_A_ListThirdRelation_RelationshipTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (_GET_ENUM(p, A_ListThirdRelation_RelationshipTypeEn)));
}
inline ThirdCustomerCustRoleEn      _GET_S_ListThirdRelation_RelationshipTypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdCustomerCustRoleEn>  (_GET_ENUM(p, S_ListThirdRelation_RelationshipTypeEn)));
}

inline void                         SET_A_ListThirdRelation_RelationshipTypeEn(DBA_DYNFLD_STP p, ThirdCustomerCustRoleEn enumValue)
{
    SET_ENUM(p, A_ListThirdRelation_RelationshipTypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ListThirdRelation_RelationshipTypeEn(DBA_DYNFLD_STP p, ThirdCustomerCustRoleEn enumValue)
{
    SET_ENUM(p, S_ListThirdRelation_RelationshipTypeEn, static_cast<unsigned char>(enumValue));
}


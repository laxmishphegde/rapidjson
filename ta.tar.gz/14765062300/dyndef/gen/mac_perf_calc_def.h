/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PerfCalcDefClassifFreqEn     GET_A_PerfCalcDef_ClassifFreqEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefClassifFreqEn>  (GET_ENUM(p, A_PerfCalcDef_ClassifFreqEn)));
}
inline PerfCalcDefPerfAttribEn      GET_A_PerfCalcDef_PerfAttribEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefPerfAttribEn>  (GET_ENUM(p, A_PerfCalcDef_PerfAttribEn)));
}
inline PerfCalcDefReturnMethodEn    GET_A_PerfCalcDef_ReturnMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefReturnMethodEn>  (GET_ENUM(p, A_PerfCalcDef_ReturnMethodEn)));
}
inline PerfCalcDefEffectDetailEn    GET_A_PerfCalcDef_EffectDetailEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefEffectDetailEn>  (GET_ENUM(p, A_PerfCalcDef_EffectDetailEn)));
}

inline PerfCalcDefClassifFreqEn     _GET_A_PerfCalcDef_ClassifFreqEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefClassifFreqEn>  (_GET_ENUM(p, A_PerfCalcDef_ClassifFreqEn)));
}
inline PerfCalcDefPerfAttribEn      _GET_A_PerfCalcDef_PerfAttribEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefPerfAttribEn>  (_GET_ENUM(p, A_PerfCalcDef_PerfAttribEn)));
}
inline PerfCalcDefReturnMethodEn    _GET_A_PerfCalcDef_ReturnMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefReturnMethodEn>  (_GET_ENUM(p, A_PerfCalcDef_ReturnMethodEn)));
}
inline PerfCalcDefEffectDetailEn    _GET_A_PerfCalcDef_EffectDetailEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcDefEffectDetailEn>  (_GET_ENUM(p, A_PerfCalcDef_EffectDetailEn)));
}

inline void                         SET_A_PerfCalcDef_ClassifFreqEn(DBA_DYNFLD_STP p, PerfCalcDefClassifFreqEn enumValue)
{
    SET_ENUM(p, A_PerfCalcDef_ClassifFreqEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfCalcDef_PerfAttribEn(DBA_DYNFLD_STP p, PerfCalcDefPerfAttribEn enumValue)
{
    SET_ENUM(p, A_PerfCalcDef_PerfAttribEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfCalcDef_ReturnMethodEn(DBA_DYNFLD_STP p, PerfCalcDefReturnMethodEn enumValue)
{
    SET_ENUM(p, A_PerfCalcDef_ReturnMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfCalcDef_EffectDetailEn(DBA_DYNFLD_STP p, PerfCalcDefEffectDetailEn enumValue)
{
    SET_ENUM(p, A_PerfCalcDef_EffectDetailEn, static_cast<unsigned char>(enumValue));
}


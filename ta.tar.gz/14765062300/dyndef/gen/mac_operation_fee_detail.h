/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline OperationFeeDetailNatEn      GET_A_OperationFeeDetail_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OperationFeeDetailNatEn>  (GET_ENUM(p, A_OperationFeeDetail_NatEn)));
}

inline OperationFeeDetailNatEn      _GET_A_OperationFeeDetail_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OperationFeeDetailNatEn>  (_GET_ENUM(p, A_OperationFeeDetail_NatEn)));
}

inline void                         SET_A_OperationFeeDetail_NatEn(DBA_DYNFLD_STP p, OperationFeeDetailNatEn enumValue)
{
    SET_ENUM(p, A_OperationFeeDetail_NatEn, static_cast<unsigned char>(enumValue));
}


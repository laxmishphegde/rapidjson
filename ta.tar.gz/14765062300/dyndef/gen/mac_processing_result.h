/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ProcessingMessageNatEn       GET_A_ProcessingResult_ResultLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProcessingMessageNatEn>  (GET_ENUM(p, A_ProcessingResult_ResultLevelEn)));
}

inline ProcessingMessageNatEn       _GET_A_ProcessingResult_ResultLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProcessingMessageNatEn>  (_GET_ENUM(p, A_ProcessingResult_ResultLevelEn)));
}

inline void                         SET_A_ProcessingResult_ResultLevelEn(DBA_DYNFLD_STP p, ProcessingMessageNatEn enumValue)
{
    SET_ENUM(p, A_ProcessingResult_ResultLevelEn, static_cast<unsigned char>(enumValue));
}


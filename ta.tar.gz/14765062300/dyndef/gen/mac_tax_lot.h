/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TaxLotMovementNatEn          GET_A_TaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (GET_ENUM(p, A_TaxLot_MovementNatEn)));
}
inline TaxLotMovementNatEn          GET_S_TaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (GET_ENUM(p, S_TaxLot_MovementNatEn)));
}
inline TaxLotInputNatEn             GET_A_TaxLot_InputNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotInputNatEn>  (GET_ENUM(p, A_TaxLot_InputNatEn)));
}
inline TaxLotImpactEn               GET_A_TaxLot_ImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotImpactEn>  (GET_ENUM(p, A_TaxLot_ImpactEn)));
}
inline TaxLotStatusEn               GET_A_TaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (GET_ENUM(p, A_TaxLot_StatusEn)));
}
inline TaxLotStatusEn               GET_S_TaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (GET_ENUM(p, S_TaxLot_StatusEn)));
}
inline TaxLotOrderEn                GET_A_TaxLot_OrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOrderEn>  (GET_ENUM(p, A_TaxLot_OrderEn)));
}

inline TaxLotMovementNatEn          _GET_A_TaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (_GET_ENUM(p, A_TaxLot_MovementNatEn)));
}
inline TaxLotMovementNatEn          _GET_S_TaxLot_MovementNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotMovementNatEn>  (_GET_ENUM(p, S_TaxLot_MovementNatEn)));
}
inline TaxLotInputNatEn             _GET_A_TaxLot_InputNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotInputNatEn>  (_GET_ENUM(p, A_TaxLot_InputNatEn)));
}
inline TaxLotImpactEn               _GET_A_TaxLot_ImpactEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotImpactEn>  (_GET_ENUM(p, A_TaxLot_ImpactEn)));
}
inline TaxLotStatusEn               _GET_A_TaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (_GET_ENUM(p, A_TaxLot_StatusEn)));
}
inline TaxLotStatusEn               _GET_S_TaxLot_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotStatusEn>  (_GET_ENUM(p, S_TaxLot_StatusEn)));
}
inline TaxLotOrderEn                _GET_A_TaxLot_OrderEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TaxLotOrderEn>  (_GET_ENUM(p, A_TaxLot_OrderEn)));
}

inline void                         SET_A_TaxLot_MovementNatEn(DBA_DYNFLD_STP p, TaxLotMovementNatEn enumValue)
{
    SET_ENUM(p, A_TaxLot_MovementNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLot_MovementNatEn(DBA_DYNFLD_STP p, TaxLotMovementNatEn enumValue)
{
    SET_ENUM(p, S_TaxLot_MovementNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLot_InputNatEn(DBA_DYNFLD_STP p, TaxLotInputNatEn enumValue)
{
    SET_ENUM(p, A_TaxLot_InputNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLot_ImpactEn(DBA_DYNFLD_STP p, TaxLotImpactEn enumValue)
{
    SET_ENUM(p, A_TaxLot_ImpactEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLot_StatusEn(DBA_DYNFLD_STP p, TaxLotStatusEn enumValue)
{
    SET_ENUM(p, A_TaxLot_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TaxLot_StatusEn(DBA_DYNFLD_STP p, TaxLotStatusEn enumValue)
{
    SET_ENUM(p, S_TaxLot_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TaxLot_OrderEn(DBA_DYNFLD_STP p, TaxLotOrderEn enumValue)
{
    SET_ENUM(p, A_TaxLot_OrderEn, static_cast<unsigned char>(enumValue));
}


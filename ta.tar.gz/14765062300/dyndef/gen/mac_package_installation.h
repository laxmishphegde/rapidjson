/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PackageInstallationStatusEn  GET_A_PackageInstallation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (GET_ENUM(p, A_PackageInstallation_StatusEn)));
}
inline PackageInstallationStatusEn  GET_S_PackageInstallation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (GET_ENUM(p, S_PackageInstallation_StatusEn)));
}

inline PackageInstallationStatusEn  _GET_A_PackageInstallation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (_GET_ENUM(p, A_PackageInstallation_StatusEn)));
}
inline PackageInstallationStatusEn  _GET_S_PackageInstallation_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PackageInstallationStatusEn>  (_GET_ENUM(p, S_PackageInstallation_StatusEn)));
}

inline void                         SET_A_PackageInstallation_StatusEn(DBA_DYNFLD_STP p, PackageInstallationStatusEn enumValue)
{
    SET_ENUM(p, A_PackageInstallation_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PackageInstallation_StatusEn(DBA_DYNFLD_STP p, PackageInstallationStatusEn enumValue)
{
    SET_ENUM(p, S_PackageInstallation_StatusEn, static_cast<unsigned char>(enumValue));
}


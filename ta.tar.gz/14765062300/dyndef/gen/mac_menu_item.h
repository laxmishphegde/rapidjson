/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline MenuItemNatEn                GET_A_MenuItem_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemNatEn>  (GET_ENUM(p, A_MenuItem_NatEn)));
}
inline MenuItemNatEn                GET_S_MenuItem_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemNatEn>  (GET_ENUM(p, S_MenuItem_NatEn)));
}
inline MenuItemScriptNatEn          GET_A_MenuItem_ScriptNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemScriptNatEn>  (GET_ENUM(p, A_MenuItem_ScriptNatEn)));
}
inline MenuItemScriptNatEn          GET_S_MenuItem_ScriptNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemScriptNatEn>  (GET_ENUM(p, S_MenuItem_ScriptNatEn)));
}
inline DictEntityNatEn              GET_A_MenuItem_EntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (GET_ENUM(p, A_MenuItem_EntityNatEn)));
}
inline DictEntityNatEn              GET_S_MenuItem_EntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (GET_ENUM(p, S_MenuItem_EntityNatEn)));
}
inline MenuItemActionEn             GET_A_MenuItem_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemActionEn>  (GET_ENUM(p, A_MenuItem_ActionEn)));
}
inline MenuItemActionEn             GET_S_MenuItem_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemActionEn>  (GET_ENUM(p, S_MenuItem_ActionEn)));
}

inline MenuItemNatEn                _GET_A_MenuItem_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemNatEn>  (_GET_ENUM(p, A_MenuItem_NatEn)));
}
inline MenuItemNatEn                _GET_S_MenuItem_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemNatEn>  (_GET_ENUM(p, S_MenuItem_NatEn)));
}
inline MenuItemScriptNatEn          _GET_A_MenuItem_ScriptNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemScriptNatEn>  (_GET_ENUM(p, A_MenuItem_ScriptNatEn)));
}
inline MenuItemScriptNatEn          _GET_S_MenuItem_ScriptNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemScriptNatEn>  (_GET_ENUM(p, S_MenuItem_ScriptNatEn)));
}
inline DictEntityNatEn              _GET_A_MenuItem_EntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (_GET_ENUM(p, A_MenuItem_EntityNatEn)));
}
inline DictEntityNatEn              _GET_S_MenuItem_EntityNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictEntityNatEn>  (_GET_ENUM(p, S_MenuItem_EntityNatEn)));
}
inline MenuItemActionEn             _GET_A_MenuItem_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemActionEn>  (_GET_ENUM(p, A_MenuItem_ActionEn)));
}
inline MenuItemActionEn             _GET_S_MenuItem_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MenuItemActionEn>  (_GET_ENUM(p, S_MenuItem_ActionEn)));
}

inline void                         SET_A_MenuItem_NatEn(DBA_DYNFLD_STP p, MenuItemNatEn enumValue)
{
    SET_ENUM(p, A_MenuItem_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MenuItem_NatEn(DBA_DYNFLD_STP p, MenuItemNatEn enumValue)
{
    SET_ENUM(p, S_MenuItem_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MenuItem_ScriptNatEn(DBA_DYNFLD_STP p, MenuItemScriptNatEn enumValue)
{
    SET_ENUM(p, A_MenuItem_ScriptNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MenuItem_ScriptNatEn(DBA_DYNFLD_STP p, MenuItemScriptNatEn enumValue)
{
    SET_ENUM(p, S_MenuItem_ScriptNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MenuItem_EntityNatEn(DBA_DYNFLD_STP p, DictEntityNatEn enumValue)
{
    SET_ENUM(p, A_MenuItem_EntityNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MenuItem_EntityNatEn(DBA_DYNFLD_STP p, DictEntityNatEn enumValue)
{
    SET_ENUM(p, S_MenuItem_EntityNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MenuItem_ActionEn(DBA_DYNFLD_STP p, MenuItemActionEn enumValue)
{
    SET_ENUM(p, A_MenuItem_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MenuItem_ActionEn(DBA_DYNFLD_STP p, MenuItemActionEn enumValue)
{
    SET_ENUM(p, S_MenuItem_ActionEn, static_cast<unsigned char>(enumValue));
}


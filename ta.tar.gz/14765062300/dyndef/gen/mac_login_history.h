/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline LoginHistNatEn               GET_A_LoginHist_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LoginHistNatEn>  (GET_ENUM(p, A_LoginHist_NatEn)));
}
inline LoginHistNatEn               GET_S_LoginHist_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LoginHistNatEn>  (GET_ENUM(p, S_LoginHist_NatEn)));
}

inline LoginHistNatEn               _GET_A_LoginHist_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LoginHistNatEn>  (_GET_ENUM(p, A_LoginHist_NatEn)));
}
inline LoginHistNatEn               _GET_S_LoginHist_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LoginHistNatEn>  (_GET_ENUM(p, S_LoginHist_NatEn)));
}

inline void                         SET_A_LoginHist_NatEn(DBA_DYNFLD_STP p, LoginHistNatEn enumValue)
{
    SET_ENUM(p, A_LoginHist_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_LoginHist_NatEn(DBA_DYNFLD_STP p, LoginHistNatEn enumValue)
{
    SET_ENUM(p, S_LoginHist_NatEn, static_cast<unsigned char>(enumValue));
}


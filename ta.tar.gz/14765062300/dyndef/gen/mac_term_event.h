/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline TermEvtOptionClassEn         GET_A_TermEvt_OptionClassEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtOptionClassEn>  (GET_ENUM(p, A_TermEvt_OptionClassEn)));
}
inline TermEvtOptStyleEn            GET_A_TermEvt_OptStyleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtOptStyleEn>  (GET_ENUM(p, A_TermEvt_OptStyleEn)));
}
inline TermEvtFreqUnitEn            GET_A_TermEvt_FreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtFreqUnitEn>  (GET_ENUM(p, A_TermEvt_FreqUnitEn)));
}
inline InstrPremiumPmtEn            GET_A_TermEvt_PremiumPmtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPremiumPmtEn>  (GET_ENUM(p, A_TermEvt_PremiumPmtEn)));
}
inline TermEvtBarrierNatEn          GET_A_TermEvt_BarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (GET_ENUM(p, A_TermEvt_BarrierNatEn)));
}
inline TermEvtPayOffNatEn           GET_A_TermEvt_PayOffNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtPayOffNatEn>  (GET_ENUM(p, A_TermEvt_PayOffNatEn)));
}
inline TermEvtBarrierNatEn          GET_A_TermEvt_UpperBarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (GET_ENUM(p, A_TermEvt_UpperBarrierNatEn)));
}
inline TermEvtEventTimeEn           GET_A_TermEvt_EventTimeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtEventTimeEn>  (GET_ENUM(p, A_TermEvt_EventTimeEn)));
}
inline InstrNatEn                   GET_A_TermEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (GET_ENUM(p, A_TermEvt_InstrNatEn)));
}

inline TermEvtOptionClassEn         _GET_A_TermEvt_OptionClassEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtOptionClassEn>  (_GET_ENUM(p, A_TermEvt_OptionClassEn)));
}
inline TermEvtOptStyleEn            _GET_A_TermEvt_OptStyleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtOptStyleEn>  (_GET_ENUM(p, A_TermEvt_OptStyleEn)));
}
inline TermEvtFreqUnitEn            _GET_A_TermEvt_FreqUnitEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtFreqUnitEn>  (_GET_ENUM(p, A_TermEvt_FreqUnitEn)));
}
inline InstrPremiumPmtEn            _GET_A_TermEvt_PremiumPmtEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrPremiumPmtEn>  (_GET_ENUM(p, A_TermEvt_PremiumPmtEn)));
}
inline TermEvtBarrierNatEn          _GET_A_TermEvt_BarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (_GET_ENUM(p, A_TermEvt_BarrierNatEn)));
}
inline TermEvtPayOffNatEn           _GET_A_TermEvt_PayOffNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtPayOffNatEn>  (_GET_ENUM(p, A_TermEvt_PayOffNatEn)));
}
inline TermEvtBarrierNatEn          _GET_A_TermEvt_UpperBarrierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtBarrierNatEn>  (_GET_ENUM(p, A_TermEvt_UpperBarrierNatEn)));
}
inline TermEvtEventTimeEn           _GET_A_TermEvt_EventTimeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<TermEvtEventTimeEn>  (_GET_ENUM(p, A_TermEvt_EventTimeEn)));
}
inline InstrNatEn                   _GET_A_TermEvt_InstrNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrNatEn>  (_GET_ENUM(p, A_TermEvt_InstrNatEn)));
}

inline void                         SET_A_TermEvt_OptionClassEn(DBA_DYNFLD_STP p, TermEvtOptionClassEn enumValue)
{
    SET_ENUM(p, A_TermEvt_OptionClassEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_OptStyleEn(DBA_DYNFLD_STP p, TermEvtOptStyleEn enumValue)
{
    SET_ENUM(p, A_TermEvt_OptStyleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_FreqUnitEn(DBA_DYNFLD_STP p, TermEvtFreqUnitEn enumValue)
{
    SET_ENUM(p, A_TermEvt_FreqUnitEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_PremiumPmtEn(DBA_DYNFLD_STP p, InstrPremiumPmtEn enumValue)
{
    SET_ENUM(p, A_TermEvt_PremiumPmtEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_BarrierNatEn(DBA_DYNFLD_STP p, TermEvtBarrierNatEn enumValue)
{
    SET_ENUM(p, A_TermEvt_BarrierNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_PayOffNatEn(DBA_DYNFLD_STP p, TermEvtPayOffNatEn enumValue)
{
    SET_ENUM(p, A_TermEvt_PayOffNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_UpperBarrierNatEn(DBA_DYNFLD_STP p, TermEvtBarrierNatEn enumValue)
{
    SET_ENUM(p, A_TermEvt_UpperBarrierNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_EventTimeEn(DBA_DYNFLD_STP p, TermEvtEventTimeEn enumValue)
{
    SET_ENUM(p, A_TermEvt_EventTimeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TermEvt_InstrNatEn(DBA_DYNFLD_STP p, InstrNatEn enumValue)
{
    SET_ENUM(p, A_TermEvt_InstrNatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline LogTypeEn                    GET_A_Log_TypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogTypeEn>  (GET_ENUM(p, A_Log_TypeEn)));
}
inline LogWarningLevelEn            GET_A_Log_WarningLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogWarningLevelEn>  (GET_ENUM(p, A_Log_WarningLevelEn)));
}
inline LogModeEn                    GET_A_Log_ModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogModeEn>  (GET_ENUM(p, A_Log_ModeEn)));
}
inline LogSelectedLineEn            GET_A_Log_SelectedLineEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogSelectedLineEn>  (GET_ENUM(p, A_Log_SelectedLineEn)));
}

inline LogTypeEn                    _GET_A_Log_TypeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogTypeEn>  (_GET_ENUM(p, A_Log_TypeEn)));
}
inline LogWarningLevelEn            _GET_A_Log_WarningLevelEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogWarningLevelEn>  (_GET_ENUM(p, A_Log_WarningLevelEn)));
}
inline LogModeEn                    _GET_A_Log_ModeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogModeEn>  (_GET_ENUM(p, A_Log_ModeEn)));
}
inline LogSelectedLineEn            _GET_A_Log_SelectedLineEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<LogSelectedLineEn>  (_GET_ENUM(p, A_Log_SelectedLineEn)));
}

inline void                         SET_A_Log_TypeEn(DBA_DYNFLD_STP p, LogTypeEn enumValue)
{
    SET_ENUM(p, A_Log_TypeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Log_WarningLevelEn(DBA_DYNFLD_STP p, LogWarningLevelEn enumValue)
{
    SET_ENUM(p, A_Log_WarningLevelEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Log_ModeEn(DBA_DYNFLD_STP p, LogModeEn enumValue)
{
    SET_ENUM(p, A_Log_ModeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_Log_SelectedLineEn(DBA_DYNFLD_STP p, LogSelectedLineEn enumValue)
{
    SET_ENUM(p, A_Log_SelectedLineEn, static_cast<unsigned char>(enumValue));
}


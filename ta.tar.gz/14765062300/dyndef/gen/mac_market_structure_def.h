/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline MarketStructureDefNatEn      GET_A_MarketStructureDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefNatEn>  (GET_ENUM(p, A_MarketStructureDef_NatEn)));
}
inline MarketStructureDefNatEn      GET_S_MarketStructureDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefNatEn>  (GET_ENUM(p, S_MarketStructureDef_NatEn)));
}
inline MarketStructureDefGenStatusEn GET_A_MarketStructureDef_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefGenStatusEn>  (GET_ENUM(p, A_MarketStructureDef_GenStatusEn)));
}
inline MarketStructureDefGenStatusEn GET_S_MarketStructureDef_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefGenStatusEn>  (GET_ENUM(p, S_MarketStructureDef_GenStatusEn)));
}

inline MarketStructureDefNatEn      _GET_A_MarketStructureDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefNatEn>  (_GET_ENUM(p, A_MarketStructureDef_NatEn)));
}
inline MarketStructureDefNatEn      _GET_S_MarketStructureDef_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefNatEn>  (_GET_ENUM(p, S_MarketStructureDef_NatEn)));
}
inline MarketStructureDefGenStatusEn _GET_A_MarketStructureDef_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefGenStatusEn>  (_GET_ENUM(p, A_MarketStructureDef_GenStatusEn)));
}
inline MarketStructureDefGenStatusEn _GET_S_MarketStructureDef_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefGenStatusEn>  (_GET_ENUM(p, S_MarketStructureDef_GenStatusEn)));
}

inline void                         SET_A_MarketStructureDef_NatEn(DBA_DYNFLD_STP p, MarketStructureDefNatEn enumValue)
{
    SET_ENUM(p, A_MarketStructureDef_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MarketStructureDef_NatEn(DBA_DYNFLD_STP p, MarketStructureDefNatEn enumValue)
{
    SET_ENUM(p, S_MarketStructureDef_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_MarketStructureDef_GenStatusEn(DBA_DYNFLD_STP p, MarketStructureDefGenStatusEn enumValue)
{
    SET_ENUM(p, A_MarketStructureDef_GenStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MarketStructureDef_GenStatusEn(DBA_DYNFLD_STP p, MarketStructureDefGenStatusEn enumValue)
{
    SET_ENUM(p, S_MarketStructureDef_GenStatusEn, static_cast<unsigned char>(enumValue));
}


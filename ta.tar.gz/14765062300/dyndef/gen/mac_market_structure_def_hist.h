/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline MarketStructureDefHistGenStatusEn GET_A_MarketStructureDefHist_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefHistGenStatusEn>  (GET_ENUM(p, A_MarketStructureDefHist_GenStatusEn)));
}
inline MarketStructureDefHistGenStatusEn GET_S_MarketStructureDefHist_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefHistGenStatusEn>  (GET_ENUM(p, S_MarketStructureDefHist_GenStatusEn)));
}

inline MarketStructureDefHistGenStatusEn _GET_A_MarketStructureDefHist_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefHistGenStatusEn>  (_GET_ENUM(p, A_MarketStructureDefHist_GenStatusEn)));
}
inline MarketStructureDefHistGenStatusEn _GET_S_MarketStructureDefHist_GenStatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<MarketStructureDefHistGenStatusEn>  (_GET_ENUM(p, S_MarketStructureDefHist_GenStatusEn)));
}

inline void                         SET_A_MarketStructureDefHist_GenStatusEn(DBA_DYNFLD_STP p, MarketStructureDefHistGenStatusEn enumValue)
{
    SET_ENUM(p, A_MarketStructureDefHist_GenStatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_MarketStructureDefHist_GenStatusEn(DBA_DYNFLD_STP p, MarketStructureDefHistGenStatusEn enumValue)
{
    SET_ENUM(p, S_MarketStructureDefHist_GenStatusEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PerfCalcResultPeriodNatEn    GET_A_PerfCalcResult_PeriodNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcResultPeriodNatEn>  (GET_ENUM(p, A_PerfCalcResult_PeriodNatEn)));
}
inline PerfCalcResultPeriodNatEn    GET_S_PerfCalcResult_PeriodNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcResultPeriodNatEn>  (GET_ENUM(p, S_PerfCalcResult_PeriodNatEn)));
}
inline PtfRetFreqUnitEn             GET_A_PerfCalcResult_FrequencyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (GET_ENUM(p, A_PerfCalcResult_FrequencyEn)));
}

inline PerfCalcResultPeriodNatEn    _GET_A_PerfCalcResult_PeriodNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcResultPeriodNatEn>  (_GET_ENUM(p, A_PerfCalcResult_PeriodNatEn)));
}
inline PerfCalcResultPeriodNatEn    _GET_S_PerfCalcResult_PeriodNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfCalcResultPeriodNatEn>  (_GET_ENUM(p, S_PerfCalcResult_PeriodNatEn)));
}
inline PtfRetFreqUnitEn             _GET_A_PerfCalcResult_FrequencyEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfRetFreqUnitEn>  (_GET_ENUM(p, A_PerfCalcResult_FrequencyEn)));
}

inline void                         SET_A_PerfCalcResult_PeriodNatEn(DBA_DYNFLD_STP p, PerfCalcResultPeriodNatEn enumValue)
{
    SET_ENUM(p, A_PerfCalcResult_PeriodNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_PerfCalcResult_PeriodNatEn(DBA_DYNFLD_STP p, PerfCalcResultPeriodNatEn enumValue)
{
    SET_ENUM(p, S_PerfCalcResult_PeriodNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PerfCalcResult_FrequencyEn(DBA_DYNFLD_STP p, PtfRetFreqUnitEn enumValue)
{
    SET_ENUM(p, A_PerfCalcResult_FrequencyEn, static_cast<unsigned char>(enumValue));
}


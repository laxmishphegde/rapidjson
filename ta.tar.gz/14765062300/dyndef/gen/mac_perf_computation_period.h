/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PerfComputationPeriodTechNatEn GET_S_PerfComputationPeriod_TechNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfComputationPeriodTechNatEn>  (GET_ENUM(p, S_PerfComputationPeriod_TechNatEn)));
}

inline PerfComputationPeriodTechNatEn _GET_S_PerfComputationPeriod_TechNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PerfComputationPeriodTechNatEn>  (_GET_ENUM(p, S_PerfComputationPeriod_TechNatEn)));
}

inline void                         SET_S_PerfComputationPeriod_TechNatEn(DBA_DYNFLD_STP p, PerfComputationPeriodTechNatEn enumValue)
{
    SET_ENUM(p, S_PerfComputationPeriod_TechNatEn, static_cast<unsigned char>(enumValue));
}


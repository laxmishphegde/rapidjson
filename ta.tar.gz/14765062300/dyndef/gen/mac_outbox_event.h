/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline OutboxEventStatusEn          GET_A_OutboxEvent_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxEventStatusEn>  (GET_ENUM(p, A_OutboxEvent_StatusEn)));
}
inline OutboxEventStatusEn          GET_S_OutboxEvent_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxEventStatusEn>  (GET_ENUM(p, S_OutboxEvent_StatusEn)));
}
inline SubscriptionActionEn         GET_A_OutboxEvent_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionActionEn>  (GET_ENUM(p, A_OutboxEvent_ActionEn)));
}

inline OutboxEventStatusEn          _GET_A_OutboxEvent_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxEventStatusEn>  (_GET_ENUM(p, A_OutboxEvent_StatusEn)));
}
inline OutboxEventStatusEn          _GET_S_OutboxEvent_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OutboxEventStatusEn>  (_GET_ENUM(p, S_OutboxEvent_StatusEn)));
}
inline SubscriptionActionEn         _GET_A_OutboxEvent_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SubscriptionActionEn>  (_GET_ENUM(p, A_OutboxEvent_ActionEn)));
}

inline void                         SET_A_OutboxEvent_StatusEn(DBA_DYNFLD_STP p, OutboxEventStatusEn enumValue)
{
    SET_ENUM(p, A_OutboxEvent_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_OutboxEvent_StatusEn(DBA_DYNFLD_STP p, OutboxEventStatusEn enumValue)
{
    SET_ENUM(p, S_OutboxEvent_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_OutboxEvent_ActionEn(DBA_DYNFLD_STP p, SubscriptionActionEn enumValue)
{
    SET_ENUM(p, A_OutboxEvent_ActionEn, static_cast<unsigned char>(enumValue));
}


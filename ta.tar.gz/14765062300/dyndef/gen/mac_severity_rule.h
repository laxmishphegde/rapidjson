/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline SeverityRuleDeviationGapMethodEn GET_A_SeverityRule_DeviationGapMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleDeviationGapMethodEn>  (GET_ENUM(p, A_SeverityRule_DeviationGapMethodEn)));
}
inline SeverityRuleScopeEn          GET_A_SeverityRule_ScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleScopeEn>  (GET_ENUM(p, A_SeverityRule_ScopeEn)));
}
inline SeverityRuleSubNatEn         GET_A_SeverityRule_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleSubNatEn>  (GET_ENUM(p, A_SeverityRule_SubNatEn)));
}
inline SeverityRuleComplianceFuncScopeEn GET_A_SeverityRule_ComplianceFuncScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleComplianceFuncScopeEn>  (GET_ENUM(p, A_SeverityRule_ComplianceFuncScopeEn)));
}

inline SeverityRuleDeviationGapMethodEn _GET_A_SeverityRule_DeviationGapMethodEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleDeviationGapMethodEn>  (_GET_ENUM(p, A_SeverityRule_DeviationGapMethodEn)));
}
inline SeverityRuleScopeEn          _GET_A_SeverityRule_ScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleScopeEn>  (_GET_ENUM(p, A_SeverityRule_ScopeEn)));
}
inline SeverityRuleSubNatEn         _GET_A_SeverityRule_SubNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleSubNatEn>  (_GET_ENUM(p, A_SeverityRule_SubNatEn)));
}
inline SeverityRuleComplianceFuncScopeEn _GET_A_SeverityRule_ComplianceFuncScopeEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<SeverityRuleComplianceFuncScopeEn>  (_GET_ENUM(p, A_SeverityRule_ComplianceFuncScopeEn)));
}

inline void                         SET_A_SeverityRule_DeviationGapMethodEn(DBA_DYNFLD_STP p, SeverityRuleDeviationGapMethodEn enumValue)
{
    SET_ENUM(p, A_SeverityRule_DeviationGapMethodEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SeverityRule_ScopeEn(DBA_DYNFLD_STP p, SeverityRuleScopeEn enumValue)
{
    SET_ENUM(p, A_SeverityRule_ScopeEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SeverityRule_SubNatEn(DBA_DYNFLD_STP p, SeverityRuleSubNatEn enumValue)
{
    SET_ENUM(p, A_SeverityRule_SubNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_SeverityRule_ComplianceFuncScopeEn(DBA_DYNFLD_STP p, SeverityRuleComplianceFuncScopeEn enumValue)
{
    SET_ENUM(p, A_SeverityRule_ComplianceFuncScopeEn, static_cast<unsigned char>(enumValue));
}


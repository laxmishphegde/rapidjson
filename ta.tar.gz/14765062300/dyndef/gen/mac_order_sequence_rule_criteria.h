/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline OrderSequenceRuleCriteriaSortEn GET_A_OrderSequenceRuleCriteria_SortEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OrderSequenceRuleCriteriaSortEn>  (GET_ENUM(p, A_OrderSequenceRuleCriteria_SortEn)));
}

inline OrderSequenceRuleCriteriaSortEn _GET_A_OrderSequenceRuleCriteria_SortEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OrderSequenceRuleCriteriaSortEn>  (_GET_ENUM(p, A_OrderSequenceRuleCriteria_SortEn)));
}

inline void                         SET_A_OrderSequenceRuleCriteria_SortEn(DBA_DYNFLD_STP p, OrderSequenceRuleCriteriaSortEn enumValue)
{
    SET_ENUM(p, A_OrderSequenceRuleCriteria_SortEn, static_cast<unsigned char>(enumValue));
}


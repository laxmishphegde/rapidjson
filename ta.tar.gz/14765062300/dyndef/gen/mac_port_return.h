/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PtfReturnReturnMetEn         GET_A_PtfReturn_ReturnMetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfReturnReturnMetEn>  (GET_ENUM(p, A_PtfReturn_ReturnMetEn)));
}
inline InstrRiskNatEn               GET_A_PtfReturn_RiskNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRiskNatEn>  (GET_ENUM(p, A_PtfReturn_RiskNatEn)));
}

inline PtfReturnReturnMetEn         _GET_A_PtfReturn_ReturnMetEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PtfReturnReturnMetEn>  (_GET_ENUM(p, A_PtfReturn_ReturnMetEn)));
}
inline InstrRiskNatEn               _GET_A_PtfReturn_RiskNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<InstrRiskNatEn>  (_GET_ENUM(p, A_PtfReturn_RiskNatEn)));
}

inline void                         SET_A_PtfReturn_ReturnMetEn(DBA_DYNFLD_STP p, PtfReturnReturnMetEn enumValue)
{
    SET_ENUM(p, A_PtfReturn_ReturnMetEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PtfReturn_RiskNatEn(DBA_DYNFLD_STP p, InstrRiskNatEn enumValue)
{
    SET_ENUM(p, A_PtfReturn_RiskNatEn, static_cast<unsigned char>(enumValue));
}


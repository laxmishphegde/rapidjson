/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ScheduleFunctionStatusEn     GET_A_ScheduleFunction_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ScheduleFunctionStatusEn>  (GET_ENUM(p, A_ScheduleFunction_StatusEn)));
}

inline ScheduleFunctionStatusEn     _GET_A_ScheduleFunction_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ScheduleFunctionStatusEn>  (_GET_ENUM(p, A_ScheduleFunction_StatusEn)));
}

inline void                         SET_A_ScheduleFunction_StatusEn(DBA_DYNFLD_STP p, ScheduleFunctionStatusEn enumValue)
{
    SET_ENUM(p, A_ScheduleFunction_StatusEn, static_cast<unsigned char>(enumValue));
}


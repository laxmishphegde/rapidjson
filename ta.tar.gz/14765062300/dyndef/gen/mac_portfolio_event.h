/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PortfolioEventNatEn          GET_A_PortfolioEvent_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioEventNatEn>  (GET_ENUM(p, A_PortfolioEvent_NatEn)));
}

inline PortfolioEventNatEn          _GET_A_PortfolioEvent_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioEventNatEn>  (_GET_ENUM(p, A_PortfolioEvent_NatEn)));
}

inline void                         SET_A_PortfolioEvent_NatEn(DBA_DYNFLD_STP p, PortfolioEventNatEn enumValue)
{
    SET_ENUM(p, A_PortfolioEvent_NatEn, static_cast<unsigned char>(enumValue));
}


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline PortfolioRequestsStatusEn    GET_A_PortfolioRequests_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioRequestsStatusEn>  (GET_ENUM(p, A_PortfolioRequests_StatusEn)));
}
inline PortfolioRequestsPtfDimensionEn GET_A_PortfolioRequests_PtfDimensionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioRequestsPtfDimensionEn>  (GET_ENUM(p, A_PortfolioRequests_PtfDimensionEn)));
}
inline PortfolioRequestsInstrDimensionEn GET_A_PortfolioRequests_InstrDimensionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioRequestsInstrDimensionEn>  (GET_ENUM(p, A_PortfolioRequests_InstrDimensionEn)));
}

inline PortfolioRequestsStatusEn    _GET_A_PortfolioRequests_StatusEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioRequestsStatusEn>  (_GET_ENUM(p, A_PortfolioRequests_StatusEn)));
}
inline PortfolioRequestsPtfDimensionEn _GET_A_PortfolioRequests_PtfDimensionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioRequestsPtfDimensionEn>  (_GET_ENUM(p, A_PortfolioRequests_PtfDimensionEn)));
}
inline PortfolioRequestsInstrDimensionEn _GET_A_PortfolioRequests_InstrDimensionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<PortfolioRequestsInstrDimensionEn>  (_GET_ENUM(p, A_PortfolioRequests_InstrDimensionEn)));
}

inline void                         SET_A_PortfolioRequests_StatusEn(DBA_DYNFLD_STP p, PortfolioRequestsStatusEn enumValue)
{
    SET_ENUM(p, A_PortfolioRequests_StatusEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PortfolioRequests_PtfDimensionEn(DBA_DYNFLD_STP p, PortfolioRequestsPtfDimensionEn enumValue)
{
    SET_ENUM(p, A_PortfolioRequests_PtfDimensionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_PortfolioRequests_InstrDimensionEn(DBA_DYNFLD_STP p, PortfolioRequestsInstrDimensionEn enumValue)
{
    SET_ENUM(p, A_PortfolioRequests_InstrDimensionEn, static_cast<unsigned char>(enumValue));
}


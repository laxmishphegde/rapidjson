/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ThirdChronoNatEn             GET_A_ThirdChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdChronoNatEn>  (GET_ENUM(p, A_ThirdChrono_NatEn)));
}
inline ThirdChronoNatEn             GET_S_ThirdChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdChronoNatEn>  (GET_ENUM(p, S_ThirdChrono_NatEn)));
}

inline ThirdChronoNatEn             _GET_A_ThirdChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdChronoNatEn>  (_GET_ENUM(p, A_ThirdChrono_NatEn)));
}
inline ThirdChronoNatEn             _GET_S_ThirdChrono_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ThirdChronoNatEn>  (_GET_ENUM(p, S_ThirdChrono_NatEn)));
}

inline void                         SET_A_ThirdChrono_NatEn(DBA_DYNFLD_STP p, ThirdChronoNatEn enumValue)
{
    SET_ENUM(p, A_ThirdChrono_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ThirdChrono_NatEn(DBA_DYNFLD_STP p, ThirdChronoNatEn enumValue)
{
    SET_ENUM(p, S_ThirdChrono_NatEn, static_cast<unsigned char>(enumValue));
}


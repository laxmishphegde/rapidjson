/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline QuestionnaireElementCondActionEn GET_A_QuestionnaireElementCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireElementCondActionEn>  (GET_ENUM(p, A_QuestionnaireElementCond_ActionEn)));
}
inline QuestionnaireElementCondActionEn GET_S_QuestionnaireElementCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireElementCondActionEn>  (GET_ENUM(p, S_QuestionnaireElementCond_ActionEn)));
}

inline QuestionnaireElementCondActionEn _GET_A_QuestionnaireElementCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireElementCondActionEn>  (_GET_ENUM(p, A_QuestionnaireElementCond_ActionEn)));
}
inline QuestionnaireElementCondActionEn _GET_S_QuestionnaireElementCond_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<QuestionnaireElementCondActionEn>  (_GET_ENUM(p, S_QuestionnaireElementCond_ActionEn)));
}

inline void                         SET_A_QuestionnaireElementCond_ActionEn(DBA_DYNFLD_STP p, QuestionnaireElementCondActionEn enumValue)
{
    SET_ENUM(p, A_QuestionnaireElementCond_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_QuestionnaireElementCond_ActionEn(DBA_DYNFLD_STP p, QuestionnaireElementCondActionEn enumValue)
{
    SET_ENUM(p, S_QuestionnaireElementCond_ActionEn, static_cast<unsigned char>(enumValue));
}


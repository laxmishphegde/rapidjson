/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline FmtEltDispContextEn          GET_A_ReferenceFormatElement_DispContextEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltDispContextEn>  (GET_ENUM(p, A_ReferenceFormatElement_DispContextEn)));
}
inline FmtEltSortRuleEn             GET_A_ReferenceFormatElement_SortRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltSortRuleEn>  (GET_ENUM(p, A_ReferenceFormatElement_SortRuleEn)));
}
inline FmtEltJustificationEn        GET_A_ReferenceFormatElement_JustificationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltJustificationEn>  (GET_ENUM(p, A_ReferenceFormatElement_JustificationEn)));
}
inline FmtHeaderFontEn              GET_A_ReferenceFormatElement_FontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (GET_ENUM(p, A_ReferenceFormatElement_FontEn)));
}
inline FmtEltSeparatorEn            GET_A_ReferenceFormatElement_SeparatorEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltSeparatorEn>  (GET_ENUM(p, A_ReferenceFormatElement_SeparatorEn)));
}
inline FmtHeaderFontEn              GET_A_ReferenceFormatElement_BreakFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (GET_ENUM(p, A_ReferenceFormatElement_BreakFontEn)));
}
inline FmtEltBreakFrameEn           GET_A_ReferenceFormatElement_BreakFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltBreakFrameEn>  (GET_ENUM(p, A_ReferenceFormatElement_BreakFrameEn)));
}
inline FmtEltHierNatEn              GET_A_ReferenceFormatElement_HierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltHierNatEn>  (GET_ENUM(p, A_ReferenceFormatElement_HierNatEn)));
}
inline FmtEltTslMultilingualEn      GET_A_ReferenceFormatElement_TslMultilingualEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltTslMultilingualEn>  (GET_ENUM(p, A_ReferenceFormatElement_TslMultilingualEn)));
}
inline FmtEltTslMultilingualEn      GET_S_ReferenceFormatElement_TslMultilingualEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltTslMultilingualEn>  (GET_ENUM(p, S_ReferenceFormatElement_TslMultilingualEn)));
}
inline FmtEltTslProcessingEn        GET_A_ReferenceFormatElement_TslProcessingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltTslProcessingEn>  (GET_ENUM(p, A_ReferenceFormatElement_TslProcessingEn)));
}
inline ReferenceFormatElementReferenceNatEn GET_A_ReferenceFormatElement_ReferenceNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ReferenceFormatElementReferenceNatEn>  (GET_ENUM(p, A_ReferenceFormatElement_ReferenceNatEn)));
}
inline ReferenceFormatElementReferenceNatEn GET_S_ReferenceFormatElement_ReferenceNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ReferenceFormatElementReferenceNatEn>  (GET_ENUM(p, S_ReferenceFormatElement_ReferenceNatEn)));
}
inline XdAttributeCustoTslSearchEn  GET_A_ReferenceFormatElement_TslSearchEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoTslSearchEn>  (GET_ENUM(p, A_ReferenceFormatElement_TslSearchEn)));
}
inline XdAttribOutboxPublishEn      GET_A_ReferenceFormatElement_OutboxPublishEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribOutboxPublishEn>  (GET_ENUM(p, A_ReferenceFormatElement_OutboxPublishEn)));
}

inline FmtEltDispContextEn          _GET_A_ReferenceFormatElement_DispContextEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltDispContextEn>  (_GET_ENUM(p, A_ReferenceFormatElement_DispContextEn)));
}
inline FmtEltSortRuleEn             _GET_A_ReferenceFormatElement_SortRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltSortRuleEn>  (_GET_ENUM(p, A_ReferenceFormatElement_SortRuleEn)));
}
inline FmtEltJustificationEn        _GET_A_ReferenceFormatElement_JustificationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltJustificationEn>  (_GET_ENUM(p, A_ReferenceFormatElement_JustificationEn)));
}
inline FmtHeaderFontEn              _GET_A_ReferenceFormatElement_FontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (_GET_ENUM(p, A_ReferenceFormatElement_FontEn)));
}
inline FmtEltSeparatorEn            _GET_A_ReferenceFormatElement_SeparatorEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltSeparatorEn>  (_GET_ENUM(p, A_ReferenceFormatElement_SeparatorEn)));
}
inline FmtHeaderFontEn              _GET_A_ReferenceFormatElement_BreakFontEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtHeaderFontEn>  (_GET_ENUM(p, A_ReferenceFormatElement_BreakFontEn)));
}
inline FmtEltBreakFrameEn           _GET_A_ReferenceFormatElement_BreakFrameEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltBreakFrameEn>  (_GET_ENUM(p, A_ReferenceFormatElement_BreakFrameEn)));
}
inline FmtEltHierNatEn              _GET_A_ReferenceFormatElement_HierNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltHierNatEn>  (_GET_ENUM(p, A_ReferenceFormatElement_HierNatEn)));
}
inline FmtEltTslMultilingualEn      _GET_A_ReferenceFormatElement_TslMultilingualEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltTslMultilingualEn>  (_GET_ENUM(p, A_ReferenceFormatElement_TslMultilingualEn)));
}
inline FmtEltTslMultilingualEn      _GET_S_ReferenceFormatElement_TslMultilingualEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltTslMultilingualEn>  (_GET_ENUM(p, S_ReferenceFormatElement_TslMultilingualEn)));
}
inline FmtEltTslProcessingEn        _GET_A_ReferenceFormatElement_TslProcessingEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<FmtEltTslProcessingEn>  (_GET_ENUM(p, A_ReferenceFormatElement_TslProcessingEn)));
}
inline ReferenceFormatElementReferenceNatEn _GET_A_ReferenceFormatElement_ReferenceNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ReferenceFormatElementReferenceNatEn>  (_GET_ENUM(p, A_ReferenceFormatElement_ReferenceNatEn)));
}
inline ReferenceFormatElementReferenceNatEn _GET_S_ReferenceFormatElement_ReferenceNatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ReferenceFormatElementReferenceNatEn>  (_GET_ENUM(p, S_ReferenceFormatElement_ReferenceNatEn)));
}
inline XdAttributeCustoTslSearchEn  _GET_A_ReferenceFormatElement_TslSearchEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttributeCustoTslSearchEn>  (_GET_ENUM(p, A_ReferenceFormatElement_TslSearchEn)));
}
inline XdAttribOutboxPublishEn      _GET_A_ReferenceFormatElement_OutboxPublishEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<XdAttribOutboxPublishEn>  (_GET_ENUM(p, A_ReferenceFormatElement_OutboxPublishEn)));
}

inline void                         SET_A_ReferenceFormatElement_DispContextEn(DBA_DYNFLD_STP p, FmtEltDispContextEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_DispContextEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_SortRuleEn(DBA_DYNFLD_STP p, FmtEltSortRuleEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_SortRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_JustificationEn(DBA_DYNFLD_STP p, FmtEltJustificationEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_JustificationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_FontEn(DBA_DYNFLD_STP p, FmtHeaderFontEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_FontEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_SeparatorEn(DBA_DYNFLD_STP p, FmtEltSeparatorEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_SeparatorEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_BreakFontEn(DBA_DYNFLD_STP p, FmtHeaderFontEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_BreakFontEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_BreakFrameEn(DBA_DYNFLD_STP p, FmtEltBreakFrameEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_BreakFrameEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_HierNatEn(DBA_DYNFLD_STP p, FmtEltHierNatEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_HierNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_TslMultilingualEn(DBA_DYNFLD_STP p, FmtEltTslMultilingualEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_TslMultilingualEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ReferenceFormatElement_TslMultilingualEn(DBA_DYNFLD_STP p, FmtEltTslMultilingualEn enumValue)
{
    SET_ENUM(p, S_ReferenceFormatElement_TslMultilingualEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_TslProcessingEn(DBA_DYNFLD_STP p, FmtEltTslProcessingEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_TslProcessingEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_ReferenceNatEn(DBA_DYNFLD_STP p, ReferenceFormatElementReferenceNatEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_ReferenceNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ReferenceFormatElement_ReferenceNatEn(DBA_DYNFLD_STP p, ReferenceFormatElementReferenceNatEn enumValue)
{
    SET_ENUM(p, S_ReferenceFormatElement_ReferenceNatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_TslSearchEn(DBA_DYNFLD_STP p, XdAttributeCustoTslSearchEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_TslSearchEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ReferenceFormatElement_OutboxPublishEn(DBA_DYNFLD_STP p, XdAttribOutboxPublishEn enumValue)
{
    SET_ENUM(p, A_ReferenceFormatElement_OutboxPublishEn, static_cast<unsigned char>(enumValue));
}


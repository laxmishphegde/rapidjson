/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline OpFeesAndTaxesCalculationRuleEn GET_A_OpFeesAndTaxes_CalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OpFeesAndTaxesCalculationRuleEn>  (GET_ENUM(p, A_OpFeesAndTaxes_CalculationRuleEn)));
}

inline OpFeesAndTaxesCalculationRuleEn _GET_A_OpFeesAndTaxes_CalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<OpFeesAndTaxesCalculationRuleEn>  (_GET_ENUM(p, A_OpFeesAndTaxes_CalculationRuleEn)));
}

inline void                         SET_A_OpFeesAndTaxes_CalculationRuleEn(DBA_DYNFLD_STP p, OpFeesAndTaxesCalculationRuleEn enumValue)
{
    SET_ENUM(p, A_OpFeesAndTaxes_CalculationRuleEn, static_cast<unsigned char>(enumValue));
}


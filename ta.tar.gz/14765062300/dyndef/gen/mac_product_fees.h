/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ProductFeesNatEn             GET_A_ProductFees_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesNatEn>  (GET_ENUM(p, A_ProductFees_NatEn)));
}
inline ProductFeesNatEn             GET_S_ProductFees_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesNatEn>  (GET_ENUM(p, S_ProductFees_NatEn)));
}
inline ProductFeesCalculationRuleEn GET_A_ProductFees_CalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesCalculationRuleEn>  (GET_ENUM(p, A_ProductFees_CalculationRuleEn)));
}
inline ProductFeesCalculationRuleEn GET_S_ProductFees_CalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesCalculationRuleEn>  (GET_ENUM(p, S_ProductFees_CalculationRuleEn)));
}
inline ProductFeesExanteExpostEn    GET_A_ProductFees_ExanteExpostEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesExanteExpostEn>  (GET_ENUM(p, A_ProductFees_ExanteExpostEn)));
}

inline ProductFeesNatEn             _GET_A_ProductFees_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesNatEn>  (_GET_ENUM(p, A_ProductFees_NatEn)));
}
inline ProductFeesNatEn             _GET_S_ProductFees_NatEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesNatEn>  (_GET_ENUM(p, S_ProductFees_NatEn)));
}
inline ProductFeesCalculationRuleEn _GET_A_ProductFees_CalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesCalculationRuleEn>  (_GET_ENUM(p, A_ProductFees_CalculationRuleEn)));
}
inline ProductFeesCalculationRuleEn _GET_S_ProductFees_CalculationRuleEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesCalculationRuleEn>  (_GET_ENUM(p, S_ProductFees_CalculationRuleEn)));
}
inline ProductFeesExanteExpostEn    _GET_A_ProductFees_ExanteExpostEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ProductFeesExanteExpostEn>  (_GET_ENUM(p, A_ProductFees_ExanteExpostEn)));
}

inline void                         SET_A_ProductFees_NatEn(DBA_DYNFLD_STP p, ProductFeesNatEn enumValue)
{
    SET_ENUM(p, A_ProductFees_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ProductFees_NatEn(DBA_DYNFLD_STP p, ProductFeesNatEn enumValue)
{
    SET_ENUM(p, S_ProductFees_NatEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ProductFees_CalculationRuleEn(DBA_DYNFLD_STP p, ProductFeesCalculationRuleEn enumValue)
{
    SET_ENUM(p, A_ProductFees_CalculationRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_ProductFees_CalculationRuleEn(DBA_DYNFLD_STP p, ProductFeesCalculationRuleEn enumValue)
{
    SET_ENUM(p, S_ProductFees_CalculationRuleEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_ProductFees_ExanteExpostEn(DBA_DYNFLD_STP p, ProductFeesExanteExpostEn enumValue)
{
    SET_ENUM(p, A_ProductFees_ExanteExpostEn, static_cast<unsigned char>(enumValue));
}


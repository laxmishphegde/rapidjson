/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/



inline ObjectModifStatActionEn      GET_A_TascEntityRecompObj_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ObjectModifStatActionEn>  (GET_ENUM(p, A_TascEntityRecompObj_ActionEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_A_TascEntityRecompObj_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, A_TascEntityRecompObj_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn GET_S_TascEntityRecompObj_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (GET_ENUM(p, S_TascEntityRecompObj_MeRecordLocationEn)));
}

inline ObjectModifStatActionEn      _GET_A_TascEntityRecompObj_ActionEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<ObjectModifStatActionEn>  (_GET_ENUM(p, A_TascEntityRecompObj_ActionEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_A_TascEntityRecompObj_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, A_TascEntityRecompObj_MeRecordLocationEn)));
}
inline DictAttributeTemplateMeRecordLocationEn _GET_S_TascEntityRecompObj_MeRecordLocationEn(DBA_DYNFLD_STP p) 
{
    return  (static_cast<DictAttributeTemplateMeRecordLocationEn>  (_GET_ENUM(p, S_TascEntityRecompObj_MeRecordLocationEn)));
}

inline void                         SET_A_TascEntityRecompObj_ActionEn(DBA_DYNFLD_STP p, ObjectModifStatActionEn enumValue)
{
    SET_ENUM(p, A_TascEntityRecompObj_ActionEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_A_TascEntityRecompObj_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, A_TascEntityRecompObj_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}
inline void                         SET_S_TascEntityRecompObj_MeRecordLocationEn(DBA_DYNFLD_STP p, DictAttributeTemplateMeRecordLocationEn enumValue)
{
    SET_ENUM(p, S_TascEntityRecompObj_MeRecordLocationEn, static_cast<unsigned char>(enumValue));
}

